# Лесон-2 пак скиллов (контент-завод)

Дополнение к основному паку. Ставится так же: папки из skills/ скопируй в свою папку скиллов Claude Code:
- Windows: C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\.claude\skills\
- Mac: ~/.claude/skills/
Перезапусти Claude.

## Что внутри
- content-radar - разведка конкурентов без подключений: публичные TG-каналы через t.me/s/, YouTube и Instagram по ссылкам. Выдаёт что залетело и идеи под тебя.
- brand-voice-setup - собирает ТВОЙ стиль речи из твоих текстов в файл, чтобы Claude писал в твоём тоне. Нет своих текстов - перенимает референс.

## Уже есть в основном паке (нужны для урока 2)
content-pro, humanizer, prompt-engineer, reels-content, reels-viewer, image-pro, whisper-transcribe, youtube-analyzer.

## Монтаж рилсов
Отдельным документом «Инструменты для рилсов» (ffmpeg + whisper, самодостаточные команды).
