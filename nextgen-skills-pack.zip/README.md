# Стартовый пак скиллов для Claude Code

Набор скиллов от практикума «Claude и вайбкодинг» (NEXTGEN).
Личные данные, ключи и токены вырезаны и заменены на плейсхолдеры.

## Установка (2 минуты)
1. Распакуй архив.
2. Скопируй ВСЕ папки из `skills/` в свою папку скиллов:
   - Windows: C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\.claude\skills\
   - Mac: ~/.claude/skills/
3. Перезапусти Claude Code.

Ставь почти весь набор - они не мешают друг другу, Claude сам берёт нужный.

## Обязательно поставь ещё (это плагины, не скиллы)
- claude-mem (память между сессиями): /plugin install claude-mem
- GSD (фреймворк разработки): npx @opengsd/gsd-core@latest (репо github.com/open-gsd/gsd-core)
- Базовые скиллы Anthropic для документов (Word, Excel, PowerPoint, PDF):
    /plugin marketplace add anthropics/skills
    /plugin install document-skills@anthropic-agent-skills

## Плейсхолдеры
Часть скиллов требует ТВОИХ ключей: ищи метки [ВСТАВЬ_СВОЙ_КЛЮЧ], [ВАШЕ ФИО] и т.п.
Нужен свой ключ/настройка: image-pro (API), google-workspace (Google).

## Что внутри (22)
- autonomous-deploy
- autoresearch
- content-pro
- content-radar
- contract-generator
- design-taste-frontend
- google-workspace
- high-end-visual-design
- humanizer
- image-pro
- kinolanding
- llm-council
- nda-onboarding
- prompt-engineer
- redesign-existing-projects
- reels-content
- reels-viewer
- security-guard
- skill-selector
- whisper-transcribe
- youtube-analyzer
- zoom-transcripts
