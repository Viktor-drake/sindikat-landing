# Стартовый пак скиллов для Claude Code

Набор скиллов от практикума «Claude и вайбкодинг» (NEXTGEN).
Все личные данные, ключи и токены вырезаны и заменены на плейсхолдеры.

## Установка (2 минуты)

1. Распакуй этот архив.
2. Скопируй ВСЕ папки из `skills/` в свою папку скиллов Claude Code:
   - Windows: C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\.claude\skills\
   - Mac: ~/.claude/skills/
3. Перезапусти Claude Code. Скиллы подхватятся автоматически.

## Важно: плейсхолдеры

Часть скиллов требует ТВОИХ ключей и настроек. Открой файл скилла и найди метки:
- [ВСТАВЬ_СВОЙ_КЛЮЧ] - впиши свой API-ключ
- [ВСТАВЬ_СВОЙ_ТОКЕН] / [ВСТАВЬ_BOT_TOKEN] - свой токен
- [ВАШ_CHAT_ID], [ВАШ_КАНАЛ], [ВАШ_USERNAME] - свои данные Telegram
- [ВАШЕ ФИО], [ВАШ ОГРНИП], [ВАШ ТЕЛЕФОН], [ВАШ EMAIL] - свои реквизиты (для договоров)
- ВАШ_ПОЛЬЗОВАТЕЛЬ - имя твоего пользователя Windows в путях

Скиллы, которым нужен свой ключ/настройка: image-pro (API kie.ai или OpenAI),
google-workspace (доступ Google), telegram-* (свой Telegram MCP),
blog-publish / autonomous-deploy (свои токены и проекты).

Контент-скиллы (content-pro, nextgen-content и т.п.) заточены под бренд - поправь
примеры и тон под свой проект.

## Что внутри (34)

- ai-digest
- anomaly-monitor
- autonomous-deploy
- autoresearch
- blog-publish
- brain
- content-pro
- content-radar
- contract-generator
- design-taste-frontend
- google-workspace
- high-end-visual-design
- humanizer
- image-pro
- kinolanding
- llm-council
- longread-pro
- marcus
- microvolnovka
- nda-onboarding
- nextgen-articles
- nextgen-content
- nextgen-kb
- prompt-engineer
- redesign-existing-projects
- reels-content
- reels-pipeline
- reels-viewer
- security-guard
- skill-selector
- telegram-ai-agent
- telegram-assistant
- youtube-analyzer
- zoom-transcripts

---
Вопросы - на занятии или в чате практикума.
