"""
One-time setup script for contract-generator skill.

Copies the reference template (Договор №101 Заруцкая.docx) into the
skill's templates/ directory as contract_template.docx.

Run once after installing the skill, or any time you want to refresh
the reference template.

Usage (Windows):
    set PYTHONUTF8=1
    py "C:\\Users\\ВАШ_ПОЛЬЗОВАТЕЛЬ\\.claude\\skills\\contract-generator\\scripts\\setup_template.py"
"""
import os
import shutil
import sys

SRC = r'C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\Desktop\Claude Code\Документы\Договора\Договор №101 Заруцкая.docx'
DST = r'C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\.claude\skills\contract-generator\templates\contract_template.docx'


def main() -> int:
    if not os.path.exists(SRC):
        print(f'ERROR: source template not found: {SRC}', file=sys.stderr)
        return 1
    os.makedirs(os.path.dirname(DST), exist_ok=True)
    shutil.copy2(SRC, DST)
    size = os.path.getsize(DST)
    print(f'OK: copied {SRC} -> {DST} ({size} bytes)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
