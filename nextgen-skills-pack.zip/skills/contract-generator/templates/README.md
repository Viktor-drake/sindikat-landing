# templates/

Здесь должен лежать эталонный шаблон договора:

- `contract_template.docx` — копия `Договор №101 Заруцкая.docx`

## Если файла нет — запустите установщик

```bash
set PYTHONUTF8=1
py "C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\.claude\skills\contract-generator\scripts\setup_template.py"
```

Скрипт скопирует актуальный эталон из
`C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\Desktop\Claude Code\Документы\Договора\Договор №101 Заруцкая.docx`
в этот каталог под именем `contract_template.docx`.
