---
name: google-workspace
description: >
  Создание и редактирование Google Документов и Google Таблиц прямо из Claude Code.
  Создаёт Docs/Sheets через Google Drive MCP (под аккаунтом Виктора), правит их
  содержимое через сервисный аккаунт (Docs API + Sheets API). Используй ВСЕГДА когда
  Виктор просит: «создай гугл-док», «новая таблица», «впиши в таблицу», «отредактируй
  документ», «добавь строки в гугл-таблицу», «заполни Google Sheets», «поправь текст
  в гугл-доке», «создай гугл-документ», «занеси данные в таблицу», «сделай табличку
  в гугле», «прочитай гугл-таблицу/документ». Триггеры: «гугл-док», «гугл-таблица»,
  «google docs», «google sheets», «гугл-документ», «спредшит», ссылки вида
  docs.google.com/document или docs.google.com/spreadsheets.
user_invocable: true
---

# Google Workspace — Docs и Sheets из Claude Code

Навык даёт создавать и править Google Документы и Таблицы без браузера.
Архитектура из двух частей (проверена и работает):

| Операция | Чем делается | Под кем |
|---|---|---|
| **Создать** Doc/Sheet/папку | Google Drive MCP (`create_file`) | личный аккаунт Виктора (`[ВАШ EMAIL]`) |
| **Править / читать** содержимое | `scripts/gworkspace.py` (Docs API + Sheets API) | сервисный аккаунт |

**Почему так:** у сервисных аккаунтов Google Drive-квота = 0, они не могут
создавать файлы, но прекрасно правят то, что на них расшарено. Создание берёт
на себя Drive MCP (аккаунт Виктора, где квота есть).

## Ключевые константы

- Сервисный аккаунт (email для шаринга):
  `claude-sheets@gen-lang-client-0829978765.iam.gserviceaccount.com`
- Ключ: `C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\Desktop\Claude Code\System\google-sheets-mcp\service-account.json`
- Рабочая папка **Claude Tables** (расшарена на сервисник как Editor):
  id `1MHO1lTiMXG2nULy_eV2inmTfb8JmqdTH`

## Правило доступа (важно!)

Сервисник правит ТОЛЬКО файлы, расшаренные на его email, или лежащие в
**расшаренной на него папке** Claude Tables.

- Новые файлы создавай **сразу в папку Claude Tables** (`parentId` = id папки) —
  они автоматически наследуют доступ, отдельно шарить не нужно.
- Если Виктор даёт ссылку на таблицу/док ВНЕ этой папки и правка падает с
  `404` / `403 permission` — значит файл не расшарен. Попроси Виктора один раз
  нажать «Поделиться» на этом файле (или его папке) и вставить email сервисника
  с правами Editor. Сам шаринг ты сделать не можешь — это его клик.

---

## Как СОЗДАВАТЬ (через Drive MCP)

Используй инструмент Google Drive MCP `create_file`. Всегда клади в папку Claude Tables.

Google-таблица:
```
create_file(title="Название", contentMimeType="application/vnd.google-apps.spreadsheet",
            parentId="1MHO1lTiMXG2nULy_eV2inmTfb8JmqdTH")
```
Google-документ:
```
create_file(title="Название", contentMimeType="application/vnd.google-apps.document",
            parentId="1MHO1lTiMXG2nULy_eV2inmTfb8JmqdTH")
```
В ответе придёт `id` и `viewUrl` — сохрани id, дальше правь содержимое скриптом.
Дай Виктору кликабельную `viewUrl`.

> Если Drive MCP недоступен в сессии — попроси Виктора создать пустой Doc/Sheet
> вручную в папке Claude Tables и прислать ссылку; дальше правь скриптом.

---

## Как ПРАВИТЬ / ЧИТАТЬ (через gworkspace.py)

Все правки — через один скрипт. Шаблон запуска (PowerShell):

```powershell
uv run --with google-api-python-client --with google-auth `
  python "C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\.claude\skills\google-workspace\scripts\gworkspace.py" `
  <команда> <id-или-URL> [опции]
```

`id` можно давать как чистый id, так и как полную ссылку docs.google.com — скрипт
сам извлечёт id. Все команды печатают JSON-результат.

### Google Docs
| Команда | Что делает |
|---|---|
| `docs-read <id>` | вернуть заголовок и весь текст |
| `docs-append <id> --text "..."` | дописать текст в конец |
| `docs-replace <id> --find "..." --replace "..." [--ignore-case]` | заменить все вхождения |
| `docs-clear <id> [--text "..."]` | очистить весь текст (и опц. вписать новый) |

Полная перезапись документа = `docs-clear <id> --text "новый текст"`.

### Google Sheets
| Команда | Что делает |
|---|---|
| `sheet-tabs <id>` | список листов (вкладок) |
| `sheet-read <id> --range "A1:D10"` | прочитать диапазон |
| `sheet-write <id> --range "A1" --values-json '[["a","b"],["c","d"]]'` | записать значения |
| `sheet-append <id> --range "A1" --values-json '[["x","y"]]'` | добавить строки в конец |
| `sheet-clear <id> --range "A1:D100"` | очистить диапазон |

Диапазон с конкретным листом: `"Лист1!A1:D10"`. `values-json` — это JSON-массив
строк. Формулы и числа понимаются автоматически (valueInputOption=USER_ENTERED).

### Служебные
| Команда | Что делает |
|---|---|
| `list-folder [--folder <id>]` | что лежит в папке Claude Tables (или другой) |
| `meta <id>` | имя, тип, ссылка, можно ли редактировать |
| `whoami` | email и проект сервисника |

---

## Типовой сценарий

1. Виктор: «сделай таблицу с лидами за неделю и впиши шапку».
2. `create_file(...spreadsheet..., parentId=папка)` → получаешь id + viewUrl.
3. `gworkspace.py sheet-write <id> --range A1 --values-json '[["Имя","Телефон","Статус"]]'`.
4. Отдаёшь Виктору ссылку viewUrl.

Для документа аналогично: создал через Drive MCP → наполнил через `docs-clear/append`.

## Диагностика ошибок
- `404 File not found` или `403 permission` при правке → файл не расшарен на
  сервисник. Решение: создать его в папке Claude Tables ИЛИ попросить Виктора
  расшарить файл/папку на email сервисника (Editor).
- `whoami` покажет, тот ли ключ подхватился.
- `list-folder` покажет, что сервисник реально видит в папке.

## Стиль ответа Виктору
Коротко, по делу. Всегда давай кликабельную ссылку на созданный/изменённый файл.
Не отправляй Виктора в консоль — все правки делай сам через скрипт.
