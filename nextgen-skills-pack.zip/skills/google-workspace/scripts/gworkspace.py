#!/usr/bin/env python
"""
gworkspace.py — единый CLI для правки Google Docs и Google Sheets
через сервисный аккаунт (Service Account).

Запуск (зависимости тянутся на лету через uv):
    uv run --with google-api-python-client --with google-auth \
        python gworkspace.py <команда> [аргументы]

Авторизация: путь к ключу берётся из env GWS_SA, иначе из дефолта ниже.
Сервисник может ПРАВИТЬ/ЧИТАТЬ только файлы, расшаренные на его email
(или лежащие в расшаренной на него папке). СОЗДАВАТЬ файлы он не может
(Drive-квота сервисников = 0) — создание идёт через Google Drive MCP.

ID можно передавать как чистый id, так и как полный URL документа/таблицы —
скрипт сам вытащит id.
"""
import argparse
import json
import os
import re
import sys

DEFAULT_SA = r"C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\Desktop\Claude Code\System\google-sheets-mcp\service-account.json"
DEFAULT_FOLDER = "1MHO1lTiMXG2nULy_eV2inmTfb8JmqdTH"  # папка "Claude Tables"

SCOPES = [
    "https://www.googleapis.com/auth/documents",
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]


def _creds():
    from google.oauth2 import service_account
    sa = os.environ.get("GWS_SA", DEFAULT_SA)
    return service_account.Credentials.from_service_account_file(sa, scopes=SCOPES)


def _id(raw):
    """Принимает id или URL, возвращает чистый id."""
    if not raw:
        return raw
    m = re.search(r"/(?:document|spreadsheets)/d/([a-zA-Z0-9_-]+)", raw)
    if m:
        return m.group(1)
    m = re.search(r"/folders/([a-zA-Z0-9_-]+)", raw)
    if m:
        return m.group(1)
    return raw.strip()


def _out(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


# ---------- DOCS ----------

def _docs():
    from googleapiclient.discovery import build
    return build("docs", "v1", credentials=_creds())


def _doc_text(doc):
    out = []
    for el in doc.get("body", {}).get("content", []):
        para = el.get("paragraph")
        if not para:
            continue
        for e in para.get("elements", []):
            out.append(e.get("textRun", {}).get("content", ""))
    return "".join(out)


def docs_read(args):
    d = _docs().documents().get(documentId=_id(args.id)).execute()
    _out({"title": d.get("title"), "text": _doc_text(d)})


def docs_append(args):
    svc = _docs()
    d = svc.documents().get(documentId=_id(args.id)).execute()
    end = d["body"]["content"][-1]["endIndex"] - 1  # перед финальным переводом строки
    svc.documents().batchUpdate(
        documentId=_id(args.id),
        body={"requests": [{"insertText": {"location": {"index": end}, "text": args.text}}]},
    ).execute()
    _out({"ok": True, "action": "append", "chars": len(args.text)})


def docs_replace(args):
    res = _docs().documents().batchUpdate(
        documentId=_id(args.id),
        body={"requests": [{"replaceAllText": {
            "containsText": {"text": args.find, "matchCase": not args.ignore_case},
            "replaceText": args.replace,
        }}]},
    ).execute()
    n = res.get("replies", [{}])[0].get("replaceAllText", {}).get("occurrencesChanged", 0)
    _out({"ok": True, "action": "replace", "occurrences": n})


def docs_clear(args):
    svc = _docs()
    d = svc.documents().get(documentId=_id(args.id)).execute()
    end = d["body"]["content"][-1]["endIndex"] - 1
    reqs = []
    if end > 1:
        reqs.append({"deleteContentRange": {"range": {"startIndex": 1, "endIndex": end}}})
    if args.text:
        reqs.append({"insertText": {"location": {"index": 1}, "text": args.text}})
    if reqs:
        svc.documents().batchUpdate(documentId=_id(args.id), body={"requests": reqs}).execute()
    _out({"ok": True, "action": "clear", "wrote": bool(args.text)})


# ---------- SHEETS ----------

def _sheets():
    from googleapiclient.discovery import build
    return build("sheets", "v4", credentials=_creds())


def sheet_read(args):
    r = _sheets().spreadsheets().values().get(
        spreadsheetId=_id(args.id), range=args.range).execute()
    _out({"range": r.get("range"), "values": r.get("values", [])})


def sheet_write(args):
    vals = json.loads(args.values_json)
    _sheets().spreadsheets().values().update(
        spreadsheetId=_id(args.id), range=args.range,
        valueInputOption="USER_ENTERED", body={"values": vals}).execute()
    _out({"ok": True, "action": "write", "rows": len(vals)})


def sheet_append(args):
    vals = json.loads(args.values_json)
    _sheets().spreadsheets().values().append(
        spreadsheetId=_id(args.id), range=args.range,
        valueInputOption="USER_ENTERED", insertDataOption="INSERT_ROWS",
        body={"values": vals}).execute()
    _out({"ok": True, "action": "append", "rows": len(vals)})


def sheet_clear(args):
    _sheets().spreadsheets().values().clear(
        spreadsheetId=_id(args.id), range=args.range).execute()
    _out({"ok": True, "action": "clear", "range": args.range})


def sheet_tabs(args):
    meta = _sheets().spreadsheets().get(spreadsheetId=_id(args.id)).execute()
    tabs = [s["properties"]["title"] for s in meta.get("sheets", [])]
    _out({"title": meta.get("properties", {}).get("title"), "tabs": tabs})


# ---------- DRIVE (meta / list) ----------

def _drive():
    from googleapiclient.discovery import build
    return build("drive", "v3", credentials=_creds())


def meta(args):
    m = _drive().files().get(
        fileId=_id(args.id),
        fields="id,name,mimeType,capabilities(canEdit),webViewLink").execute()
    _out(m)


def list_folder(args):
    fid = _id(args.folder) if args.folder else DEFAULT_FOLDER
    q = "'%s' in parents and trashed = false" % fid
    r = _drive().files().list(q=q, fields="files(id,name,mimeType,webViewLink)").execute()
    _out({"folder": fid, "files": r.get("files", [])})


def whoami(args):
    sa = os.environ.get("GWS_SA", DEFAULT_SA)
    with open(sa, encoding="utf-8") as f:
        j = json.load(f)
    _out({"client_email": j.get("client_email"), "project_id": j.get("project_id")})


def main():
    p = argparse.ArgumentParser(description="Google Docs/Sheets editor via service account")
    sub = p.add_subparsers(dest="cmd", required=True)

    def add(name, fn, *fields):
        sp = sub.add_parser(name)
        sp.set_defaults(func=fn)
        for f in fields:
            if f == "id":
                sp.add_argument("id", help="id или URL документа/таблицы")
            elif f == "range":
                sp.add_argument("--range", required=True, help="напр. Лист1!A1:D10 или A1")
            elif f == "values":
                sp.add_argument("--values-json", required=True, help='JSON: [["a","b"],["c"]]')
            elif f == "text":
                sp.add_argument("--text", required=True)
            elif f == "text_opt":
                sp.add_argument("--text", default="", help="текст после очистки (опц.)")
            elif f == "find":
                sp.add_argument("--find", required=True)
                sp.add_argument("--replace", required=True)
                sp.add_argument("--ignore-case", action="store_true")
            elif f == "folder":
                sp.add_argument("--folder", help="id/URL папки (по умолчанию Claude Tables)")
        return sp

    add("docs-read", docs_read, "id")
    add("docs-append", docs_append, "id", "text")
    add("docs-replace", docs_replace, "id", "find")
    add("docs-clear", docs_clear, "id", "text_opt")
    add("sheet-read", sheet_read, "id", "range")
    add("sheet-write", sheet_write, "id", "range", "values")
    add("sheet-append", sheet_append, "id", "range", "values")
    add("sheet-clear", sheet_clear, "id", "range")
    add("sheet-tabs", sheet_tabs, "id")
    add("meta", meta, "id")
    add("list-folder", list_folder, "folder")
    add("whoami", whoami)

    args = p.parse_args()
    try:
        args.func(args)
    except Exception as e:
        from googleapiclient.errors import HttpError
        if isinstance(e, HttpError):
            _out({"ok": False, "status": e.resp.status, "error": e._get_reason()})
        else:
            _out({"ok": False, "error": str(e)})
        sys.exit(1)


if __name__ == "__main__":
    main()
