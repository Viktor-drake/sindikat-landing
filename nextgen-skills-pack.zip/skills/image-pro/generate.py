"""
image-pro generator — Kie.ai GPT Image 2 (text-to-image + image-to-image)
Качество вытягивается развёрнутым промптом (это делает скилл) + resolution 2K.

Использование:
  python generate.py --prompt "детальный английский промпт" [--aspect 16:9] [--res 2K] [--out папка] [--ref путь_к_референсу]
"""

import os
import sys
import json
import time
import argparse
import requests
from pathlib import Path
from datetime import datetime

BASE_URL = "https://api.kie.ai/api/v1/jobs"

# .env-локации, где может лежать KIE_API_KEY (секрет не дублируем — переиспользуем существующий)
ENV_CANDIDATES = [
    Path(__file__).parent / ".env",
    Path(r"C:/Users/ВАШ_ПОЛЬЗОВАТЕЛЬ/Desktop/Claude Code/Active Projects/tg-content/.env"),
    Path(r"C:/Users/ВАШ_ПОЛЬЗОВАТЕЛЬ/Desktop/Claude Code/Active Projects/SEO Growth Machine/.env"),
]


def load_key() -> str:
    key = os.environ.get("KIE_API_KEY", "")
    if key:
        return key
    for env_path in ENV_CANDIDATES:
        try:
            if env_path.exists() and env_path.stat().st_size > 0:
                for line in env_path.read_text(encoding="utf-8-sig").splitlines():
                    line = line.strip()
                    if line.startswith("KIE_API_KEY") and "=" in line:
                        return line.split("=", 1)[1].strip()
        except Exception:
            continue
    return ""


def upload_image(image_path: str) -> str:
    """Загружает локальный референс и возвращает публичный URL для i2i."""
    for name, fn in (("0x0.st", _up_0x0), ("tmpfiles.org", _up_tmpfiles)):
        try:
            url = fn(image_path)
            if url:
                print(f"Референс загружен ({name}): {url}")
                return url
        except Exception as e:
            print(f"{name} не сработал: {e}")
    raise Exception("Не удалось загрузить референс. Дай прямой URL или убери --ref.")


def _up_0x0(image_path: str):
    with open(image_path, "rb") as f:
        r = requests.post("https://0x0.st", files={"file": f}, timeout=30)
    if r.status_code == 200 and r.text.startswith("http"):
        return r.text.strip()
    return None


def _up_tmpfiles(image_path: str):
    with open(image_path, "rb") as f:
        r = requests.post("https://tmpfiles.org/api/v1/upload", files={"file": f}, timeout=30)
    data = r.json()
    if data.get("status") == "success":
        return data["data"]["url"].replace("tmpfiles.org/", "tmpfiles.org/dl/")
    return None


def create_task(key, prompt, aspect, res, ref_urls=None) -> str:
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    if ref_urls:
        payload = {
            "model": "gpt-image-2-image-to-image",
            "input": {"prompt": prompt, "input_urls": ref_urls,
                      "aspect_ratio": aspect, "resolution": res},
        }
    else:
        payload = {
            "model": "gpt-image-2-text-to-image",
            "input": {"prompt": prompt, "aspect_ratio": aspect, "resolution": res},
        }
    r = requests.post(f"{BASE_URL}/createTask", headers=headers, json=payload, timeout=30)
    data = r.json()
    if data.get("code") != 200:
        raise Exception(f"Ошибка создания задачи: {data}")
    tid = data["data"]["taskId"]
    print(f"Задача создана: {tid}")
    return tid


def wait_for_result(key, task_id, timeout=300) -> str:
    headers = {"Authorization": f"Bearer {key}"}
    start = time.time()
    while time.time() - start < timeout:
        r = requests.get(f"{BASE_URL}/recordInfo", headers=headers,
                         params={"taskId": task_id}, timeout=30)
        data = r.json()
        state = data["data"].get("state")
        print(f"Статус: {state}...")
        if state == "success":
            return json.loads(data["data"]["resultJson"])["resultUrls"][0]
        if state == "fail":
            raise Exception(f"Задача провалилась: {data['data'].get('failMsg')}")
        time.sleep(5)
    raise Exception("Таймаут ожидания результата")


def download(url, out_dir, prompt) -> Path:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    slug = "".join(c for c in prompt[:40] if c.isalnum() or c in " -_").strip().replace(" ", "_")
    fname = out / f"{ts}_{slug or 'image'}.png"
    fname.write_bytes(requests.get(url, timeout=60).content)
    print(f"Сохранено: {fname}")
    return fname


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--prompt", required=True, help="Развёрнутый английский промпт")
    p.add_argument("--aspect", default="1:1", help="1:1 | 9:16 | 16:9 | 3:2 | 2:3")
    p.add_argument("--res", default="2K", help="2K (макс) | 1K (быстро)")
    p.add_argument("--out", default=str(Path(__file__).parent / "visuals"))
    p.add_argument("--ref", default=None, help="Путь к референсу (включает i2i)")
    args = p.parse_args()

    key = load_key()
    if not key:
        print("ERROR: KIE_API_KEY не найден (ни в env, ни в .env проектов).")
        sys.exit(1)

    print(f"Генерирую [{args.aspect}, {args.res}]: {args.prompt[:80]}...")
    ref_urls = [upload_image(args.ref)] if args.ref else None
    tid = create_task(key, args.prompt, args.aspect, args.res, ref_urls)
    url = wait_for_result(key, tid)
    print(f"Готово: {url}")
    path = download(url, args.out, args.prompt)
    print(f"\nРезультат: {path}")


if __name__ == "__main__":
    main()
