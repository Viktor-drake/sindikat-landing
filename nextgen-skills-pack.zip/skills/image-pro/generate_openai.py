"""
image-pro — НАТИВНЫЙ OpenAI генератор (как в ChatGPT).
Альтернатива generate.py (kie.ai). Качество = чату, т.к. это прямой OpenAI API
с quality=high. Нужен OPENAI_API_KEY.

ВАЖНО: точный id модели подтвердить при подключении ключа (gpt-image-2 / gpt-image-1).
Меняется в константе MODEL ниже.

Использование:
  python generate_openai.py --prompt "детальный английский промпт" [--aspect 16:9] [--quality high] [--out папка] [--ref путь]
"""

import os
import sys
import time
import base64
import argparse
import requests
from pathlib import Path
from datetime import datetime

RETRIES = 6  # прокси для OpenAI из РФ рвёт длинные соединения — повторяем, пока не удержит рендер


def _post_with_retries(do_request):
    """Повторяет синхронный запрос к OpenAI, пока нестабильный прокси не удержит
    соединение на полный рендер. Возвращает распарсенный JSON."""
    last = None
    for attempt in range(1, RETRIES + 1):
        try:
            r = do_request()
            return r.json()
        except (requests.exceptions.ProxyError,
                requests.exceptions.ConnectionError,
                requests.exceptions.Timeout) as e:
            last = e
            print(f"  попытка {attempt}/{RETRIES}: прокси оборвал соединение, повтор...")
            time.sleep(3)
    raise Exception(f"Прокси не удержал соединение за {RETRIES} попыток: {last}")

MODEL = "gpt-image-2"  # при подключении ключа сверить с platform.openai.com (может быть gpt-image-1)
API_URL = "https://api.openai.com/v1/images/generations"
EDIT_URL = "https://api.openai.com/v1/images/edits"

# size по соотношению сторон (поддерживаемые OpenAI размеры)
SIZE_BY_ASPECT = {
    "1:1": "1024x1024",
    "16:9": "1536x1024",
    "9:16": "1024x1536",
    "3:2": "1536x1024",
    "2:3": "1024x1536",
}

ENV_CANDIDATES = [
    Path(__file__).parent / ".env",
    Path(r"C:/Users/ВАШ_ПОЛЬЗОВАТЕЛЬ/Desktop/Claude Code/Active Projects/tg-content/.env"),
    Path(r"C:/Users/ВАШ_ПОЛЬЗОВАТЕЛЬ/.claude/.env"),
]


def load_key() -> str:
    key = os.environ.get("OPENAI_API_KEY", "")
    if key:
        return key
    for env_path in ENV_CANDIDATES:
        try:
            if env_path.exists() and env_path.stat().st_size > 0:
                for line in env_path.read_text(encoding="utf-8-sig").splitlines():
                    line = line.strip()
                    if line.startswith("OPENAI_API_KEY") and "=" in line:
                        return line.split("=", 1)[1].strip()
        except Exception:
            continue
    return ""


def save_b64(b64, out_dir, prompt) -> Path:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    slug = "".join(c for c in prompt[:40] if c.isalnum() or c in " -_").strip().replace(" ", "_")
    fname = out / f"{ts}_{slug or 'image'}.png"
    fname.write_bytes(base64.b64decode(b64))
    print(f"Сохранено: {fname}")
    return fname


def generate(key, prompt, size, quality, out_dir):
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    payload = {"model": MODEL, "prompt": prompt, "size": size, "quality": quality, "n": 1}
    data = _post_with_retries(lambda: requests.post(API_URL, headers=headers, json=payload, timeout=300))
    if "data" not in data:
        raise Exception(f"Ошибка OpenAI: {data}")
    return save_b64(data["data"][0]["b64_json"], out_dir, prompt)


def edit(key, prompt, size, quality, ref_path, out_dir):
    headers = {"Authorization": f"Bearer {key}"}
    ref_bytes = Path(ref_path).read_bytes()
    ref_name = Path(ref_path).name

    def do():
        files = {"image[]": (ref_name, ref_bytes, "image/png")}
        form = {"model": MODEL, "prompt": prompt, "size": size, "quality": quality, "n": "1"}
        return requests.post(EDIT_URL, headers=headers, data=form, files=files, timeout=300)

    data = _post_with_retries(do)
    if "data" not in data:
        raise Exception(f"Ошибка OpenAI (edit): {data}")
    return save_b64(data["data"][0]["b64_json"], out_dir, prompt)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--prompt", required=True)
    p.add_argument("--aspect", default="1:1")
    p.add_argument("--quality", default="high", help="high | medium | low")
    p.add_argument("--out", default=str(Path(__file__).parent / "visuals"))
    p.add_argument("--ref", default=None, help="Путь к референсу (использует /images/edits)")
    args = p.parse_args()

    key = load_key()
    if not key:
        print("ERROR: OPENAI_API_KEY не найден. Создай ключ на platform.openai.com и положи в .env")
        sys.exit(1)

    size = SIZE_BY_ASPECT.get(args.aspect, "1024x1024")
    print(f"OpenAI {MODEL} [{size}, quality={args.quality}]: {args.prompt[:80]}...")
    if args.ref:
        path = edit(key, args.prompt, size, args.quality, args.ref, args.out)
    else:
        path = generate(key, args.prompt, size, args.quality, args.out)
    print(f"\nРезультат: {path}")


if __name__ == "__main__":
    main()
