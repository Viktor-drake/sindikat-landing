---
name: kinolanding
description: Собрать кинематографичный скролл-лендинг в Claude Code с AI-видео-героем (облёт камеры, драматичный свет) через Higgsfield. Уровень «дизайн-студия», но за вечер и без студии. Используй, когда нужно сделать вау-лендинг: продуктовый запуск, личный бренд, промо.
---

# Кинолендинг — кинематографичный сайт в Claude Code за вечер

Лид-магнит NextGen ([ВАШЕ ИМЯ]). По кодовому слову **КИНО**.

Это рецепт, как собрать сайт уровня кинопрезентации: тёмный, с драматичным героем-видео (облёт камеры вокруг объекта, дым, свет) и плавным «киношным» скроллом. Секрет, который не виден со стороны: **герой это не 3D, а AI-видео**, которое генерится в Higgsfield и вшивается в сайт, а Claude собирает вокруг него весь фронтенд.

## Что получается
Одностраничный лендинг: видео-герой на весь экран, который **проматывается скроллом** (кадр видео привязан к позиции скролла), плавная прокрутка, секции с анимацией появления, кинематографичная типографика, CTA. Стек бесплатный и открытый.

## Стек (всё опенсорс)
- **Vite + React** — каркас.
- **GSAP + ScrollTrigger** — анимации по скроллу.
- **Lenis** — плавный «инерционный» скролл (даёт киношность).
- **Tailwind + shadcn/ui** — типографика и UI.
- **Higgsfield** (через MCP в Claude Code) — генерация видео-героя (Kling / Seedance 2.0 / Veo / Sora) и картинок.
- Node 20+.

## Шаг 0. Подключить Higgsfield к Claude Code (один раз)
Нужна активная подписка Higgsfield.
```
claude mcp add --transport http --scope user higgsfield https://mcp.higgsfield.ai/mcp
/mcp
```
В `/mcp` войти в аккаунт Higgsfield (OAuth), перезапустить Claude Code. Проверка: «спроси у higgsfield баланс аккаунта».

## Шаг 1. Бриф-файл (скилл проекта) — пишем ДО старта
Claude собирает лендинг кратно лучше, если дать ему производственный бриф. Создай `BRIEF.md` в проекте:
- бренд, настроение, референсы (2-3 ссылки на awwwards-сайты);
- структура секций (герой → проблема → продукт → соцдоказательство → CTA);
- список ассетов и точные промпты под них;
- промпт под видео-героя (см. Шаг 2);
- стек (выше) и требования к скролл-анимации;
- чек-лист приёмки.
Загрузи `BRIEF.md` в Claude Code перед работой.

## Шаг 2. Сгенерировать видео-героя (Higgsfield)
Сначала ключевой кадр-картинку (для консистентности), потом видео по ней. Формула промпта (MCSLA): **модель + пресет камеры + объект + свет/стиль + действие**.

Пример промпта видео (Kling / Seedance 2.0 через Higgsfield):
> «Cinematic hyper-detailed [объект] on dark background, slow orbit + push-in camera, volumetric smoke, dramatic rim light, particles, 9:16, 4-6 сек, бесшовный луп».

Просьба в Claude Code: «Use higgsfield to generate a cinematic hero video: [промпт выше]». Higgsfield покажет стоимость в кредитах до генерации. Скачать готовый mp4 в `public/hero.mp4`.

## Шаг 3. Собрать сайт (главный приём — скролл-скраб видео)
Дать Claude Code задачу собрать Vite+React+GSAP+Lenis и привязать `currentTime` видео к скроллу. Ядро приёма:
```jsx
// Lenis + GSAP ScrollTrigger: кадр видео = позиция скролла
import Lenis from '@studio-freight/lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);

const lenis = new Lenis({ smoothWheel: true });
function raf(t){ lenis.raf(t); requestAnimationFrame(raf); } requestAnimationFrame(raf);

const video = document.querySelector('#hero-video'); // muted playsInline preload="auto"
video.pause();
video.addEventListener('loadedmetadata', () => {
  gsap.to(video, {
    currentTime: video.duration,
    ease: 'none',
    scrollTrigger: { trigger: '#hero', start: 'top top', end: '+=2000', scrub: true, pin: true },
  });
});
```
Дальше Claude добавляет: секции с `ScrollTrigger` (fade/slide появление), кинематографичную типографику (крупный засечный или Onest, большие межстрочные), тёмный фон + один акцентный цвет, CTA. Видео `muted playsInline preload="auto"`, иначе скраб не работает на мобиле.

## Шаг 4. Финал
- Проверить на телефоне (скролл-скраб капризен на мобиле: видео muted+inline, лёгкий вес, H.264).
- Деплой на Vercel.
- Подложить под героя 1-2 секции с реальной выгодой, иначе «красиво, но пусто».

## Стартовый промпт для Claude Code (копировать)
> «Прочитай BRIEF.md. Собери одностраничный кинематографичный лендинг: Vite + React + Tailwind + GSAP/ScrollTrigger + Lenis. Герой — видео `public/hero.mp4` на весь экран, проматываемое скроллом (currentTime привязан к scroll через ScrollTrigger scrub, секция запинена). Плавный скролл через Lenis. Тёмная тема, один акцентный цвет, крупная кинематографичная типографика, секции с анимацией появления, финальный CTA. Видео muted playsInline preload=auto. Проверь на мобиле.»

## Честно
Нужна подписка Higgsfield (видео платное по кредитам, цену MCP показывает заранее). Скролл-скраб видео капризен на мобиле — тестировать обязательно. Это не «одна кнопка», но реально вечер вместо студии за сотни тысяч.

## Источники-связки (опенсорс, для углубления)
- Higgsfield MCP для Claude Code: github.com/robonuggets/higgsfield-skill
- Higgsfield Claude skills (Seedance/Kling промпты): github.com/AKCodez/higgsfield-claude-skills, github.com/OSideMedia/higgsfield-ai-prompt-skill

Финал воронки: Telegram-канал https://t.me/[ВАШ_КАНАЛ]

---
## Как этот скилл стыкуется с дизайн-паком (роутер)
Когда нужен лендинг с кинематографичным видео-героем → kinolanding даёт технику (видео-скраб + Lenis + Higgsfield), а `design-taste-frontend` / `high-end-visual-design` дают вкус и дисциплину остальных секций под видео. То есть kinolanding = механика героя, taste-скиллы = качество всего вокруг. Связано с [[feedback_design_skill_routing]].
