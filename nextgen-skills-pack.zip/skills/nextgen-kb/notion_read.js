#!/usr/bin/env node
/**
 * NextGen KB Reader — читает публичную статью Notion по ссылке/ID и печатает
 * чистый markdown, ВКЛЮЧАЯ код-блоки (которые теряет Jina Reader).
 *
 * Использует внутренний публичный API Notion loadPageChunk: работает без
 * авторизации и без коннектора, с любого аккаунта, для любой страницы,
 * открытой по ссылке ("Share to web").
 *
 * Запуск:  node notion_read.js <url-или-id-статьи>
 * Требует: Node 18+ (глобальный fetch). У всех пользователей Claude Code он есть.
 */

const arg = process.argv[2];
if (!arg) {
  console.error('Использование: node notion_read.js <url-или-id-статьи-Notion>');
  process.exit(2);
}

// --- 1. Вытащить 32-символьный hex-id и привести к UUID ---
function toUuid(input) {
  const m = String(input).match(/[0-9a-fA-F]{32}/g);
  if (!m) {
    // вдруг уже передали UUID с дефисами
    const u = String(input).match(/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/);
    if (u) return u[0];
    return null;
  }
  const hex = m[m.length - 1]; // id страницы — последний hex в ссылке
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
}

const pageId = toUuid(arg);
if (!pageId) {
  console.error('Не нашёл ID страницы в: ' + arg);
  process.exit(2);
}

// --- 2. Забрать все блоки страницы (с пагинацией по cursor) ---
async function loadAllBlocks(id) {
  const blocks = {};
  let cursor = { stack: [] };
  for (let i = 0; i < 100; i++) { // защита от бесконечного цикла
    const res = await fetch('https://www.notion.so/api/v3/loadPageChunk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0' },
      body: JSON.stringify({ pageId: id, limit: 100, cursor, chunkNumber: 0, verticalColumns: false }),
    });
    if (!res.ok) throw new Error('Notion API вернул HTTP ' + res.status);
    const data = await res.json();
    const got = (data.recordMap && data.recordMap.block) || {};
    for (const [bid, wrap] of Object.entries(got)) {
      const v = wrap.value && (wrap.value.value || wrap.value);
      if (v && v.id) blocks[bid] = v;
    }
    cursor = data.cursor;
    if (!cursor || !cursor.stack || cursor.stack.length === 0) break;
  }
  return blocks;
}

// --- 3. Рендер rich-text (берём текст, сохраняем ссылки) ---
function rich(arr) {
  if (!Array.isArray(arr)) return '';
  return arr.map((seg) => {
    let t = seg[0] != null ? seg[0] : '';
    const ann = seg[1] || [];
    for (const a of ann) {
      if (a[0] === 'a' && a[1]) t = `[${t}](${a[1]})`;
    }
    return t;
  }).join('');
}

// --- 4. Обойти дерево блоков по порядку и собрать markdown ---
function render(blocks, rootId) {
  const out = [];
  let numCounter = 0;

  function walk(id, depth) {
    const b = blocks[id];
    if (!b) return;
    const p = b.properties || {};
    const pad = '  '.repeat(depth);
    const txt = rich(p.title);

    switch (b.type) {
      case 'page':
        if (txt) out.push(`# ${txt}\n`);
        break;
      case 'header':        out.push(`\n## ${txt}\n`); break;
      case 'sub_header':    out.push(`\n### ${txt}\n`); break;
      case 'sub_sub_header':out.push(`\n#### ${txt}\n`); break;
      case 'text':          if (txt) out.push(`${txt}\n`); break;
      case 'bulleted_list': out.push(`${pad}- ${txt}`); break;
      case 'numbered_list': out.push(`${pad}${++numCounter}. ${txt}`); break;
      case 'to_do': {
        const done = p.checked && p.checked[0] && p.checked[0][0] === 'Yes';
        out.push(`${pad}- [${done ? 'x' : ' '}] ${txt}`);
        break;
      }
      case 'toggle':        out.push(`${pad}▸ ${txt}`); break;
      case 'quote':         out.push(`> ${txt}\n`); break;
      case 'callout':       out.push(`> ${txt}\n`); break;
      case 'code': {
        const lang = (p.language && p.language[0] && p.language[0][0]) || '';
        out.push('```' + lang.toLowerCase());
        out.push(txt);
        out.push('```\n');
        break;
      }
      case 'divider':       out.push('\n---\n'); break;
      case 'image': {
        const src = (p.source && p.source[0] && p.source[0][0]) ||
                    (b.format && b.format.display_source) || '';
        out.push(`![image](${src})\n`);
        break;
      }
      case 'bookmark': {
        const link = (p.link && p.link[0] && p.link[0][0]) || '';
        out.push(`[${txt || link}](${link})\n`);
        break;
      }
      default:
        if (txt) out.push(`${txt}\n`);
    }

    // нумерация сбрасывается, если список прервался
    if (b.type !== 'numbered_list') numCounter = 0;

    for (const childId of (b.content || [])) walk(childId, depth + (b.type === 'page' ? 0 : 1));
  }

  walk(rootId, 0);
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

(async () => {
  try {
    const blocks = await loadAllBlocks(pageId);
    if (!blocks[pageId]) {
      console.error('Страница не найдена или закрыта. Проверь, что статья открыта по ссылке (Share to web).');
      process.exit(1);
    }
    console.log(render(blocks, pageId));
  } catch (e) {
    console.error('Ошибка чтения: ' + e.message);
    process.exit(1);
  }
})();
