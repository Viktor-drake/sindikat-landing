---
name: reels-viewer
description: >
  Просмотр и разбор Instagram Reels (а также TikTok и любых коротких видео)
  по ссылке: скачивает видео через yt-dlp, извлекает кадры и звук через ffmpeg,
  транскрибирует речь через faster-whisper, читает кадры визуально и отвечает
  на основе РЕАЛЬНОГО содержимого. Используй ВСЕГДА когда пользователь прислал
  ссылку instagram.com/reel, instagram.com/p/, instagram.com/tv/, tiktok.com
  и хочет любой разбор: «посмотри reels», «о чём этот ролик», «разбери reels»,
  «что в видео», «что за инструмент показан», «изучи этот рилс», «транскрибируй»,
  «выжимка», «что говорит автор», «конспект», «формат ролика», «как сделан».
  НЕ используй Chrome MCP и НЕ пересказывай нагугленные статьи как «разбор видео».
  Для YouTube используй скилл youtube-analyzer.
---

# Reels Viewer — правильный просмотр Instagram/TikTok Reels

Claude **не смотрит видео напрямую** и не «открывает» Instagram. Чтобы разобрать
Reels, надо: скачать файл → вытащить кадры (картинка) и звук → транскрибировать
речь → прочитать кадры визуально (multimodal Read). Только так получится разбор
по реальному содержимому, а не по описанию.

## Золотое правило
**Никогда не выдавай пересказ догадок за «разбор видео».** Если скачать не удалось,
скажи прямо и предложи: (а) прислать видео файлом, (б) описать словами. Не использовать
Chrome MCP, не «гадать» по URL.

## Рецепт (Windows, проверено)

### Шаг 1. Скачать видео
```python
import yt_dlp, imageio_ffmpeg, os, shutil
ff = imageio_ffmpeg.get_ffmpeg_exe()
bindir = os.path.join(os.path.dirname(ff), "_ytdlp_bin"); os.makedirs(bindir, exist_ok=True)
if not os.path.exists(os.path.join(bindir, "ffmpeg.exe")): shutil.copy(ff, os.path.join(bindir, "ffmpeg.exe"))
url = "ССЫЛКА"
opts = {"outtmpl": "_reel/v.%(ext)s", "merge_output_format": "mp4",
        "ffmpeg_location": bindir, "overwrites": True, "quiet": True, "no_warnings": True}
with yt_dlp.YoutubeDL(opts) as ydl:
    info = ydl.extract_info(url, download=True)
print(info.get("uploader"), info.get("duration"),
      "likes", info.get("like_count"), "comments", info.get("comment_count"))
print("DESC:", (info.get("description") or "")[:600])   # описание = хук + лид-магнит, часто это и есть суть
```
Если Instagram отдаёт ошибку (приватное/гео/логин): добавь в opts
`"cookiesfrombrowser": ("chrome",)` (или firefox/edge). Публичные приватные ссылки скачать нельзя.

### Шаг 2. Кадры + транскрипт
```python
import imageio_ffmpeg, subprocess, glob
ff = imageio_ffmpeg.get_ffmpeg_exe()
src = glob.glob("_reel/v.*")[0]
# Кадры по таймлайну (подставь моменты под длину ролика)
for t in ["1","8","15","22","28"]:
    subprocess.run([ff,"-y","-ss",t,"-i",src,"-vframes","1","-q:v","3",f"_reel/_f{t}.jpg"], capture_output=True)
# Звук → транскрипт
subprocess.run([ff,"-y","-i",src,"-vn","-ac","1","-ar","16000","_reel/a.wav"], capture_output=True)
from faster_whisper import WhisperModel
m = WhisperModel("medium", device="cpu", compute_type="int8")
segs,_ = m.transcribe("_reel/a.wav", language="ru", beam_size=5, vad_filter=True)  # language="en" для англоязычных
print("\n".join(f"[{int(s.start//60):02d}:{int(s.start%60):02d}] {s.text.strip()}" for s in segs))
```

### Шаг 3. Прочитать кадры
Read каждый `_reel/_f*.jpg` (multimodal) — это даёт визуал: формат (talking-head /
анимация / скринкаст), что на экране, какой инструмент показан, текст-плашки.

### Шаг 4. Собрать разбор
Свести: описание (из шага 1) + транскрипт (шаг 2) + визуал (шаг 3). Часто **главное
в описании** — хук и лид-магнит («пиши X в комменты»), а не в самой картинке.

## Гигиена / авторские права
- Скачанное чужое видео — **временный файл для анализа**. После разбора удалить папку `_reel/`.
- Не публиковать и не выдавать чужой ролик за свой. Для контент-завода: брать формат и
  механику, а не сам файл (см. проект «Контент завод»).

## Зависимости
`pip install yt-dlp faster-whisper imageio-ffmpeg` — обычно уже стоят в окружении Контент-завода.
