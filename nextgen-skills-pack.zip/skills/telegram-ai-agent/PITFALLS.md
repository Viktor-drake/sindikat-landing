# Известные грабли — Telegram AI Agent

Каждый пункт — то, что отжирало время при сборке Marcus Gallup. Перечитать перед каждой новой сборкой.

---

## 🔥 Топ-5 болезненных (главные потери времени)

### 1. Markdown parse_mode в ответах
**Симптом:** `400: Bad Request: can't parse entities: Can't find end of the entity starting at byte offset N`

**Причина:** В `ctx.reply(text, { parse_mode: 'Markdown' })` Telegram парсит угловые скобки `<>`, подчёркивания `_`, звёздочки `*` как разметку. Динамический контент (имена, идентификаторы) ломает парсер.

**Решение:** **НЕ использовать `parse_mode: 'Markdown'`** во всех ответах с пользовательским/динамическим контентом. Только plain text. Если очень нужна разметка — `parse_mode: 'HTML'` и экранировать `<` `>` `&`.

---

### 2. AI clients создаются при загрузке модуля
**Симптом:** `OpenAIError: The OPENAI_API_KEY environment variable is missing or empty` или такая же у Anthropic. Cold start падает.

**Причина:** `const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })` на верхнем уровне файла. При import — пытается инициализироваться. Если env переменной нет → краш всего бота.

**Решение:** **Lazy init обязательно**. Шаблон:
```javascript
let _client;
function getClient() {
  if (!_client) {
    if (!process.env.OPENAI_API_KEY) throw new Error('...');
    _client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return _client;
}
```
Использовать `getClient()` внутри функций, не на module load.

---

### 3. Env vars scope = custom env вместо Production
**Симптом:** Все env переменные есть в Vercel, но в Production runtime пустые. Бот валится с 401/missing.

**Причина:** Vercel автоматически создаёт custom environment с именем проекта (например `marcus-gallup`). Переменные туда попадают по умолчанию, но **Production deploy их не видит**.

**Решение:** При создании каждой переменной — явно выбирать `Production` + `Preview` в Environments. Custom env типа `<bot-name>` НЕ отмечать.

**Проверка:** Settings → Environment Variables → у каждой переменной должно быть «Production and Preview» под именем, не «marcus-gallup».

---

### 4. includeFiles для .md промптов
**Симптом:** `ENOENT: no such file or directory, open '.../src/ai/prompts/system.md'` в runtime.

**Причина:** Vercel serverless по умолчанию бандлит только `.js`/`.ts` файлы. `.md` файлы не попадают в function bundle.

**Решение:** В `vercel.json`:
```json
{
  "functions": {
    "api/webhook.js": {
      "maxDuration": 60,
      "includeFiles": "src/ai/prompts/**"
    },
    "api/cron/*.js": {
      "maxDuration": 60,
      "includeFiles": "src/ai/prompts/**"
    }
  }
}
```

---

### 5. Vercel project URL непредсказуем
**Симптом:** При попытке открыть `<bot-name>.vercel.app` — 404 DEPLOYMENT_NOT_FOUND.

**Причина:** Vercel генерирует случайный URL типа `project-ic8fs.vercel.app`. Имя проекта в дашборде — это не URL.

**Решение:** Реальный URL найти в **Vercel → проект → Overview → Domains** или в **Deployments → последний Ready → Domain**. Если нужен красивый — добавить вручную в **Settings → Domains**.

---

## 🐛 Средние (могут отжать 10-30 мин)

### 6. Sensitive env vars нельзя редактировать inline
**Симптом:** Меняешь значение Sensitive переменной, сохраняешь — а в коде всё ещё старое.

**Решение:** Sensitive переменные в Vercel **только удалить и создать заново**. Edit может не сохранять корректно.

### 7. Webhook URL должен включать `/api/webhook`
**Симптом:** Webhook установлен, `pending: 0`, `last_error: none`, но бот молчит.

**Причина:** Скрипт `set-webhook.js` добавляет `/api/webhook` сам. Если пользователь передал URL **уже с** `/api/webhook` — может быть двойной путь.

**Решение:** В `scripts/set-webhook.js` использовать только корень URL (`https://project-xxx.vercel.app`), скрипт сам добавит endpoint.

### 8. CRLF warnings на Windows
**Симптом:** `warning: in the working copy of '...', LF will be replaced by CRLF the next time Git touches it`

**Причина:** Нормальное поведение Git на Windows.

**Решение:** Игнорировать.

### 9. Auth middleware ставится ПЕРВЫМ
**Симптом:** Логи показывают что webhook сработал, но в логике handler-а ничего не происходит. Бот молчит.

**Причина:** Auth middleware молча отклоняет всех кроме `OWNER_CHAT_ID`. Если ID неверный или scope env переменной не Production — все сообщения отбиваются.

**Решение:** В `auth.js` использовать `console.warn` для отклонённых — будет видно в Vercel Logs. Маркер «Чужой доступ» в логах = проблема с `OWNER_CHAT_ID`.

### 10. Anthropic документы — base64, не binary
**Симптом:** Claude отвечает «не могу прочитать документ».

**Причина:** API принимает PDF только как `{type: 'document', source: {type: 'base64', media_type: 'application/pdf', data: ...}}`. Не как Buffer/binary.

**Решение:** `Buffer.from(arrayBuffer).toString('base64')` перед отправкой в Claude.

---

## ⚠️ Мелкие, но раздражающие (5-15 мин каждое)

### 11. Telegram bot token формат
- Telegram: `123456789:AAFhKjL-O3...` (цифры + `:` + alphanum)
- НЕ `sk_live_...` (Stripe)
- НЕ `sk-ant-api03-...` (Anthropic)
- НЕ `sk-proj-...` (OpenAI)
- НЕ `ghp_...` (GitHub)

Не путать токены при копировании в env vars.

### 12. Cron время в Vercel — UTC
- МСК 9:00 = UTC `0 6 * * *`
- МСК 21:00 = UTC `0 18 * * *`
- Воскресенье 11:00 МСК = `0 8 * * 0`

### 13. Vercel Cron в Hobby plan ограничен
- Не больше 2 cron'ов на проект
- Не чаще раза в день

Для трёх+ cron нужен Pro plan (у Виктора уже Pro).

### 14. ESM `__dirname`
В ES modules стандартный `__dirname` не работает. Использовать:
```javascript
import { fileURLToPath } from 'url';
import { dirname } from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
```

### 15. Telegraf пакет
Поставить `telegraf` версии **4.x**, не 5.x. У 5.x ESM-имена импортов другие, ломаются туториалы.

### 16. Vercel KV → Upstash переименование
Vercel перевёл KV на Upstash. `@vercel/kv` пакет всё ещё работает, но **deprecation warning** при install. Env переменные `KV_REST_API_URL`, `KV_REST_API_TOKEN` сохраняются для совместимости.

### 17. Кириллический путь в Claude Code
**Симптом:** В сессии Claude Code shell-команды (`Bash`, `PowerShell`) возвращают пустой stdout или exit 1. Файловые операции (Read/Write/Glob) работают.

**Причина:** Encoding stdout при cwd с кириллицей.

**Решение:** Делегировать в `Agent` subagent (у них шеллы работают через другой механизм) или попросить Виктора выполнить команды вручную. Это **session-level баг**, не лечится перезапуском MCP.

### 18. PDF от Telegram приходит как `document`
Не `voice`, не `audio`, не `photo`. Нужен отдельный handler `bot.on('document', handler)`. И проверка `mime_type === 'application/pdf'`.

### 19. Telegraf middleware port для Production
`bot.use(authMiddleware)` должен быть **до** регистрации команд и handler-ов. Иначе auth не сработает.

### 20. Деплой не обновляется после env var change
**Симптом:** Изменил env переменную в Vercel — деплой не подхватил.

**Причина:** Vercel **не всегда** автоматически передеплоит при изменении env переменной. Зависит от настроек.

**Решение:** После любого изменения env vars — Deployments → последний → «...» → **Redeploy** руками.

---

## 🛡️ Безопасность (важно с самого начала)

### S1. Auth middleware первым делом
В `webhook.js` перед регистрацией команд:
```javascript
bot.use(authMiddleware); // ← обязательно первым
```
Иначе случайный человек, узнавший username бота, может пользоваться.

### S2. `.env` в `.gitignore`
Проверить **до первого commit**. Если случайно запушил — старые токены в истории, нужна ротация всех ключей.

### S3. Сохранять секреты в менеджер паролей
Anthropic/OpenAI/GitHub показывают токен **один раз**. При создании сразу в менеджер (1Password, Bitwarden, Keychain). Иначе пересоздавать каждый раз.

### S4. GitHub PAT scope — только `repo`
Не давать админских прав. Fine-grained tokens сложнее настроить, проще classic с минимальным scope.

### S5. Vercel KV приватность
`@vercel/kv` инициализируется через env переменные. Не логировать KV-ключи никогда.

---

## 🧪 Диагностика когда бот молчит

Чек-лист, проходить по порядку:

1. **`node scripts/check-webhook.js`** — что в `last_error_message`?
   - 401/Unauthorized → `TELEGRAM_BOT_TOKEN` неверный/отсутствует
   - Connection refused → URL неправильный
   - Timeout → функция слишком долгая или Deployment Protection
2. **Vercel → Logs → Error фильтр** — есть стактрейс? Что в нём?
3. **Vercel → Logs → Warning** — есть «Чужой доступ»? → `OWNER_CHAT_ID` неверный
4. **Vercel → Deployments → последний Ready** — после последнего изменения env?
5. **Открыть URL в браузере** (`<url>/api/webhook`) — что отвечает?
   - JSON → endpoint жив, проблема в auth/handler
   - 500 → функция падает (см. Logs)
   - 404 DEPLOYMENT_NOT_FOUND → URL не тот
   - Vercel auth screen → Deployment Protection включён

---

## 📝 Что сделать ПЕРЕД сборкой нового бота

1. Прочитать этот файл целиком
2. Открыть `Desktop/Claude Code/marcus.gallup/` как референс
3. Проверить что Vercel Pro активен (новый KV нужен на каждый проект)
4. Подготовить менеджер паролей под новые ключи
5. Сразу спланировать имя бота (для GitHub репо, Vercel project, BotFather username)
