---
name: telegram-ai-agent
description: Быстрая сборка персонального Telegram-бота (коуч или ассистент): каркас, логика, подключение. Триггеры: «создай бота в Telegram», «AI-агент в TG», «коуч-бот по теме».
---

# Telegram AI Agent — скилл для быстрой сборки персонального коуч-бота

## Когда использовать

Триггеры в речи Виктора:
- «создай бота в Telegram», «AI-агент в TG», «персональный ассистент в телеге»
- «новый Маркус [для чего-то]», «семейство Маркусов»
- «коуч-бот по [теме]», «ассистент-наставник»
- «PDF-знание + бот»

**НЕ использовать** если:
- Бот для бизнес-логики (платежи, заказы) — это не коуч-агент
- Многопользовательский SaaS — этот скилл про single-user agents
- Нужен бот не в Telegram — стек заточен под TG

## Что это и почему

Канонический пример: **Marcus Gallup** в `C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\Desktop\Claude Code\marcus.gallup`. Личный Gallup-коуч для Виктора, собранный за один вечер. Все архитектурные решения, код-шаблоны, известные грабли — переиспользуемы.

Скилл превращает 4-5 часов сборки + дебаг в **30-90 минут чистой работы**.

## Семейство Маркусов

Виктор строит экосистему ассистентов под брендом **Маркус**:
- Маркус (главный, операционка)
- Marcus Gallup (коуч по карте талантов)
- Возможные: Маркус Контент, Маркус Деньги, Маркус Здоровье, и т.д.

Каждый — отдельный TG-бот, отдельный Vercel-проект, отдельный приватный GitHub-репо. Разделение по контекстам, не модули внутри одного бота.

---

## Архитектура (зафиксировано, НЕ обсуждать заново)

| Слой | Решение | Почему |
|---|---|---|
| Хостинг | **Vercel Pro** (у Виктора уже оплачен $20/мес) | Единая экосистема его ботов, бесплатные cron, нет таймаутов |
| Язык | **Node.js + Telegraf** | Совместимость с другими его ботами, чистый async код |
| LLM основной | **Anthropic Claude Sonnet 4.5** | Лучший коуч-режим, поддержка PDF documents, prompt caching |
| LLM лёгкий | **Anthropic Claude Haiku 4.5** | Классификация, простые ответы, экономия |
| Голос → текст | **OpenAI Whisper API** | Дёшево (~$5/мес), точно, понимает русский |
| Краткая память | **Vercel KV** (Upstash под капотом) | История чата, активные flow, 256MB free |
| Долгая память | **Obsidian-vault через GitHub API** | Версионирование автоматом, синк с локальным Obsidian через Git plugin |
| Триггеры | **Vercel Cron** | Утро/вечер/неделя без внешних сервисов |
| GitHub | **`Viktor-drake`** аккаунт, приватные репо | Личные боты |

## Стоимость на бота

- Vercel Pro: уже оплачен ($20/мес общий)
- Claude API: $30-60/мес при активном использовании (с prompt caching)
- Whisper API: ~$5/мес
- **Новых расходов на каждого нового Маркуса: $35-65/мес**

---

## Структура кода (готовые шаблоны)

Каноническая структура — копировать из `Desktop/Claude Code/marcus.gallup/`:

```
<agent-name>/
├── CLAUDE.md                          # память проекта
├── TZ.md                              # ТЗ (если делегируется)
├── SETUP.md                           # шаги запуска
├── README.md
├── package.json                       # зависимости
├── vercel.json                        # cron + includeFiles
├── .env.example                       # все нужные ключи
├── .gitignore
├── api/
│   ├── webhook.js                     # главный TG endpoint
│   └── cron/
│       ├── morning.js                 # утренний триггер
│       ├── evening.js                 # вечерний триггер
│       └── weekly.js                  # воскресный
├── src/
│   ├── ai/
│   │   ├── claude.js                  # Anthropic SDK + lazy init + caching + analyzePdfBase64
│   │   ├── whisper.js                 # OpenAI Whisper + lazy init
│   │   └── prompts/
│   │       └── system.md              # коуч-промпт (главный артефакт)
│   ├── bot/
│   │   ├── keyboards.js               # inline keyboards
│   │   ├── middleware/auth.js         # только владелец
│   │   ├── handlers/
│   │   │   ├── commands.js            # /start, /situation, /morning, ...
│   │   │   ├── callbacks.js           # кнопки
│   │   │   ├── text.js                # свободный текст
│   │   │   ├── voice.js               # голосовые
│   │   │   └── document.js            # PDF
│   │   └── flows/
│   │       ├── runner.js              # роутер flow
│   │       ├── morning.js             # 3-вопросный термомикс
│   │       ├── evening.js
│   │       ├── situation.js
│   │       ├── weekly.js
│   │       ├── idea.js                # тест на влюблённость / decision support
│   │       ├── person.js              # подготовка к встрече с человеком из people/
│   │       └── save-person.js         # обработка PDF → создание people/<имя>.md
│   ├── memory/
│   │   ├── kv.js                      # Vercel KV: история + flow state
│   │   └── obsidian.js                # GitHub API для vault
│   └── profile/
│       └── profile.json               # структурированная карта знаний (опционально)
└── scripts/
    ├── set-webhook.js                 # установка webhook
    ├── check-webhook.js               # диагностика webhook
    └── setup-vault.js                 # инициализация vault репо
```

---

## Discovery — что спросить у Виктора

Перед сборкой выясни (минимум 5 минут):

1. **Имя бота.** В семействе Маркусов: «Marcus X» / «Маркус [тема]».
2. **Цель.** Одна фраза: «помогаю с …», «коуч по …».
3. **Что бот должен знать.** Источники:
   - Word/PDF-документы → системный промпт
   - Транскрипты разговоров → выжимка
   - Структурированные данные → profile.json
4. **Главный приоритет сценария.** Один из:
   - Разбор ситуации (Marcus Gallup паттерн)
   - Подготовка к событию
   - Дисциплина ритуалов (утро/вечер/неделя)
   - Обработка входящих документов
5. **Тон.** Дефолт — «жёстко-уважительно, в стиле Нуркена». Если другой — уточнить.
6. **Триггерные времена.** Дефолт: утро 9:00 МСК, вечер 21:00 МСК, воскресенье 11:00 МСК.
7. **Нужны ли особые входы:** PDF, голос, картинки, голосовые ответы (TTS).
8. **Долгая память — нужна или нет.** Если да — отдельный приватный репо `<bot-name>-vault`.

Если на 1-3 ответа нет — сначала их собираем, потом начинаем сборку.

---

## Setup-чеклист (15-30 минут чистого времени Виктора)

### Шаг A — Создать TG-бота
- @BotFather → `/newbot` → имя → username
- Скопировать токен (`123456789:AAFh...`)

### Шаг B — Узнать chat_id
- @userinfobot → `/start` → скопировать число

### Шаг C — API-ключи (если первый бот в семействе — сохранить в менеджер паролей)
- Anthropic: https://console.anthropic.com → API Keys
- OpenAI: https://platform.openai.com/api-keys (только если нужен голос)
- GitHub PAT: github.com/settings/tokens → classic → scope `repo`

### Шаг D — Создать репо (делегировать в Agent или сделать вручную через gh)
```powershell
cd "Desktop/Claude Code/<agent-name>"
npm install
git init
git branch -M main
git add .
git commit -m "Initial"
gh repo create Viktor-drake/<agent-name> --private --source . --remote origin --push
gh repo create Viktor-drake/<agent-name>-vault --private  # если нужна долгая память
```

### Шаг E — Vercel
1. https://vercel.com/dashboard → New Project → импорт из GitHub
2. Settings → Storage → Create Database → **Upstash** → Pay As You Go → Connect to project
3. Settings → Environment Variables → добавить **СО SCOPE PRODUCTION + PREVIEW**:
   - `TELEGRAM_BOT_TOKEN`
   - `OWNER_CHAT_ID`
   - `ANTHROPIC_API_KEY`
   - `OPENAI_API_KEY` (если нужен голос)
   - `GITHUB_TOKEN`
   - `OBSIDIAN_VAULT_REPO` = `Viktor-drake/<agent-name>-vault`
4. Settings → Git → Connect Git Repository → выбрать репо

### Шаг F — Локальный .env
```powershell
copy .env.example .env
# заполнить TELEGRAM_BOT_TOKEN, GITHUB_TOKEN, OBSIDIAN_VAULT_REPO
```

### Шаг G — Инициализация
```powershell
npm run setup-vault                                    # стартовые файлы в vault
node scripts/set-webhook.js https://<vercel-url>      # установка webhook
node scripts/check-webhook.js                          # проверка
```

### Шаг H — Тест
- `/start` в боте — должно прийти приветствие
- Голосовое — должно ответить без транскрипта
- PDF (если поддерживается) — должен распознать

**Если бот молчит → Vercel → Logs → Error → диагностика по PITFALLS.md**

---

## Что меняется при каждом новом боте

| Что | Где | Как |
|---|---|---|
| Имя/назначение бота | system.md, README.md, CLAUDE.md | Поиск-замена |
| Системный промпт | `src/ai/prompts/system.md` | Полностью переписать под тему |
| Команды и кнопки | `src/bot/handlers/commands.js`, `keyboards.js` | Адаптировать сценарии |
| Flows | `src/bot/flows/*.js` | Оставить нужные, убрать лишние |
| Триггерные времена | `vercel.json` | Cron-строки в UTC |
| Структура vault | `scripts/setup-vault.js` | Шаблоны state.md / horizons.md / others |
| package.json name | `package.json` | Имя пакета |
| Env vars | Vercel | OBSIDIAN_VAULT_REPO = `<bot-name>-vault` |

**Не меняются:**
- Telegraf bootstrap (webhook.js)
- Auth middleware
- Lazy init pattern в claude.js / whisper.js
- Vercel KV структура
- GitHub API helper для vault
- Smart routing логика
- Шаблоны cron (только тексты сообщений)

---

## Известные грабли (см. PITFALLS.md в этой папке)

Перечитать обязательно перед сборкой. Кратко:

1. **Markdown parse_mode** — не использовать в ответах с динамическим контентом
2. **Env vars scope** — должен быть Production (не custom env типа `<bot-name>`)
3. **Sensitive vars нельзя редактировать** — delete + add new
4. **AI clients lazy init** — `new Anthropic(...)` / `new OpenAI(...)` НЕ на module load
5. **includeFiles в vercel.json** для .md файлов промптов
6. **Vercel project URL непредсказуемый** — найти в Overview → Domains
7. **CRLF warnings на Windows** — норма, игнорировать
8. **Кириллица в путях** — иногда ломает shell в Claude Code сессиях. Файловые операции работают, команды иногда нет
9. **Сами токены проверять по префиксам** — `sk_live_` это Stripe, не Telegram
10. **Vercel Deployment Protection** — для webhook должно быть Disabled или Preview-only

---

## План работ при использовании скилла

1. **Discovery** (5-15 мин): задать вопросы выше, получить ответы
2. **Создать папку проекта** в `Desktop/Claude Code/<agent-name>/`
3. **Скопировать шаблоны** из `marcus.gallup/` (см. структуру выше)
4. **Кастомизировать**:
   - `system.md` — главный артефакт, **70% времени уйдёт сюда**
   - Команды, flow, vault-структура — по списку выше
5. **Прогнать setup-чеклист** с Виктором
6. **Тестовый прогон**: `/start` + один сценарий + один PDF (если есть)
7. **Зафиксировать в CLAUDE.md** проекта что и зачем

---

## Оценка времени экономии

**Без скилла (как Marcus Gallup сегодня):** 4-6 часов
- 2 часа: обсуждение архитектуры с нуля
- 1 час: написание кода
- 1.5-2 часа: дебаг setup (env vars scope, Markdown errors, lazy init, etc.)
- 0.5 часа: тестирование

**Со скиллом:** 45-90 минут
- 10 мин: discovery
- 15-25 мин: написание системного промпта (главное)
- 10 мин: адаптация шаблонов кода (Claude делает поиск-замену)
- 25-40 мин: setup чеклист (BotFather + env vars + Vercel KV — это в любом случае руками)
- 5 мин: тест

**Ускорение: 4-6x.** Главная экономия — не повторение известных граблей и не пере-проектирование архитектуры.

---

## Каноническая референс-реализация

**Marcus Gallup:** `C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\Desktop\Claude Code\marcus.gallup\`

Содержит:
- Все 15 файлов кода
- TZ.md с полным техзаданием
- CLAUDE.md с памятью проекта
- SETUP.md с пошаговой инструкцией

При сборке нового бота — **сначала открыть marcus.gallup**, понять структуру, потом копировать и адаптировать.
