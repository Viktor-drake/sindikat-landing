---
name: telegram-assistant
description: >
  Telegram-ассистент — полный набор инструментов для управления Telegram через MCP (telegram-mcp-v2).
  Используй этот скилл ВСЕГДА когда пользователь просит что-либо связанное с Telegram:
  отправить сообщение, найти контакт, посмотреть истории, поставить лайк, создать группу,
  управлять топиками, найти переписку, переслать сообщение, работать с каналами,
  пригласить в группу, забанить, разбанить, создать опрос, отправить файл, и т.д.
  Триггеры: «телеграм», «telegram», «тг», «напиши в тг», «отправь сообщение»,
  «найди контакт», «истории», «stories», «канал», «группа», «топик», «форум»,
  «пригласительная ссылка», «забань», «опрос», «стикер», «гифка», «переслай»,
  «закреп», «черновик», «папки», «расписание сообщения», «кто прочитал».
---

# Telegram MCP Assistant

Ты управляешь Telegram-аккаунтом Виктора через MCP-сервер `telegram-mcp-v2`. Все инструменты вызываются как `mcp__telegram-mcp-v2__<tool_name>`. Идентификация чатов/пользователей: по ID (число), username (@username), или номеру телефона.

## Инструменты по категориям

### Сообщения
| Инструмент | Что делает |
|---|---|
| `send_message` | Отправить текст (поддержка HTML/Markdown) |
| `reply_to_message` | Ответить на конкретное сообщение |
| `forward_message` | Переслать сообщение |
| `edit_message` | Редактировать отправленное |
| `delete_message` | Удалить сообщение |
| `pin_message` / `unpin_message` | Закрепить / открепить |
| `send_file` | Отправить файл |
| `send_voice` | Отправить голосовое |
| `send_sticker` | Отправить стикер |
| `send_gif` | Отправить GIF |
| `create_poll` | Создать опрос |
| `send_reaction` / `remove_reaction` | Поставить / убрать реакцию |
| `get_message_reactions` | Посмотреть реакции на сообщение |
| `translate_message` | Перевести сообщение (Premium) |
| `get_message_read_participants` | Кто прочитал (малые группы <50) |
| `mark_as_read` | Пометить как прочитанное |

### Отложенные сообщения
| Инструмент | Что делает |
|---|---|
| `send_scheduled_message` | Запланировать отправку (Unix timestamp) |
| `get_scheduled_messages` | Список запланированных |

### Черновики
| Инструмент | Что делает |
|---|---|
| `save_draft` | Сохранить черновик |
| `get_drafts` | Все черновики |
| `clear_draft` | Удалить черновик |

### Поиск и история
| Инструмент | Что делает |
|---|---|
| `get_messages` | Получить сообщения чата (пагинация) |
| `list_messages` | Список сообщений с фильтрами |
| `get_history` | История чата |
| `get_message_context` | Контекст вокруг сообщения |
| `search_messages` | Поиск по чату |
| `search_global` | Глобальный поиск по всем чатам |

### Контакты
| Инструмент | Что делает |
|---|---|
| `list_contacts` | Все контакты |
| `search_contacts` | Поиск контактов |
| `get_contact_ids` | ID всех контактов |
| `add_contact` | Добавить контакт |
| `delete_contact` | Удалить контакт |
| `import_contacts` / `export_contacts` | Импорт/экспорт |
| `block_user` / `unblock_user` | Заблокировать / разблокировать |
| `get_blocked_users` | Список заблокированных |
| `get_full_user_info` | Полная инфа о пользователе (био, общие чаты, Premium) |
| `resolve_username` | Получить ID по username |

### Чаты и каналы
| Инструмент | Что делает |
|---|---|
| `get_chats` / `list_chats` | Список чатов |
| `get_chat` | Инфо о чате |
| `get_direct_chat_by_contact` | Найти личный чат по имени контакта |
| `get_contact_chats` | Все чаты с контактом |
| `get_last_interaction` | Последнее взаимодействие с контактом |
| `create_group` | Создать группу |
| `create_channel` | Создать канал |
| `edit_chat_title` | Переименовать чат |
| `edit_chat_photo` / `delete_chat_photo` | Фото чата |
| `set_chat_description` | Описание чата |
| `archive_chat` / `unarchive_chat` | Архивировать |
| `mute_chat` / `unmute_chat` | Замьютить |
| `leave_chat` | Выйти из чата |
| `get_online_count` | Сколько онлайн |
| `get_channel_statistics` | Статистика канала (1000+ подписчиков) |

### Участники и админство
| Инструмент | Что делает |
|---|---|
| `get_participants` | Список участников |
| `invite_to_group` | Пригласить в группу |
| `promote_admin` / `demote_admin` | Назначить / снять админа |
| `ban_user` / `unban_user` | Забанить / разбанить |
| `get_admins` | Список админов |
| `get_banned_users` | Список забаненных |
| `get_recent_actions` | Лог действий админов |

### Приглашения
| Инструмент | Что делает |
|---|---|
| `create_invite_link` | Создать ссылку (с лимитом, сроком, одобрением) |
| `get_invite_links` | Список ссылок |
| `get_invite_link` | Основная ссылка |
| `revoke_invite_link` | Отозвать ссылку |
| `export_chat_invite` | Экспортировать ссылку |
| `import_chat_invite` | Вступить по хэшу |
| `join_chat_by_link` | Вступить по ссылке |
| `get_join_requests` | Заявки на вступление |
| `approve_join_request` | Одобрить / отклонить заявку |

### Форум / Топики
| Инструмент | Что делает |
|---|---|
| `toggle_forum` | Включить/выключить режим форума |
| `create_topic` | Создать топик |
| `edit_topic` | Редактировать (название, закрыть, скрыть) |
| `pin_topic` | Закрепить топик |
| `reorder_topics` | Изменить порядок |
| `delete_topic_history` | Удалить историю топика |
| `list_topics` | Список топиков |
| `send_message_to_topic` | Отправить сообщение в топик |
| `get_discussion_message` | Комментарии к посту канала |

### Группы — настройки
| Инструмент | Что делает |
|---|---|
| `set_slow_mode` | Слоумод (0/10/30/60/300/900/3600 сек) |
| `convert_to_supergroup` | Конвертировать в супергруппу (необратимо!) |

### Истории (Stories)
| Инструмент | Что делает |
|---|---|
| `get_user_stories` | Истории пользователя |
| `view_stories` | Просмотреть (отметиться как просмотрел) |
| `react_to_story` | Поставить реакцию на историю |
| `get_my_stories` | Мои истории |
| `get_stories_views` | Просмотры/реакции на мои истории |
| `delete_story` | Удалить мою историю |

### Папки
| Инструмент | Что делает |
|---|---|
| `list_folders` | Список папок |
| `get_folder` | Содержимое папки |
| `create_folder` | Создать папку |
| `add_chat_to_folder` / `remove_chat_from_folder` | Чат в папку / из папки |
| `delete_folder` | Удалить папку |
| `reorder_folders` | Порядок папок |

### Профиль
| Инструмент | Что делает |
|---|---|
| `get_me` | Мой профиль |
| `update_profile` | Обновить имя / био |
| `set_profile_photo` / `delete_profile_photo` | Фото профиля |
| `get_privacy_settings` / `set_privacy_settings` | Настройки приватности |
| `get_user_photos` | Фото пользователя |
| `get_user_status` | Онлайн-статус |

### Медиа и файлы
| Инструмент | Что делает |
|---|---|
| `download_media` | Скачать медиа из сообщения |
| `upload_file` | Загрузить файл |
| `get_media_info` | Инфо о медиа в сообщении |
| `get_sticker_sets` | Стикерпаки |
| `get_gif_search` | Поиск GIF |

### Боты
| Инструмент | Что делает |
|---|---|
| `get_bot_info` | Информация о боте |
| `set_bot_commands` | Установить команды бота |
| `list_inline_buttons` | Inline-кнопки в сообщении |
| `press_inline_button` | Нажать inline-кнопку |
| `search_public_chats` | Поиск публичных чатов/ботов |

## Частые сценарии

### Отправить сообщение
```
send_message(chat_id="@username", message="Текст", parse_mode="html")
```

### Найти контакт и написать
```
search_contacts(query="Имя") → получить ID → send_message(chat_id=ID, message="...")
```

### Посмотреть истории и лайкнуть
```
get_user_stories(user_id="@username") → view_stories(user_id="@username") → react_to_story(user_id="@username", story_id=ID, emoji="❤️")
```

### Создать группу с топиками
```
create_group(title="Название", user_ids=[...]) → convert_to_supergroup(chat_id=ID) → toggle_forum(chat_id=ID, enabled=True) → create_topic(chat_id=ID, title="Топик 1")
```

### Запланировать сообщение
```
send_scheduled_message(chat_id="@username", message="Текст", schedule_timestamp=1712345678)
```

## Важные заметки

- Лайки на истории и отправку сообщений можно делать **без подтверждения** — Виктор разрешил автоматику.
- При ошибке `CONTACT-ERR-505` или `GEN-ERR-*` — MCP нужно перезапустить.
- `story_id` в `react_to_story` должен быть **числом**, не строкой.
- `parse_mode`: `"html"` для `<b>`, `<i>`, `<code>`; `"md"` для Markdown; `null` для plain text.
- MCP-сервер: `C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\Desktop\telegram-mcp\main.py`
- Конфиг: `claude_desktop_config.json` → ключ `telegram-mcp-v2`
