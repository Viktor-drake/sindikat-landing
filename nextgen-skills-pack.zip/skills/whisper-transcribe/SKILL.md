---
name: whisper-transcribe
description: >
  Транскрибация видео и аудио в текст через Whisper (faster-whisper) локально, без
  загрузки в облако. Извлекает дорожку через ffmpeg, распознаёт речь и выдаёт чистый
  текст плюс субтитры (SRT) с таймкодами. Используй, когда нужно: «расшифруй запись»,
  «сделай текст из аудио», «транскрибируй видео», «субтитры к ролику», «текст созвона/
  кружочка/голосового», «конспект из записи». Работает с mp4, mov, mp3, wav, m4a, ogg
  и ссылками (через yt-dlp). Для YouTube по ссылке лучше скилл youtube-analyzer.
---

# Whisper Transcribe — транскрибация видео и аудио

Локальная расшифровка речи в текст. Ничего не уходит в облако, всё считается на твоей машине.

## Что нужно один раз поставить
```
pip install faster-whisper
```
Плюс **ffmpeg** в системе (Windows: `winget install Gyan.FFmpeg`, Mac: `brew install ffmpeg`).
Опционально для скачивания по ссылке: `pip install yt-dlp`.

## Как работает
1. Если дали ссылку - скачиваем медиа через `yt-dlp`. Если локальный файл - берём его.
2. Извлекаем аудио в wav 16kHz моно через ffmpeg:
   `ffmpeg -i "<вход>" -ar 16000 -ac 1 -c:a pcm_s16le "audio.wav"`
3. Распознаём через faster-whisper:
```python
from faster_whisper import WhisperModel
model = WhisperModel("large-v3", device="auto", compute_type="auto")  # для слабого ПК: "small" или "medium"
segments, info = model.transcribe("audio.wav", language="ru", vad_filter=True)
text = "\n".join(s.text.strip() for s in segments)
print(text)
```
4. Сохраняем результат: `transcript.txt` (чистый текст) и при необходимости `subtitles.srt` (с таймкодами из `segments`).

## Выбор модели
- `large-v3` - максимальное качество (нужна видеокарта или терпение на CPU)
- `medium` - баланс
- `small` - быстро на слабом ПК, качество ниже

## Правила
- Указывай язык явно (`language="ru"`), если речь русская - точнее и быстрее.
- `vad_filter=True` убирает паузы и тишину, меньше галлюцинаций.
- Длинные файлы (лекции, созвоны) считаются дольше - предупреди пользователя.
- Для разбора смысла после расшифровки передай текст в `content-pro` (выжимка/тезисы) или `zoom-transcripts` (для созвонов).

## Связанные скиллы
- `youtube-analyzer` - YouTube по ссылке (субтитры/транскрипт без скачивания видео)
- `reels-viewer` - разбор Reels/TikTok (там whisper уже встроен)
- `zoom-transcripts` - готовые транскрипты созвонов Zoom
