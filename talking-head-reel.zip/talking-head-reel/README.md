# talking-head-reel

Скилл для Claude Code: собирает вертикальный рилс «говорящая голова + motion-графика»
из клипа AI-аватара через [HyperFrames](https://github.com/heygen-com/hyperframes).

Вместо ручного HTML пишется манифест YAML: карточки, раскадровка PiP-видео и субтитры.
Дальше генератор собирает `index.html`, движок рендерит mp4.

## Что внутри

| файл | назначение |
| --- | --- |
| `SKILL.md` | сам скилл: правила, грабли, порядок сборки. Читать первым |
| `build.py` | манифест YAML → `index.html` |
| `marks.py` | библиотека из 30+ анимированных элементов (inline SVG + GSAP) |
| `sound.py` | синтез звуковых эффектов и микс по событиям карточек |
| `draft_manifest.py` | черновик манифеста из word-level транскрипта |
| `assets_index.py` | индекс уже сгенерированных логотипов и B-roll с поиском |
| `fetch_logos.py` | локальная библиотека логотипов из Simple Icons / svgl |
| `reference-claude-window.html` | рабочий фрагмент карточки «окно ассистента» |
| `sfx/` | синтезированные wav: click, ding, key, pop, thock, tick, whoosh |
| `example/` | пример манифеста и скелет проекта HyperFrames |

## Установка

```bash
# Claude Code (личные скиллы)
cp -r talking-head-reel ~/.claude/skills/

# или в скиллы проекта
cp -r talking-head-reel <проект>/.claude/skills/
```

Зависимости:

```bash
pip install pyyaml faster-whisper requests
# ffmpeg должен быть в PATH
# hyperframes CLI ставится через npx, версия пинуется в package.json проекта
```

## Как пользоваться

1. Сгенерировать или снять клип говорящей головы (HeyGen, другой генератор, обычная съёмка).
2. Вытащить аудио и квадратный кроп лица под PiP (команды в `SKILL.md`).
3. Снять word-level транскрипт (`faster-whisper`).
4. Заполнить `manifest.yaml` по образцу из `example/`.
5. `python build.py manifest.yaml --out project/index.html`
6. `npx hyperframes check` → `npx hyperframes snapshot` → `npx hyperframes render`
7. Ускорение через ffmpeg и звук через `sound.py`.

Подробности, грабли движка и правила оформления — в `SKILL.md`.

## Лицензия и происхождение

Код скилла свободен к использованию и изменению. Звуковые эффекты синтезируются кодом,
внешних сэмплов и лицензий за ними нет. Логотипы тянутся из Simple Icons (CC0) и svgl (MIT).
Шрифт в примере не приложен: подставьте свой woff2 в `project/assets/fonts/`.
