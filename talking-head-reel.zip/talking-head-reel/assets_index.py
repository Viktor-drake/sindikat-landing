# -*- coding: utf-8 -*-
"""
Память по ассетам: один индекс всех логотипов и B-roll картинок проекта,
чтобы не генерить заново то, что уже лежит в папке прошлой задачи.

    python assets_index.py --scan                 # пересобрать индекс
    python assets_index.py --find "терминал ночь" # найти подходящее
    python assets_index.py --find laptop --copy projects/my-reel/hyperframes-project/assets/broll

Индекс: <корень проекта>/_assets/index.json
B-roll подхватывает описание из broll.yaml рядом с картинкой (промпт = теги),
логотипы индексируются по имени файла.
"""
import os
import argparse
import json
import pathlib
import shutil
import sys

ROOT = pathlib.Path(os.environ.get("REEL_PROJECT_ROOT", ".")).resolve()
INDEX = ROOT / "_assets" / "index.json"
IMG = {".png", ".jpg", ".jpeg", ".webp"}


def _prompts_near(folder: pathlib.Path) -> dict:
    """id -> промпт из broll*.yaml рядом с папкой картинок (или в ней самой)."""
    import yaml
    out = {}
    for cand in list(folder.parent.glob("broll*.yaml")) + list(folder.glob("broll*.yaml")):
        try:
            for item in yaml.safe_load(cand.read_text(encoding="utf-8")) or []:
                if item.get("id"):
                    out[str(item["id"])] = " ".join(str(item.get("prompt", "")).split())
        except Exception:
            continue
    return out


def scan() -> list:
    items = []

    for svg in sorted((ROOT / "_assets" / "logos").glob("*.svg")):
        items.append({
            "kind": "logo",
            "id": svg.stem,
            "path": str(svg.relative_to(ROOT)).replace("\\", "/"),
            "tags": svg.stem,
            "task": "_assets",
        })

    seen_dirs = set()
    for folder in sorted(ROOT.glob("Задачи/*/broll*")):
        if not folder.is_dir() or folder in seen_dirs:
            continue
        seen_dirs.add(folder)
        prompts = _prompts_near(folder)
        task = folder.parent.name
        for img in sorted(folder.iterdir()):
            if img.suffix.lower() not in IMG:
                continue
            base = img.stem.split("_")[0] if img.stem not in prompts else img.stem
            items.append({
                "kind": "broll",
                "id": img.stem,
                "path": str(img.relative_to(ROOT)).replace("\\", "/"),
                "tags": prompts.get(img.stem) or prompts.get(base) or img.stem,
                "task": task,
            })

    INDEX.parent.mkdir(parents=True, exist_ok=True)
    INDEX.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
    logos = sum(1 for x in items if x["kind"] == "logo")
    print(f"Проиндексировано: {logos} логотипов, {len(items) - logos} B-roll. Индекс: {INDEX}")
    return items


def find(query: str, copy_to: str | None = None):
    if not INDEX.exists():
        scan()
    items = json.loads(INDEX.read_text(encoding="utf-8"))
    terms = [t.lower() for t in query.split() if t]
    scored = []
    for it in items:
        hay = f"{it['id']} {it['tags']}".lower()
        hits = sum(1 for t in terms if t in hay)
        if hits:
            scored.append((hits, it))
    scored.sort(key=lambda x: -x[0])
    if not scored:
        print("Ничего не нашлось, придётся генерить новое.")
        return
    for hits, it in scored[:10]:
        print(f"  [{hits}] {it['kind']:5} {it['id']:22} {it['task']:22} {it['path']}")
        print(f"        {it['tags'][:110]}")
    if copy_to:
        dst = pathlib.Path(copy_to)
        dst.mkdir(parents=True, exist_ok=True)
        src = ROOT / scored[0][1]["path"]
        shutil.copy2(src, dst / src.name)
        print(f"Скопировано лучшее совпадение: {src.name} -> {dst}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scan", action="store_true")
    ap.add_argument("--find")
    ap.add_argument("--copy", help="папка, куда положить лучшее совпадение")
    a = ap.parse_args()
    if a.scan:
        scan()
    elif a.find:
        find(a.find, a.copy)
    else:
        sys.exit("Нужен --scan или --find")


if __name__ == "__main__":
    main()
