# -*- coding: utf-8 -*-
"""
Генератор HyperFrames-композиции для рилса "говорящая голова + motion-графика".

Вход:  manifest.yaml (карточки, раскадровка PiP, субтитры)
Выход: index.html (одним файлом, без data-composition-src — см. баг движка в SKILL.md)

Запуск:
    python build.py manifest.yaml --out путь/к/hyperframes-project/index.html

Субтитры можно не писать руками: укажи в манифесте
    captions: {from_words: "_артефакты/heygen_words.json", max_words: 6}
и они соберутся из word-level транскрипта Whisper по паузам.
"""
import argparse
import json
import pathlib
import sys

import yaml

import marks

# ── Бренд-токены. Меняются здесь, а не по карточкам ────────────
BG = "rgb(245, 244, 241)"
INK = "rgb(23, 23, 20)"
ACCENT = "rgb(195, 100, 93)"      # контраст-безопасная терракота (WCAG AA)
ACCENT_DEEP = "rgb(179, 58, 50)"  # только для плашек/заливок, НЕ для мелкого текста
MUTED = "rgb(128, 128, 126)"        # приглушённый текст НА БЕЖЕВОМ фоне (проходит AA)
MUTED_GLASS = "rgb(145, 145, 143)"  # он же НА СТЕКЛЯННОЙ карточке (фон светлее, можно светлее)
GLASS = "linear-gradient(145deg, rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.26))"
SHADOW = "rgba(38, 34, 23, 0.125) 0px 12px 28px 0px"

# ── Состояния PiP-видео (talking-head-recut video framing) ────────────────────
PIP_STATES = {
    "hero_center": dict(width=480, height=480, x=300, y=90, borderRadius=999),
    "side_big":    dict(width=320, height=320, x=700, y=60, borderRadius=999),
    "side_small":  dict(width=230, height=230, x=790, y=60, borderRadius=999),
    # Крупный план сверху. Пропорция КВАДРАТНАЯ, как у pip_source: коробка 1080x960
    # обрезала лицо сверху и снизу, потому что object-fit: cover растягивает квадрат
    # под некрадратный бокс. такой кадр забракован на ревью, см. SKILL.md.
    "half_top":    dict(width=820, height=820, x=130, y=110, borderRadius=56),
    # Спикер крупной карточкой снизу, уходящей за нижний край; верх кадра отдан контенту
    # (скриншот, сайт, интерфейс). Формат подсмотрен у донора, см. SKILL.md.
    "bottom_card": dict(width=1000, height=820, x=40, y=1140, borderRadius=48),
    "fullscreen":  dict(width=1080, height=1920, x=0, y=0, borderRadius=0),
}


# ── Пресеты оформления ────────────────────────────────────────────────────────
# preset: beige | ink | bold в манифесте. Меняет разом палитру, субтитры и форму PiP,
# набор карточек при этом общий. Подробнее — раздел "Разнообразие шаблонов" в SKILL.md.
CAP_PLATE_DARK = (
    "position:absolute; left:0; right:0; margin:0 auto; bottom:210px; max-width:900px;"
    " width:max-content; text-align:center; font-weight:700; font-size:48px; line-height:1.28;"
    " letter-spacing:-0.01em; color:rgb(250,249,247); background:rgba(23,23,20,0.86);"
    " padding:18px 32px; border-radius:26px; opacity:0; z-index:6;"
)
CAP_PLATE_LIGHT = (
    "position:absolute; left:0; right:0; margin:0 auto; bottom:210px; max-width:900px;"
    " width:max-content; text-align:center; font-weight:700; font-size:48px; line-height:1.28;"
    " letter-spacing:-0.01em; color:rgb(23,23,20); background:rgba(245,244,241,0.93);"
    " padding:18px 32px; border-radius:26px; opacity:0; z-index:6;"
)
CAP_BARE_BIG = (
    "position:absolute; left:0; right:0; margin:0 auto; bottom:250px; max-width:960px;"
    " width:max-content; text-align:center; font-weight:800; font-size:64px; line-height:1.14;"
    " letter-spacing:-0.025em; color:rgb(18,18,16); padding:0 28px; opacity:0; z-index:6;"
    " text-shadow:0 0 18px rgba(250,248,244,0.95), 0 0 6px rgba(250,248,244,0.95);"
)

PRESETS = {
    "beige": dict(
        BG="rgb(245, 244, 241)", INK="rgb(23, 23, 20)",
        ACCENT="rgb(195, 100, 93)", ACCENT_DEEP="rgb(179, 58, 50)",
        MUTED="rgb(128, 128, 126)", MUTED_GLASS="rgb(136, 136, 134)",
        GLASS="linear-gradient(145deg, rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.26))",
        SHADOW="rgba(38, 34, 23, 0.125) 0px 12px 28px 0px",
        _cap=CAP_PLATE_DARK, _cap_fg="rgb(250,249,247)", _cap_hi="rgb(232,156,148)", _pip={},
    ),
    # Светлые варианты фона (тёмный отклонён на ревью). Отличаются оттенком и фактурой.
    "paper": dict(
        BG="rgb(250, 249, 246)", INK="rgb(23, 23, 20)",
        ACCENT="rgb(186, 82, 74)", ACCENT_DEEP="rgb(166, 52, 45)",
        MUTED="rgb(124, 124, 121)", MUTED_GLASS="rgb(132, 132, 130)",
        GLASS="linear-gradient(145deg, rgba(255, 255, 255, 0.82), rgba(255, 255, 255, 0.5))",
        SHADOW="rgba(38, 34, 23, 0.10) 0px 10px 26px 0px",
        _cap=CAP_PLATE_DARK, _cap_fg="rgb(250,249,247)", _cap_hi="rgb(232,156,148)",
        # едва заметная бумажная фактура: тонкая сетка линий поверх однотонного фона
        _bg=("background-image:repeating-linear-gradient(0deg, rgba(23,23,20,0.022) 0 1px, "
             "transparent 1px 3px), repeating-linear-gradient(90deg, rgba(23,23,20,0.018) 0 1px, "
             "transparent 1px 3px);"),
        _pip={},
    ),
    "sand": dict(
        BG="rgb(237, 231, 221)", INK="rgb(28, 25, 20)",
        ACCENT="rgb(172, 66, 56)", ACCENT_DEEP="rgb(150, 48, 40)",
        MUTED="rgb(120, 114, 105)", MUTED_GLASS="rgb(128, 122, 113)",
        GLASS="linear-gradient(145deg, rgba(255, 253, 249, 0.72), rgba(255, 253, 249, 0.38))",
        SHADOW="rgba(60, 48, 30, 0.14) 0px 14px 30px 0px",
        _cap=CAP_PLATE_DARK, _cap_fg="rgb(250,249,247)", _cap_hi="rgb(235,160,150)",
        # тёплое световое пятно сверху, как от окна
        _bg=("background-image:radial-gradient(900px 700px at 50% 12%, rgba(255,255,255,0.55), "
             "rgba(255,255,255,0) 70%);"),
        _pip={},
    ),
    "studio": dict(
        BG="rgb(241, 242, 244)", INK="rgb(20, 22, 26)",
        ACCENT="rgb(178, 70, 60)", ACCENT_DEEP="rgb(156, 50, 42)",
        MUTED="rgb(116, 120, 126)", MUTED_GLASS="rgb(124, 128, 134)",
        GLASS="linear-gradient(145deg, rgba(255, 255, 255, 0.86), rgba(255, 255, 255, 0.55))",
        SHADOW="rgba(20, 30, 50, 0.12) 0px 14px 32px 0px",
        _cap=CAP_PLATE_DARK, _cap_fg="rgb(250,250,251)", _cap_hi="rgb(232,150,142)",
        _bg=("background-image:linear-gradient(180deg, rgba(255,255,255,0.7) 0%, "
             "rgba(255,255,255,0) 45%);"),
        _pip={},
    ),
    "ink": dict(
        BG="rgb(23, 23, 20)", INK="rgb(245, 244, 241)",
        ACCENT="rgb(221, 132, 120)", ACCENT_DEEP="rgb(195, 100, 93)",
        MUTED="rgb(152, 150, 144)", MUTED_GLASS="rgb(166, 164, 158)",
        GLASS="linear-gradient(145deg, rgba(255, 255, 255, 0.12), rgba(255, 255, 255, 0.04))",
        SHADOW="rgba(0, 0, 0, 0.45) 0px 14px 32px 0px",
        _cap=CAP_PLATE_LIGHT, _cap_fg="rgb(23,23,20)", _cap_hi="rgb(179,58,50)",
        _pip={"_all": dict(borderRadius=44)},
    ),
    "bold": dict(
        BG="rgb(250, 248, 244)", INK="rgb(18, 18, 16)",
        ACCENT="rgb(198, 74, 64)", ACCENT_DEEP="rgb(179, 58, 50)",
        MUTED="rgb(120, 120, 118)", MUTED_GLASS="rgb(138, 138, 136)",
        GLASS="linear-gradient(145deg, rgba(255, 255, 255, 0.78), rgba(255, 255, 255, 0.40))",
        SHADOW="rgba(30, 26, 18, 0.16) 0px 16px 36px 0px",
        _cap=CAP_BARE_BIG, _cap_fg="rgb(18,18,16)", _cap_hi="rgb(198,74,64)",
        # PiP уходит вниз-влево и становится скруглённым квадратом
        _pip={
            "_all": dict(borderRadius=44),
            "side_big": dict(x=60, y=1360),
            "side_small": dict(x=60, y=1470),
            "hero_center": dict(width=520, height=520, x=280, y=120),
        },
    ),
}


def apply_preset(name):
    """Переопределяет бренд-токены модуля под выбранный пресет.
    Возвращает (css субтитров, таблица состояний PiP, цвета караоке)."""
    if name not in PRESETS:
        sys.exit(f"Неизвестный пресет: {name}. Доступны: {', '.join(PRESETS)}")
    p = PRESETS[name]
    g = globals()
    for k, v in p.items():
        if not k.startswith("_"):
            g[k] = v
    states = {k: dict(v) for k, v in PIP_STATES.items()}
    over = p["_pip"]
    for k, v in states.items():
        v.update(over.get("_all", {}))
        v.update(over.get(k, {}))
    return p["_cap"], states, (p["_cap_fg"], p["_cap_hi"]), p.get("_bg", "")


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ══════════════════════════════════════════════════════════════════════════════
#  БИБЛИОТЕКА КАРТОЧЕК
#  Каждый билдер: (cid, card, t0) -> dict(css=..., html=..., js=...)
#  t0 — абсолютное время старта карточки на общем таймлайне.
# ══════════════════════════════════════════════════════════════════════════════

def build_hook(cid, c, t0):
    """Зачёркнутое слово + подпись, затем заголовок с акцентом."""
    word = esc(c.get("strike_word", "CapCut"))
    sub = esc(c.get("sub", ""))
    l1 = esc(c.get("line1", ""))
    acc = esc(c.get("accent", ""))
    css = f"""
      #{cid}-strike-group {{ position:absolute; left:0; right:0; top:{c.get('strike_top',840)}px;
        text-align:center; opacity:0; }}
      #{cid}-strike-group .word {{ position:relative; display:inline-block; font-weight:800;
        font-size:{c.get('strike_size',116)}px; letter-spacing:-0.02em; color:{INK}; }}
      #{cid}-strike {{ position:absolute; left:-6px; right:-6px; top:50%; height:10px;
        margin-top:-5px; background:{ACCENT_DEEP}; border-radius:6px;
        transform:scaleX(0); transform-origin:left center; }}
      #{cid}-sub {{ margin-top:30px; font-weight:600; font-size:40px; color:{MUTED}; opacity:0; }}
      #{cid}-headline {{ top:{c.get('headline_top',740)}px; font-size:{c.get('headline_size',100)}px;
        line-height:1.1; }}
    """
    html = f"""
        <div id="{cid}-strike-group">
          <span class="word">{word}<span id="{cid}-strike"></span></span>
          {f'<div id="{cid}-sub">{sub}</div>' if sub else ''}
        </div>
        <div class="headline" id="{cid}-headline" data-layout-allow-overlap>
          <span class="line" id="{cid}-l1">{l1}</span>
          {f'<span class="line" id="{cid}-l2"><span class="accent">{acc}</span></span>' if acc else ''}
        </div>
    """
    js = f"""
      tl.fromTo("#{cid}-strike-group", {{opacity:0, scale:0.85}}, {{opacity:1, scale:1, duration:0.35, ease:"back.out(1.8)"}}, {t0+0.25:.2f});
      tl.fromTo("#{cid}-strike", {{scaleX:0}}, {{scaleX:1, duration:0.32, ease:"power2.inOut"}}, {t0+0.75:.2f});
      {f'tl.fromTo("#{cid}-sub", {{opacity:0, y:12}}, {{opacity:1, y:0, duration:0.3, ease:"power2.out"}}, {t0+1.05:.2f});' if sub else ''}
      tl.to("#{cid}-strike-group", {{opacity:0, y:-24, duration:0.3, ease:"power2.in"}}, {t0+2.55:.2f});
      tl.fromTo("#{cid}-l1", {{opacity:0, y:46}}, {{opacity:1, y:0, duration:0.45, ease:"power3.out"}}, {t0+2.85:.2f});
      {f'tl.fromTo("#{cid}-l2", {{opacity:0, y:46}}, {{opacity:1, y:0, duration:0.45, ease:"power3.out"}}, {t0+3.05:.2f});' if acc else ''}
    """
    return dict(css=css, html=html, js=js)


def build_headline(cid, c, t0):
    """Заголовок в несколько строк, последняя может быть акцентной."""
    lines = c.get("lines", [])
    accent_last = c.get("accent_last", True)
    css = f"""
      #{cid}-headline {{ top:{c.get('top',780)}px; font-size:{c.get('size',92)}px;
        line-height:1.14; padding:0 70px; }}
    """
    spans, js_parts = [], []
    for i, ln in enumerate(lines):
        is_acc = accent_last and i == len(lines) - 1
        inner = f'<span class="accent">{esc(ln)}</span>' if is_acc else esc(ln)
        spans.append(f'<span class="line" id="{cid}-l{i}">{inner}</span>')
        js_parts.append(
            f'tl.fromTo("#{cid}-l{i}", {{opacity:0, y:40}}, '
            f'{{opacity:1, y:0, duration:0.4, ease:"power3.out"}}, {t0+0.05+i*0.18:.2f});'
        )
    html = f'<div class="headline" id="{cid}-headline" data-layout-allow-overlap>{"".join(spans)}</div>'
    return dict(css=css, html=html, js="\n      ".join(js_parts))


def build_pills_merge(cid, c, t0):
    """Две пилюли сливаются -> чипы разбора -> итоговый заголовок."""
    left = esc(c.get("left", ""))
    right = esc(c.get("right", ""))
    chips = c.get("chips", [])
    out_lines = c.get("out_lines", [])
    css = f"""
      .{cid}-pill {{ position:absolute; top:860px; width:420px; padding:34px 20px;
        border-radius:999px; text-align:center; font-weight:700; font-size:38px; color:{INK};
        background:{GLASS}; backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px);
        box-shadow:{SHADOW}; opacity:0; }}
      #{cid}-pill-l {{ left:-460px; }}
      #{cid}-pill-r {{ right:-460px; }}
      #{cid}-ring {{ position:absolute; left:50%; top:894px; width:60px; height:60px;
        margin-left:-30px; border-radius:999px; background:{ACCENT_DEEP}; opacity:0;
        transform:scale(0); }}
      #{cid}-chips {{ position:absolute; left:0; right:0; top:860px; display:flex;
        justify-content:center; gap:20px; flex-wrap:wrap; padding:0 60px; }}
      .{cid}-chip {{ padding:22px 34px; border-radius:999px; background:{GLASS};
        backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px); box-shadow:{SHADOW};
        font-weight:700; font-size:34px; color:{ACCENT}; opacity:0; transform:scale(0.6); }}
      #{cid}-headline {{ top:800px; font-size:96px; line-height:1.12; }}
    """
    chip_html = "".join(
        f'<div class="{cid}-chip" id="{cid}-chip{i}">{esc(ch)}</div>' for i, ch in enumerate(chips)
    )
    out_html = "".join(
        f'<span class="line" id="{cid}-o{i}">'
        + (f'<span class="accent">{esc(ln)}</span>' if i == len(out_lines) - 1 else esc(ln))
        + "</span>"
        for i, ln in enumerate(out_lines)
    )
    html = f"""
        <div class="{cid}-pill" id="{cid}-pill-l">{left}</div>
        <div class="{cid}-pill" id="{cid}-pill-r">{right}</div>
        <div id="{cid}-ring"></div>
        <div id="{cid}-chips">{chip_html}</div>
        <div class="headline" id="{cid}-headline" data-layout-allow-overlap>{out_html}</div>
    """
    js = [
        f'tl.fromTo("#{cid}-pill-l", {{opacity:0, x:0}}, {{opacity:1, x:190, duration:0.55, ease:"power3.out"}}, {t0+0.1:.2f});',
        f'tl.fromTo("#{cid}-pill-r", {{opacity:0, x:0}}, {{opacity:1, x:-190, duration:0.55, ease:"power3.out"}}, {t0+0.1:.2f});',
        f'tl.to(["#{cid}-pill-l", "#{cid}-pill-r"], {{opacity:0, duration:0.25, ease:"power2.in"}}, {t0+0.85:.2f});',
        f'tl.fromTo("#{cid}-ring", {{opacity:1, scale:0}}, {{opacity:0, scale:3.2, duration:0.45, ease:"power2.out"}}, {t0+0.85:.2f});',
    ]
    for i in range(len(chips)):
        js.append(
            f'tl.fromTo("#{cid}-chip{i}", {{opacity:0, scale:0.6, y:14}}, '
            f'{{opacity:1, scale:1, y:0, duration:0.3, ease:"back.out(2)"}}, {t0+1.35+i*0.2:.2f});'
        )
    clear_at = t0 + 1.35 + len(chips) * 0.2 + 1.2
    js.append(f'tl.to("#{cid}-chips", {{opacity:0, y:-16, duration:0.3, ease:"power2.in"}}, {clear_at:.2f});')
    for i in range(len(out_lines)):
        js.append(
            f'tl.fromTo("#{cid}-o{i}", {{opacity:0, y:40}}, '
            f'{{opacity:1, y:0, duration:0.45, ease:"power3.out"}}, {clear_at+0.5+i*0.2:.2f});'
        )
    return dict(css=css, html=html, js="\n      ".join(js))


def build_claude_window(cid, c, t0):
    """Окно Claude Code: промпт печатается -> лоадер -> чекмарк 'Готово'."""
    words = c.get("prompt_words", [])
    title = esc(c.get("title", "Claude Code"))
    resp = esc(c.get("response", "Готово"))
    dur = float(c.get("duration", 6.4))
    css = f"""
      #{cid}-win {{ position:absolute; left:50%; margin-left:-440px; top:{c.get('top',800)}px;
        width:880px; padding:44px 50px; border-radius:36px;
        background:linear-gradient(145deg, rgba(255,255,255,0.62), rgba(255,255,255,0.28));
        backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px);
        box-shadow:rgba(38,34,23,0.14) 0px 20px 44px 0px; opacity:0; transform:scale(0.94); }}
      #{cid}-win .bar {{ display:flex; align-items:center; gap:10px; margin-bottom:34px; }}
      #{cid}-win .bar i {{ width:16px; height:16px; border-radius:999px; background:rgba(23,23,20,0.18); }}
      #{cid}-win .bar span {{ font-weight:700; font-size:28px; color:{MUTED_GLASS}; margin-left:10px; }}
      #{cid}-win .row {{ display:flex; align-items:baseline; gap:16px; flex-wrap:wrap;
        font-weight:700; font-size:44px; color:{INK}; min-height:60px; }}
      #{cid}-caret {{ color:{ACCENT_DEEP}; opacity:0; }}
      .{cid}-w {{ opacity:0; }}
      #{cid}-cursor {{ display:inline-block; width:6px; height:46px; background:{ACCENT_DEEP};
        margin-left:2px; opacity:0; }}
      #{cid}-div {{ height:2px; background:rgba(23,23,20,0.1); margin:34px 0;
        transform:scaleX(0); transform-origin:left center; }}
      #{cid}-resp {{ display:flex; align-items:center; gap:18px; opacity:0; }}
      #{cid}-loader {{ display:flex; gap:10px; }}
      #{cid}-loader i {{ width:16px; height:16px; border-radius:999px; background:{ACCENT_DEEP}; opacity:0.3; }}
      #{cid}-check {{ width:44px; height:44px; border-radius:999px; background:{ACCENT_DEEP};
        display:flex; align-items:center; justify-content:center; flex:none; transform:scale(0); }}
      #{cid}-check svg {{ width:24px; height:24px; }}
      #{cid}-label {{ font-weight:700; font-size:36px; color:{INK}; opacity:0; }}
    """
    wspans = "".join(f'<span class="{cid}-w" id="{cid}-w{i}">{esc(w)}</span>' for i, w in enumerate(words))
    html = f"""
        <div id="{cid}-win">
          <div class="bar"><i></i><i></i><i></i><span>{title}</span></div>
          <div class="row">
            <span id="{cid}-caret">&gt;</span>{wspans}<span id="{cid}-cursor"></span>
          </div>
          <div id="{cid}-div"></div>
          <div id="{cid}-resp">
            <div id="{cid}-loader"><i id="{cid}-d1"></i><i id="{cid}-d2"></i><i id="{cid}-d3"></i></div>
            <div id="{cid}-check"><svg viewBox="0 0 24 24" fill="none"><path d="M4 12.5L9.5 18L20 6"
              stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
            <span id="{cid}-label">{resp}</span>
          </div>
        </div>
    """
    js = [f'tl.fromTo("#{cid}-win", {{opacity:0, scale:0.94}}, {{opacity:1, scale:1, duration:0.4, ease:"power2.out"}}, {t0+0.2:.2f});',
          f'tl.to("#{cid}-caret", {{opacity:1, duration:0.15}}, {t0+0.57:.2f});']
    for i in range(len(words)):
        js.append(f'tl.to("#{cid}-w{i}", {{opacity:1, duration:0.12}}, {t0+0.77+i*0.25:.2f});')
    tw = t0 + 0.77 + len(words) * 0.25
    js += [
        f'tl.fromTo("#{cid}-cursor", {{opacity:0}}, {{opacity:1, duration:0.15}}, {tw+0.15:.2f});',
        f'tl.to("#{cid}-cursor", {{opacity:0.15, duration:0.3, ease:"steps(1)", repeat:3, yoyo:true}}, {tw+0.35:.2f});',
        f'tl.fromTo("#{cid}-div", {{scaleX:0}}, {{scaleX:1, duration:0.35, ease:"power2.inOut"}}, {tw+0.9:.2f});',
        f'tl.to("#{cid}-resp", {{opacity:1, duration:0.2}}, {tw+1.15:.2f});',
    ]
    for i in range(3):
        js.append(
            f'tl.fromTo("#{cid}-d{i+1}", {{opacity:0.3, y:0}}, '
            f'{{opacity:1, y:-8, duration:0.3, ease:"sine.inOut", repeat:3, yoyo:true}}, {tw+1.2+i*0.15:.2f});'
        )
    end = t0 + dur
    js += [
        f'tl.to("#{cid}-loader", {{opacity:0, duration:0.2, ease:"power2.in"}}, {end-1.0:.2f});',
        f'tl.fromTo("#{cid}-check", {{scale:0}}, {{scale:1, duration:0.3, ease:"back.out(2.4)"}}, {end-0.9:.2f});',
        f'tl.fromTo("#{cid}-label", {{opacity:0, x:-10}}, {{opacity:1, x:0, duration:0.3, ease:"power2.out"}}, {end-0.75:.2f});',
        f'tl.to("#{cid}-win", {{opacity:0, duration:0.25, ease:"power2.in"}}, {end-0.3:.2f});',
    ]
    return dict(css=css, html=html, js="\n      ".join(js))


def build_checklist(cid, c, t0):
    """Заголовок + стеклянная карточка с чек-пунктами, которые тикают по очереди."""
    lines = c.get("lines", [])
    steps = c.get("steps", [])
    check = """<svg viewBox="0 0 24 24" fill="none"><path d="M4 12.5L9.5 18L20 6"
                stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>"""
    css = f"""
      #{cid}-headline {{ top:{c.get('top',740)}px; font-size:{c.get('size',108)}px; line-height:1.08; }}
      #{cid}-wrap {{ position:absolute; left:50%; bottom:{c.get('card_bottom',420)}px;
        margin-left:-410px; width:820px; opacity:0; }}
      #{cid}-card {{ width:100%; padding:40px 48px; border-radius:999px; background:{GLASS};
        backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px); box-shadow:{SHADOW};
        display:flex; align-items:center; justify-content:center; gap:28px; }}
      .{cid}-step {{ display:flex; align-items:center; gap:14px; opacity:0.28; }}
      .{cid}-step .dot {{ width:40px; height:40px; border-radius:999px; background:{ACCENT_DEEP};
        display:flex; align-items:center; justify-content:center; flex:none; transform:scale(0); }}
      .{cid}-step .dot svg {{ width:20px; height:20px; }}
      .{cid}-step .lbl {{ font-weight:600; font-size:34px; color:{INK}; white-space:nowrap; }}
      .{cid}-step .arr {{ font-weight:600; font-size:30px; color:{MUTED_GLASS}; margin-left:6px; }}
    """
    hl = "".join(
        f'<span class="line" id="{cid}-l{i}">'
        + (f'<span class="accent" id="{cid}-acc">{esc(ln)}</span>' if i == len(lines) - 1 else esc(ln))
        + "</span>"
        for i, ln in enumerate(lines)
    )
    steps_html = "".join(
        f'<div class="{cid}-step" id="{cid}-s{i}"><span class="dot">{check}</span>'
        f'<span class="lbl">{esc(s)}</span>'
        + ('<span class="arr">&gt;</span>' if i < len(steps) - 1 else "")
        + "</div>"
        for i, s in enumerate(steps)
    )
    html = f"""
        <div class="headline" id="{cid}-headline" data-layout-allow-overlap>{hl}</div>
        <div id="{cid}-wrap"><div id="{cid}-card">{steps_html}</div></div>
    """
    js = []
    for i in range(len(lines)):
        js.append(
            f'tl.fromTo("#{cid}-l{i}", {{opacity:0, y:46}}, '
            f'{{opacity:1, y:0, duration:0.45, ease:"power3.out"}}, {t0+0.05+i*0.2:.2f});'
        )
    if lines:
        js += [
            f'tl.fromTo("#{cid}-acc", {{scale:1}}, {{scale:1.14, duration:0.18, ease:"power2.out"}}, {t0+0.62:.2f});',
            f'tl.to("#{cid}-acc", {{scale:1, duration:0.22, ease:"back.out(2)"}}, {t0+0.8:.2f});',
        ]
    js.append(f'tl.fromTo("#{cid}-wrap", {{opacity:0, y:40}}, {{opacity:1, y:0, duration:0.4, ease:"power2.out"}}, {t0+0.95:.2f});')
    for i in range(len(steps)):
        at = t0 + 1.35 + i * 0.33
        js.append(f'tl.to("#{cid}-s{i}", {{opacity:1, duration:0.12}}, {at:.2f});')
        js.append(f'tl.fromTo("#{cid}-s{i} .dot", {{scale:0}}, {{scale:1, duration:0.24, ease:"back.out(2.4)"}}, {at:.2f});')
    return dict(css=css, html=html, js="\n      ".join(js))


def build_chat_edits(cid, c, t0):
    """Чат-пузырь с печатающейся правкой -> тэги с чекмарками -> финальный укол."""
    words = c.get("bubble_words", [])
    tags = c.get("tags", [])
    final = c.get("final_strike", "")
    dur = float(c.get("duration", 12.5))
    check = """<svg viewBox="0 0 24 24" fill="none"><path d="M4 12.5L9.5 18L20 6"
                stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>"""
    css = f"""
      #{cid}-bubble {{ position:absolute; left:90px; right:90px; top:760px; padding:44px 46px;
        border-radius:44px; background:{GLASS}; backdrop-filter:blur(18px);
        -webkit-backdrop-filter:blur(18px); box-shadow:{SHADOW}; font-weight:600; font-size:42px;
        line-height:1.32; color:{INK}; opacity:0; }}
      #{cid}-bubble .w {{ opacity:0; }}
      #{cid}-tags {{ position:absolute; left:0; right:0; top:900px; display:flex;
        justify-content:center; gap:18px; flex-wrap:wrap; padding:0 60px; }}
      .{cid}-tag {{ display:flex; align-items:center; gap:12px; padding:20px 30px;
        border-radius:999px; background:{GLASS}; backdrop-filter:blur(18px);
        -webkit-backdrop-filter:blur(18px); box-shadow:{SHADOW}; font-weight:700; font-size:32px;
        color:{INK}; opacity:0; transform:scale(0.7); }}
      .{cid}-tag .dot {{ width:32px; height:32px; border-radius:999px; background:{ACCENT_DEEP};
        display:flex; align-items:center; justify-content:center; flex:none; transform:scale(0); }}
      .{cid}-tag .dot svg {{ width:17px; height:17px; }}
      #{cid}-fin {{ position:absolute; left:0; right:0; top:900px; text-align:center; opacity:0; }}
      #{cid}-fin .word {{ position:relative; display:inline-block; font-weight:800; font-size:100px;
        letter-spacing:-0.02em; color:{INK}; }}
      #{cid}-fin-strike {{ position:absolute; left:-6px; right:-6px; top:50%; height:9px;
        margin-top:-4.5px; background:{ACCENT_DEEP}; border-radius:6px; transform:scaleX(0);
        transform-origin:left center; }}
    """
    wh = " ".join(f'<span class="w" id="{cid}-w{i}">{esc(w)}</span>' for i, w in enumerate(words))
    th = "".join(
        f'<div class="{cid}-tag" id="{cid}-t{i}"><span class="dot">{check}</span>{esc(t)}</div>'
        for i, t in enumerate(tags)
    )
    html = f"""
        <div id="{cid}-bubble">{wh}</div>
        <div id="{cid}-tags">{th}</div>
        {f'<div id="{cid}-fin"><span class="word">{esc(final)}<span id="{cid}-fin-strike"></span></span></div>' if final else ''}
    """
    js = [f'tl.fromTo("#{cid}-bubble", {{opacity:0, y:30}}, {{opacity:1, y:0, duration:0.35, ease:"power3.out"}}, {t0+0.1:.2f});']
    for i in range(len(words)):
        js.append(f'tl.to("#{cid}-w{i}", {{opacity:1, duration:0.1}}, {t0+0.45+i*0.22:.2f});')
    bubble_end = t0 + 0.45 + len(words) * 0.22 + 0.4
    js.append(f'tl.to("#{cid}-bubble", {{opacity:0, y:-20, duration:0.3, ease:"power2.in"}}, {bubble_end:.2f});')
    for i in range(len(tags)):
        at = bubble_end + 0.4 + i * 0.35
        js.append(f'tl.fromTo("#{cid}-t{i}", {{opacity:0, scale:0.7}}, {{opacity:1, scale:1, duration:0.3, ease:"back.out(2)"}}, {at:.2f});')
        js.append(f'tl.fromTo("#{cid}-t{i} .dot", {{scale:0}}, {{scale:1, duration:0.22, ease:"back.out(2.4)"}}, {at+0.08:.2f});')
    if final:
        end = t0 + dur
        js += [
            f'tl.to("#{cid}-tags", {{opacity:0, y:-16, duration:0.3, ease:"power2.in"}}, {end-4.9:.2f});',
            f'tl.fromTo("#{cid}-fin", {{opacity:0, scale:0.85}}, {{opacity:1, scale:1, duration:0.35, ease:"back.out(1.8)"}}, {end-4.4:.2f});',
            f'tl.fromTo("#{cid}-fin-strike", {{scaleX:0}}, {{scaleX:1, duration:0.32, ease:"power2.inOut"}}, {end-3.9:.2f});',
        ]
    return dict(css=css, html=html, js="\n      ".join(js))


def build_logo(cid, c, t0):
    """Логотип бренда крупно (SVG из локальной библиотеки) + подпись под ним."""
    src = c.get("src", "")
    label = esc(c.get("label", ""))
    sub = esc(c.get("sub", ""))
    size = int(c.get("size", 260))
    tint = c.get("tint", INK)   # simple-icons отдаёт монохром, красим через filter-free mask
    css = f"""
      #{cid}-logo {{ position:absolute; left:50%; top:{c.get('top',720)}px; margin-left:-{size//2}px;
        width:{size}px; height:{size}px; opacity:0; transform:scale(0.8);
        background-color:{tint}; -webkit-mask:url("{esc(src)}") no-repeat center / contain;
        mask:url("{esc(src)}") no-repeat center / contain; }}
      #{cid}-label {{ position:absolute; left:0; right:0; top:{c.get('top',720)+size+50}px;
        text-align:center; font-weight:800; font-size:{c.get('label_size',84)}px;
        letter-spacing:-0.02em; color:{INK}; opacity:0; }}
      #{cid}-sub {{ position:absolute; left:0; right:0; top:{c.get('top',720)+size+50+int(c.get('label_size',84))*1.25:.0f}px;
        text-align:center; font-weight:600; font-size:44px; color:{ACCENT}; opacity:0; }}
    """
    html = (f'<div id="{cid}-logo"></div>'
            + (f'<div id="{cid}-label">{label}</div>' if label else "")
            + (f'<div id="{cid}-sub">{sub}</div>' if sub else ""))
    js = [f'tl.fromTo("#{cid}-logo", {{opacity:0, scale:0.8}}, '
          f'{{opacity:1, scale:1, duration:0.45, ease:"back.out(2)"}}, {t0+0.1:.2f});']
    if label:
        js.append(f'tl.fromTo("#{cid}-label", {{opacity:0, y:24}}, {{opacity:1, y:0, duration:0.35, ease:"power3.out"}}, {t0+0.45:.2f});')
    if sub:
        js.append(f'tl.fromTo("#{cid}-sub", {{opacity:0, y:20}}, {{opacity:1, y:0, duration:0.35, ease:"power3.out"}}, {t0+0.68:.2f});')
    return dict(css=css, html=html, js="\n      ".join(js))


def build_broll(cid, c, t0):
    """B-roll: картинка или видео на весь кадр (или вставкой) + опциональная подпись."""
    src = c.get("src", "")
    is_video = str(src).lower().endswith((".mp4", ".webm", ".mov"))
    caption = esc(c.get("caption", ""))
    dur = float(c.get("duration", 3.0))
    zoom = float(c.get("ken_burns", 1.08))  # анимация статики вместо генерации видео
    css = f"""
      #{cid}-media {{ position:absolute; inset:0; width:100%; height:100%; object-fit:cover; }}
      #{cid}-cap {{ position:absolute; left:0; right:0; margin:0 auto; bottom:420px;
        width:max-content; max-width:900px; text-align:center; font-weight:800; font-size:64px;
        color:rgb(23,23,20); background:rgba(245,244,241,0.92); padding:18px 34px; border-radius:26px;
        opacity:0; }}
    """
    if is_video:
        media = (f'<video id="{cid}-media" class="clip" src="{esc(src)}" muted playsinline '
                 f'data-start="{t0}" data-duration="{dur}" data-track-index="3"></video>')
        js_media = ""
    else:
        # overflow при Ken Burns намеренный: зум не должен открывать поля по краям
        media = f'<img id="{cid}-media" src="{esc(src)}" alt="" data-layout-allow-overflow>'
        js_media = (f'tl.fromTo("#{cid}-media", {{scale:1}}, {{scale:{zoom}, '
                    f'duration:{dur:.2f}, ease:"none"}}, {t0:.2f});')
    js = [js_media]
    if caption:
        js.append(f'tl.fromTo("#{cid}-cap", {{opacity:0, y:20}}, {{opacity:1, y:0, duration:0.3, ease:"power2.out"}}, {t0+0.3:.2f});')
    html = media + (f'<div id="{cid}-cap">{caption}</div>' if caption else "")
    return dict(css=css, html=html, js="\n      ".join(x for x in js if x))


def build_shot(cid, c, t0):
    """Реальный скриншот интерфейса карточкой в верхней зоне кадра.
    В отличие от `broll` не растягивается на весь кадр: скриншот должен остаться
    читаемым, поэтому он вписывается по ширине и получает рамку и тень."""
    src = c.get("src", "")
    width = int(c.get("width", 900))
    top = int(c.get("top", 220))
    caption = esc(c.get("caption", ""))
    zoom = float(c.get("ken_burns", 1.04))
    dur = float(c.get("duration", 3.0))
    css = f"""
      #{cid}-shot {{ position:absolute; left:0; right:0; margin:0 auto; top:{top}px;
        width:{width}px; border-radius:20px; overflow:hidden; box-shadow:{SHADOW};
        border:1px solid rgba(23,23,20,0.10); opacity:0; }}
      #{cid}-shot img {{ display:block; width:100%; }}
      #{cid}-shotcap {{ position:absolute; left:0; right:0; margin:0 auto; top:{top - 110}px;
        width:max-content; max-width:940px; text-align:center; font-weight:800; font-size:64px;
        letter-spacing:-0.02em; color:{INK}; opacity:0; }}
      #{cid}-shotcap .accent {{ color:{ACCENT}; }}
    """
    html = (f'<div id="{cid}-shot" data-layout-allow-overflow><img src="{esc(src)}" alt=""></div>'
            + (f'<div id="{cid}-shotcap">{caption}</div>' if caption else ""))
    js = [f'tl.fromTo("#{cid}-shot", {{opacity:0, y:40, scale:0.97}}, '
          f'{{opacity:1, y:0, scale:1, duration:0.45, ease:"power3.out"}}, {t0+0.1:.2f});',
          f'tl.to("#{cid}-shot", {{scale:{zoom}, duration:{max(dur - 0.5, 0.5):.2f}, ease:"none"}}, {t0+0.55:.2f});']
    if caption:
        js.append(f'tl.fromTo("#{cid}-shotcap", {{opacity:0, y:18}}, '
                  f'{{opacity:1, y:0, duration:0.3, ease:"power2.out"}}, {t0+0.35:.2f});')
    return dict(css=css, html=html, js="\n      ".join(js))


BASE_DIR = pathlib.Path(".")   # выставляется в build(), нужен билдерам, читающим файлы


def build_lottie(cid, c, t0):
    """Векторная Lottie-анимация. JSON вшивается в html, а не грузится по path:
    плеер должен быть готов уже на первом кадре, иначе первые кадры захвата пустые.
    Позицию анимации ведёт НАШ таймлайн (goToAndStop), поэтому seek детерминирован:
    проверено двумя рендерами, кадры совпали побайтово."""
    src = c.get("src", "")
    size = int(c.get("size", 640))
    top = int(c.get("top", 620))
    dur = float(c.get("duration", 3.0))
    lead = float(c.get("lead_in", 0.25))
    data = (BASE_DIR / src).resolve()
    if not data.exists():
        sys.exit(f"Lottie не найден: {data}")
    payload = json.dumps(json.loads(data.read_text(encoding="utf-8")),
                         ensure_ascii=False, separators=(",", ":"))
    css = f"""
      #{cid}-lot {{ position:absolute; left:0; right:0; margin:0 auto; top:{top}px;
        width:{size}px; height:{size}px; opacity:0; }}
    """
    html = f'<div id="{cid}-lot"></div>'
    lines = [
        f'const {cid}_data = {payload};',
        f'const {cid}_anim = lottie.loadAnimation({{container:document.getElementById("{cid}-lot"), '
        f'renderer:"svg", loop:false, autoplay:false, animationData:{cid}_data}});',
        f'const {cid}_head = {{f:0}};',
        f'{cid}_anim.goToAndStop(0, true);',
        f'tl.fromTo("#{cid}-lot", {{opacity:0, scale:0.92}}, '
        f'{{opacity:1, scale:1, duration:0.4, ease:"power3.out"}}, {t0+0.1:.2f});',
        f'tl.to({cid}_head, {{f:{cid}_anim.totalFrames - 1, duration:{max(dur - lead, 0.5):.2f}, '
        f'ease:"none", onUpdate:() => {cid}_anim.goToAndStop({cid}_head.f, true)}}, {t0+lead:.2f});',
    ]
    js = "\n      ".join(lines)
    return dict(css=css, html=html, js=js, head=LOTTIE_SCRIPT)


LOTTIE_SCRIPT = ('<script src="https://cdn.jsdelivr.net/npm/lottie-web@5.12.2/'
                 'build/player/lottie.min.js"></script>')


CARD_BUILDERS = {
    "hook": build_hook,
    "headline": build_headline,
    "pills_merge": build_pills_merge,
    "claude_window": build_claude_window,
    "checklist": build_checklist,
    "chat_edits": build_chat_edits,
    "broll": build_broll,
    "shot": build_shot,
    "lottie": build_lottie,
    # библиотека служебной графики (стрелки, галочки, лоадеры) — marks.py.
    # Тема читается в момент вызова, поэтому пресет уже применён.
    "mark": lambda cid, c, t0: marks.build_mark(
        cid, c, t0, dict(accent=ACCENT, ink=INK, muted=MUTED, deep=ACCENT_DEEP,
                         glass=GLASS, shadow=SHADOW, bg=BG)),
    "logo": build_logo,
}


# ══════════════════════════════════════════════════════════════════════════════
#  СУБТИТРЫ
# ══════════════════════════════════════════════════════════════════════════════

def captions_from_words(words_path, max_words=6, gap=0.28, fixes=None):
    """
    Группирует word-level транскрипт Whisper в читаемые фразы.

    Приоритет разрыва: конец предложения > запятая (если фраза уже набрана) >
    пауза в речи > лимит слов. Так фразы не обрываются на середине мысли.
    `fixes` — словарь замен для ошибок распознавания (терминов, брендов, ё).
    """
    fixes = fixes or {}
    words = json.loads(pathlib.Path(words_path).read_text(encoding="utf-8"))

    def fix(token):
        bare = token.strip(" .,!?:;")
        tail = token[len(token.rstrip(" .,!?:;")):] if token.rstrip(" .,!?:;") != token else ""
        for src, dst in fixes.items():
            if bare.lower() == src.lower():
                return dst + tail
        return token

    chunks, cur = [], []
    for w in words:
        txt = fix(str(w.get("word", w.get("text", ""))).strip())
        if not txt:
            continue
        if cur:
            prev = cur[-1]["word"].strip()
            pause = float(w["start"]) - float(cur[-1]["end"])
            brk = (prev.endswith((".", "!", "?"))
                   or (prev.endswith(",") and len(cur) >= 3)
                   or pause > gap
                   or len(cur) >= max_words)
            if brk:
                chunks.append(cur)
                cur = []
        cur.append({"word": txt, "start": float(w["start"]), "end": float(w["end"])})
    if cur:
        chunks.append(cur)
    return [
        {"start": round(ch[0]["start"], 2),
         "duration": round(ch[-1]["end"] - ch[0]["start"], 2),
         "text": " ".join(x["word"] for x in ch),
         "words": [{"word": x["word"], "start": round(x["start"], 2), "end": round(x["end"], 2)}
                   for x in ch]}
        for ch in chunks
    ]


# ══════════════════════════════════════════════════════════════════════════════
#  СБОРКА
# ══════════════════════════════════════════════════════════════════════════════

def build(manifest, base_dir):
    cap_css, pip_states, (cap_fg, cap_hi), bg_extra = apply_preset(manifest.get("preset", "beige"))
    total = float(manifest["duration"])
    cards = manifest.get("cards", [])
    caps_cfg = manifest.get("captions", {}) or {}

    global BASE_DIR
    BASE_DIR = base_dir
    css_parts, html_parts, js_parts, head_parts = [], [], [], []

    # ── карточки ──────────────────────────────────────────────────────────────
    for i, c in enumerate(cards):
        ctype = c["type"]
        if ctype not in CARD_BUILDERS:
            sys.exit(f"Неизвестный тип карточки: {ctype}. Доступны: {', '.join(CARD_BUILDERS)}")
        cid = f"c{i}"
        t0, dur = float(c["start"]), float(c["duration"])
        piece = CARD_BUILDERS[ctype](cid, c, t0)
        css_parts.append(piece["css"])
        if piece.get("head") and piece["head"] not in head_parts:
            head_parts.append(piece["head"])
        html_parts.append(
            f'      <div class="card-host clip" id="{cid}" data-start="{t0}" '
            f'data-duration="{dur}" data-track-index="0">{piece["html"]}\n      </div>'
        )
        js_parts.append(f'      /* {ctype} [{t0} - {t0+dur:.2f}] */\n      {piece["js"]}')

    # ── PiP-раскадровка ───────────────────────────────────────────────────────
    pip = manifest.get("pip", {}) or {}
    pip_js = []
    if pip.get("src"):
        for k, st in enumerate(pip.get("states", [])):
            state = pip_states.get(st["state"])
            if not state:
                sys.exit(f"Неизвестное состояние PiP: {st['state']}. Доступны: {', '.join(pip_states)}")
            at = float(st["at"])
            props = ", ".join(f"{k2}:{v}" for k2, v in state.items())
            if k == 0:
                pip_js.append(f'tl.set("#video-wrap", {{{props}, autoAlpha:1}}, {at:.2f});')
            elif st.get("hidden"):
                pip_js.append(f'tl.to("#video-wrap", {{autoAlpha:0, duration:0.3, ease:"power2.in"}}, {at:.2f});')
            else:
                pip_js.append(f'tl.to("#video-wrap", {{{props}, autoAlpha:1, duration:0.5, ease:"power2.inOut"}}, {at:.2f});')
        pip_js.append(f'tl.to("#video-wrap", {{autoAlpha:0, duration:0.25, ease:"power2.in"}}, {float(pip.get("hide_at", total-0.2)):.2f});')

    # ── субтитры ──────────────────────────────────────────────────────────────
    caps = caps_cfg.get("items")
    if not caps and caps_cfg.get("from_words"):
        wp = (base_dir / caps_cfg["from_words"]).resolve()
        caps = captions_from_words(
            wp,
            max_words=int(caps_cfg.get("max_words", 6)),
            gap=float(caps_cfg.get("gap", 0.28)),
            fixes=caps_cfg.get("fixes") or {},
        )
        print(f"Субтитры собраны из транскрипта: {len(caps)} блоков")
    caps = caps or []
    karaoke = bool(caps_cfg.get("karaoke", True))
    if caps_cfg.get("bottom"):
        # субтитры поднимаются, когда низ кадра занят спикером (состояние bottom_card)
        cap_css = cap_css.replace("bottom:210px", f'bottom:{int(caps_cfg["bottom"])}px')
    cap_html, cap_js = [], []
    for i, cap in enumerate(caps):
        words = cap.get("words") if karaoke else None
        if words:
            # караоке: слово подсвечивается акцентом ровно на своём тайминге
            inner = " ".join(
                f'<span class="cap-w" id="cap{i}w{j}">{esc(w["word"])}</span>'
                for j, w in enumerate(words)
            )
        else:
            inner = esc(cap["text"])
        cap_html.append(
            f'      <div class="cap-line clip" id="cap{i}" data-start="{cap["start"]}" '
            f'data-duration="{cap["duration"]}" data-track-index="2">{inner}</div>'
        )
        cap_js.append(
            f'tl.fromTo("#cap{i}", {{opacity:0, y:10}}, '
            f'{{opacity:1, y:0, duration:0.12, ease:"power2.out"}}, {cap["start"]});'
        )
        if words:
            for j, w in enumerate(words):
                cap_js.append(
                    f'tl.set("#cap{i}w{j}", {{color:CAP_HI}}, {max(w["start"], cap["start"]):.2f});')
                cap_js.append(
                    f'tl.set("#cap{i}w{j}", {{color:CAP_FG}}, {w["end"]:.2f});')

    # ── сборка документа ──────────────────────────────────────────────────────
    pip_block = ""
    if pip.get("src"):
        pip_block = f"""
      <div class="video-wrapper" id="video-wrap">
        <video id="pip-video" class="clip" src="{esc(pip['src'])}" muted playsinline
          data-start="0" data-duration="{pip.get('duration', total)}" data-track-index="1"></video>
      </div>"""
    audio_block = ""
    if manifest.get("audio"):
        audio_block = (f'\n      <audio id="source-audio" src="{esc(manifest["audio"])}" data-start="0" '
                       f'data-duration="{manifest.get("audio_duration", total)}" data-track-index="10" data-volume="1"></audio>')

    return f"""<!doctype html>
<html lang="ru">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=1080, height=1920" />
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
    {"".join(head_parts)}
    <style>
      @font-face {{ font-family:"Manrope"; src:url("assets/fonts/Manrope-cyrillic-var.woff2") format("woff2");
        font-weight:200 800; font-style:normal; }}
      * {{ margin:0; padding:0; box-sizing:border-box; }}
      html, body {{ margin:0; width:1080px; height:1920px; overflow:hidden; background:#000;
        font-family:"Manrope", "Montserrat", sans-serif; }}
      #stage {{ width:100%; height:100%; position:relative; }}
      .video-wrapper {{ position:absolute; top:0; left:0; overflow:hidden;
        box-shadow:0 16px 40px rgba(0,0,0,0.3); border:5px solid {BG}; z-index:5; }}
      .video-wrapper video {{ width:100%; height:100%; object-fit:cover; object-position:50% 50%; }}
      .card-host {{ position:absolute; inset:0; width:1080px; height:1920px; background:{BG};
        {bg_extra} overflow:hidden; z-index:1; }}
      .cap-line {{ {cap_css} }}
      .headline {{ position:absolute; left:0; right:0; display:flex; flex-direction:column;
        align-items:center; gap:14px; text-align:center; font-weight:800; letter-spacing:-0.02em;
        color:{INK}; }}
      .headline .line {{ display:block; opacity:0; transform:translateY(46px); }}
      .headline .accent {{ color:{ACCENT}; }}
{"".join(css_parts)}
    </style>
  </head>
  <body>
    <div id="stage" data-composition-id="main" data-start="0" data-duration="{total}"
      data-width="1080" data-height="1920">
{chr(10).join(html_parts)}
{pip_block}{audio_block}

{chr(10).join(cap_html)}
    </div>
    <script>
      window.__timelines = window.__timelines || {{}};
      const CAP_FG = "{cap_fg}";   /* цвет субтитра */
      const CAP_HI = "{cap_hi}";   /* цвет активного слова (караоке) */
      const tl = gsap.timeline({{ paused: true }});

      /* ── раскадровка PiP ── */
      {chr(10).join("      " + x for x in pip_js).strip()}

{chr(10).join(js_parts)}

      /* ── субтитры ── */
      {chr(10).join("      " + x for x in cap_js).strip()}

      window.__timelines["main"] = tl;
      tl.seek(0);
    </script>
  </body>
</html>
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("manifest")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    mpath = pathlib.Path(args.manifest).resolve()
    manifest = yaml.safe_load(mpath.read_text(encoding="utf-8"))
    html = build(manifest, mpath.parent)
    out = pathlib.Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"Готово: {out}  ({len(html)} символов, карточек: {len(manifest.get('cards', []))})")


if __name__ == "__main__":
    main()
