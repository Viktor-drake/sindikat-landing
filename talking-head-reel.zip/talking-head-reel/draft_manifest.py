# -*- coding: utf-8 -*-
"""
Черновик манифеста из word-level транскрипта: разбивает речь на карточки,
подбирает тип карточки по смыслу фразы и раскладывает PiP.

    python draft_manifest.py projects/my-reel --preset beige > projects/my-reel/manifest.yaml

Это ЧЕРНОВИК, а не финал: тексты карточек нужно переписать руками (в файле они
помечены TODO), логотипы и B-roll подставить из индекса (`assets_index.py --find`).
Смысл в том, что тайминги, границы карточек и раскадровка PiP уже расставлены.
"""
import argparse
import json
import pathlib
import re
import sys

BRANDS = {
    "claude": "claude", "anthropic": "anthropic", "google": "google", "гугл": "google",
    "яндекс": "yandex", "chatgpt": "openai", "openai": "openai", "гпт": "openai",
    "perplexity": "perplexity", "playwright": "playwright", "firecrawl": "firecrawl",
    "github": "github", "телеграм": "telegram", "инстаграм": "instagram",
    "figma": "figma", "фигма": "figma", "tiktok": "tiktok", "youtube": "youtube",
}
PROMPT_HINTS = ("промпт", "напиш", "отправ", "строк", "запрос", "диалог", "команд")
LIST_HINTS = ("первый", "второй", "третий", "во-первых", "шаг")

MAX_CARD = 5.5   # длиннее карточку держать скучно, режем пополам
MIN_CARD = 2.0


def sentences(words):
    out, cur = [], []
    for w in words:
        cur.append(w)
        if str(w.get("word", "")).strip().endswith((".", "!", "?")):
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def split_long(chunk):
    """Режет длинную фразу пополам по границе слова."""
    dur = chunk[-1]["end"] - chunk[0]["start"]
    if dur <= MAX_CARD or len(chunk) < 6:
        return [chunk]
    mid = len(chunk) // 2
    return [chunk[:mid], chunk[mid:]]


def text_of(chunk):
    return " ".join(str(w["word"]).strip() for w in chunk).strip()


def lines_from(text, max_len=22):
    """Наивная разбивка фразы на 2-3 строки заголовка."""
    words, lines, cur = text.strip(" .,!?").split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > max_len and cur:
            lines.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return lines[:3]


def pick_type(text, idx, broll_counter):
    low = text.lower()
    for key, logo in BRANDS.items():
        if key in low:
            return "logo", logo
    if any(h in low for h in PROMPT_HINTS):
        return "claude_window", None
    if low.count(",") >= 2 or any(h in low for h in LIST_HINTS):
        return "checklist", None
    if broll_counter % 3 == 2:
        return "broll", None
    return "headline", None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("task", help="папка задачи (в ней _артефакты/heygen_words.json)")
    ap.add_argument("--preset", default="beige")
    ap.add_argument("--words", default="_артефакты/heygen_words.json")
    a = ap.parse_args()

    task = pathlib.Path(a.task)
    wpath = task / a.words
    if not wpath.exists():
        sys.exit(f"Нет word-level транскрипта: {wpath}")
    words = json.loads(wpath.read_text(encoding="utf-8"))
    total = round(float(words[-1]["end"]) + 0.06, 2)

    chunks = []
    for s in sentences(words):
        chunks.extend(split_long(s))

    cards, states, broll_n = [], [], 0
    for i, ch in enumerate(chunks):
        start = round(float(ch[0]["start"]), 2)
        end = round(float(chunks[i + 1][0]["start"]) if i + 1 < len(chunks) else total, 2)
        dur = round(max(end - start, MIN_CARD), 2)
        text = text_of(ch)
        ctype, logo = ("hook", None) if i == 0 else pick_type(text, i, broll_n)
        if ctype == "broll":
            broll_n += 1
        else:
            broll_n += 1 if ctype == "headline" else 0

        cards.append(dict(i=i, type=ctype, start=start, duration=dur, text=text, logo=logo))
        # PiP: крупно на первой карточке, дальше чередование, на картинке мельче
        state = "hero_center" if i == 0 else ("side_small" if ctype in ("broll", "claude_window")
                                              else ("side_big" if i % 2 else "side_small"))
        if not states or states[-1][1] != state:
            states.append((start, state))

    out = [f'# ЧЕРНОВИК манифеста, сгенерирован draft_manifest.py. Тексты карточек переписать руками.',
           f'preset: {a.preset}',
           f'duration: {total}',
           'audio: assets/heygen_audio.m4a',
           '',
           'pip:',
           '  src: assets/pip_source.mp4',
           f'  duration: {total}',
           f'  hide_at: {round(total - 0.2, 2)}',
           '  states:']
    for at, st in states:
        out.append(f'    - {{at: {at}, state: {st}}}')
    out += ['', 'captions:', f'  from_words: {a.words}', '  max_words: 7', '  karaoke: true',
            '  fixes: {}', '', 'cards:']

    for c in cards:
        out.append(f'  # [{c["start"]}] {c["text"]}')
        out.append(f'  - type: {c["type"]}')
        out.append(f'    start: {c["start"]}')
        out.append(f'    duration: {c["duration"]}')
        ls = lines_from(c["text"])
        if c["type"] == "hook":
            out += ['    strike_word: TODO', f'    line1: TODO {ls[0] if ls else ""}',
                    '    accent: TODO', '    sub: TODO']
        elif c["type"] == "headline":
            out += ['    top: 820', '    size: 100', f'    lines: [{", ".join(ls)}]  # TODO сократить']
        elif c["type"] == "checklist":
            out += ['    top: 700', '    size: 96', f'    lines: [{", ".join(ls[:2])}]  # TODO сократить',
                    '    steps: [TODO, TODO, TODO]  # по ОДНОМУ слову на шаг', '    card_bottom: 620']
        elif c["type"] == "logo":
            out += [f'    src: assets/logos/{c["logo"]}.svg', '    size: 200', '    top: 700',
                    '    label: TODO', '    sub: TODO']
        elif c["type"] == "claude_window":
            out += ['    prompt_words: [TODO, TODO, TODO]', '    response: Готово']
        elif c["type"] == "broll":
            out += ['    src: assets/broll/TODO.png  # assets_index.py --find "..."',
                    '    caption: TODO', '    ken_burns: 1.08']
        out.append('')

    print("\n".join(out))


if __name__ == "__main__":
    main()
