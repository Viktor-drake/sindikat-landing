"""Word-level транскрипт клипа. Кладётся в папку ролика, запускается один раз."""
import json, pathlib
from faster_whisper import WhisperModel

m = WhisperModel("medium", device="cpu", compute_type="int8")
segs, _ = m.transcribe("avatar.mp4", language="ru", word_timestamps=True,
                       initial_prompt="термины, бренды и имена собственные через запятую")
w = [{"word": x.word, "start": round(x.start, 2), "end": round(x.end, 2)}
     for s in segs for x in s.words]
pathlib.Path("_words.json").write_text(json.dumps(w, ensure_ascii=False, indent=1), encoding="utf-8")
print("words:", len(w), "last:", w[-1]["end"])
