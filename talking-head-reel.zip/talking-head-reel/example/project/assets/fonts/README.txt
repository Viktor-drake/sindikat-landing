Шрифт сюда: любой variable woff2 с кириллицей (например Manrope).
