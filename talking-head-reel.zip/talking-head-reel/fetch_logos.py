# -*- coding: utf-8 -*-
"""
Наполняет локальную библиотеку логотипов для роликов.

Зачем локально: HyperFrames запрещает сетевые запросы во время рендера
(детерминизм), поэтому иконки должны лежать файлами рядом с проектом.

Источники (оба бесплатные, без ключей):
  1. Simple Icons  — ~3400 монохромных брендов, лицензия CC0 (можно всё)
  2. svgl          — ~600 цветных логотипов, MIT (fallback)

Запуск:
    python fetch_logos.py claude youtube instagram --out "_assets/logos"
    python fetch_logos.py --preset reels        # базовый набор под наши ролики
"""
import argparse
import json
import pathlib
import sys
import urllib.request

SIMPLE = "https://cdn.jsdelivr.net/npm/simple-icons@latest/icons/{}.svg"
SVGL_API = "https://api.svgl.app?search={}"

PRESETS = {
    "reels": ["claude", "openai", "instagram", "youtube", "telegram", "tiktok", "github", "figma"],
}


def get(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def fetch_simple(slug):
    try:
        return get(SIMPLE.format(slug)), "simple-icons (CC0)"
    except Exception:
        return None, None


def fetch_svgl(slug):
    try:
        data = json.loads(get(SVGL_API.format(slug)).decode("utf-8"))
        if isinstance(data, dict) and data.get("error"):
            return None, None
        if not data:
            return None, None
        route = data[0]["route"]
        if isinstance(route, dict):           # бывает {light, dark}
            route = route.get("light") or next(iter(route.values()))
        return get(route), f"svgl (MIT): {data[0]['title']}"
    except Exception:
        return None, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slugs", nargs="*", help="claude youtube instagram ...")
    ap.add_argument("--preset", choices=sorted(PRESETS), help="готовый набор")
    ap.add_argument("--out", default="_assets/logos")
    args = ap.parse_args()

    slugs = list(args.slugs)
    if args.preset:
        slugs += PRESETS[args.preset]
    if not slugs:
        sys.exit("Укажи слаги брендов или --preset reels")

    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    ok, missing = [], []
    for slug in dict.fromkeys(slugs):          # без дублей, порядок сохраняем
        blob, src = fetch_simple(slug)
        if blob is None:
            blob, src = fetch_svgl(slug)
        if blob is None:
            missing.append(slug)
            print(f"  нет   {slug}")
            continue
        path = out / f"{slug}.svg"
        path.write_bytes(blob)
        ok.append(slug)
        print(f"  ОК    {slug}  <- {src}")

    print(f"\nСкачано {len(ok)} в {out.resolve()}")
    if missing:
        print("Не нашлось:", ", ".join(missing))
        print("Для таких брендов используем текстовое начертание (карточка hook) или свой скриншот.")


if __name__ == "__main__":
    main()
