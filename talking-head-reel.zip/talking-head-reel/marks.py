# -*- coding: utf-8 -*-
"""
Библиотека служебной motion-графики: стрелки, галочки, подчёркивания, лоадеры.

Почему не Lottie из библиотек: готовые анимации там мультяшные и с разными лицензиями,
а нам нужны десять предсказуемых элементов В НАШЕМ стиле, которые красятся бренд-цветом
и не требуют ни лицензий, ни сети. Это обычный inline SVG плюс GSAP, поэтому детерминизм
такой же, как у остальных карточек.

Используется из build.py как тип карточки `mark`:

    - type: mark
      shape: arrow_right
      size: 360
      top: 900
      color: accent        # accent | ink | muted
"""
import json


def json_dumps(x):
    """Строка для вставки в JS: кавычки и юникод экранируются корректно."""
    return json.dumps(x, ensure_ascii=False)


# Каждая фигура: (viewBox, svg-нутро, тип анимации)
#   draw     — рисуется штрихом (stroke-dasharray)
#   pop      — появляется масштабом
#   dots     — три точки по очереди
#   progress — полоса заполняется
SHAPES = {
    # 1. Галочка: «сделано», «пункт закрыт»
    "check": ("0 0 100 100", '<path d="M18 54 L40 76 L82 26" />', "draw"),
    # 2. Крестик: «так не надо»
    "cross": ("0 0 100 100", '<path d="M25 25 L75 75" /><path d="M75 25 L25 75" />', "draw"),
    # 3. Стрелка вправо: «было → стало»
    "arrow_right": ("0 0 120 60",
                    '<path d="M6 30 H96" /><path d="M78 13 L100 30 L78 47" />', "draw"),
    # 4. Стрелка вниз: «смотри сюда», подводка к CTA
    "arrow_down": ("0 0 60 120",
                   '<path d="M30 6 H30 V96" /><path d="M13 78 L30 100 L47 78" />', "draw"),
    # 5. Кривая стрелка от руки: «а вот отсюда»
    "arrow_curve": ("0 0 120 90",
                    '<path d="M10 18 C 42 10, 78 28, 92 62" />'
                    '<path d="M72 58 L95 68 L88 44" />', "draw"),
    # 6. Подчёркивание: акцент под словом
    "underline": ("0 0 200 30", '<path d="M6 20 C 55 6, 140 26, 194 12" />', "draw"),
    # 7. Обводка кружком: выделить элемент
    "circle_mark": ("0 0 200 120",
                    '<path d="M100 10 C 170 10, 196 40, 190 66 '
                    'C 182 100, 120 114, 76 110 C 26 104, 6 76, 14 50 '
                    'C 22 24, 60 12, 108 14" />', "draw"),
    # 8. Три точки: «думает», «генерирует»
    "loader": ("0 0 160 40",
               '<circle cx="28" cy="20" r="13" /><circle cx="80" cy="20" r="13" />'
               '<circle cx="132" cy="20" r="13" />', "dots"),
    # 9. Полоса прогресса: «процесс идёт», проценты
    "progress": ("0 0 300 40", "", "progress"),
    # 10. Вспышка: момент «вау», результат
    "spark": ("0 0 100 100",
              '<path d="M50 8 V30" /><path d="M50 70 V92" /><path d="M8 50 H30" />'
              '<path d="M70 50 H92" /><path d="M22 22 L37 37" /><path d="M63 63 L78 78" />'
              '<path d="M78 22 L63 37" /><path d="M37 63 L22 78" />'
              '<circle cx="50" cy="50" r="12" />', "pop"),
    # 11. Курсор-указатель: «нажми», «вот эта кнопка»
    "cursor": ("0 0 80 100",
               '<path d="M14 8 L14 74 L30 58 L42 84 L54 78 L42 52 L64 50 Z" />', "pop"),
    # 12. Скобка-акколада: «всё это вместе»
    "brace": ("0 0 60 200",
              '<path d="M44 6 C 20 6, 34 90, 12 100 C 34 110, 20 194, 44 194" />', "draw"),
}

STROKE_ONLY = {"check", "cross", "arrow_right", "arrow_down", "arrow_curve",
               "underline", "circle_mark", "brace"}


def _esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ── Составные элементы ────────────────────────────────────────────────────────
# Это уже не одна svg-фигура, а маленькие сценки: считающееся число, рамка,
# зачёркивание, курсор, который ходит по кадру и кликает.

def _counter(cid, c, t0, theme):
    """Растущее число: метрика, которая набирается на глазах."""
    frm = float(c.get("from", 0))
    to = float(c.get("to", 100))
    dur = float(c.get("duration", 2.0))
    run = float(c.get("run", max(dur * 0.7, 0.6)))
    size = int(c.get("size", 180))
    top = int(c.get("top", 700))
    prefix, suffix = _esc(c.get("prefix", "")), _esc(c.get("suffix", ""))
    dec = int(c.get("decimals", 0))
    sep = c.get("sep", " ")          # разделитель тысяч
    color = theme.get(c.get("color", "ink"), theme["ink"])
    label = c.get("label")

    css = [f'#{cid}-num {{ position:absolute; left:0; right:0; top:{top}px; text-align:center;',
           f'  font-weight:800; font-size:{size}px; letter-spacing:-0.03em; color:{color};',
           '  opacity:0; font-variant-numeric:tabular-nums; }']
    html = [f'<div id="{cid}-num">{prefix}0{suffix}</div>']
    js = [
        f'const {cid}_v = {{n:{frm}}};',
        f'const {cid}_el = document.getElementById("{cid}-num");',
        f'const {cid}_fmt = (x) => x.toFixed({dec}).replace(/\\B(?=(\\d{{3}})+(?!\\d))/g, "{sep}");',
        f'tl.fromTo("#{cid}-num", {{opacity:0, y:26}}, {{opacity:1, y:0, duration:0.3, '
        f'ease:"power3.out"}}, {t0:.2f});',
        f'tl.to({cid}_v, {{n:{to}, duration:{run:.2f}, ease:"power2.out", onUpdate:() => '
        f'{{ {cid}_el.textContent = "{prefix}" + {cid}_fmt({cid}_v.n) + "{suffix}"; }}}}, {t0 + 0.1:.2f});',
    ]
    if label:
        css += [f'#{cid}-numlabel {{ position:absolute; left:0; right:0; top:{int(top + size * 1.18) + 26}px;',
                f'  text-align:center; font-weight:600; font-size:48px; color:{theme["muted"]};',
                '  opacity:0; }']
        html.append(f'<div id="{cid}-numlabel">{_esc(label)}</div>')
        js.append(f'tl.fromTo("#{cid}-numlabel", {{opacity:0, y:14}}, {{opacity:1, y:0, '
                  f'duration:0.3, ease:"power2.out"}}, {t0 + 0.35:.2f});')
    return css, html, js


def _frame_box(cid, c, t0, theme):
    """Рамка выделения: обвести область на скриншоте."""
    w, h = int(c.get("w", 700)), int(c.get("h", 260))
    x, y = int(c.get("x", 190)), int(c.get("y", 700))
    color = theme.get(c.get("color", "accent"), theme["accent"])
    stroke = int(c.get("stroke", 10))
    dur = float(c.get("duration", 2.0))
    radius = int(c.get("radius", 22))
    label = c.get("label")

    css = [f'#{cid}-box {{ position:absolute; left:{x}px; top:{y}px; width:{w}px; height:{h}px;',
           '  opacity:0; }',
           f'#{cid}-box svg {{ display:block; width:100%; height:100%; overflow:visible; }}']
    html = [f'<div id="{cid}-box"><svg viewBox="0 0 {w} {h}" fill="none" '
            f'xmlns="http://www.w3.org/2000/svg"><rect x="{stroke}" y="{stroke}" '
            f'width="{w - stroke * 2}" height="{h - stroke * 2}" rx="{radius}" stroke="{color}" '
            f'stroke-width="{stroke}" stroke-linecap="round"/></svg></div>']
    # периметр считаем здесь, а не через getTotalLength в браузере:
    # измерение DOM внутри рендера зависит от порядка перемотки и линтер его справедливо ругает
    perim = 2 * ((w - stroke * 2) + (h - stroke * 2))
    js = [f'tl.to("#{cid}-box", {{opacity:1, duration:0.15}}, {t0:.2f});',
          f'gsap.set("#{cid}-box rect", {{strokeDasharray:{perim}, strokeDashoffset:{perim}}});',
          f'tl.to("#{cid}-box rect", {{strokeDashoffset:0, duration:{max(dur * 0.55, 0.45):.2f}, '
          f'ease:"power2.inOut"}}, {t0 + 0.05:.2f});']
    if label:
        css += [f'#{cid}-boxlabel {{ position:absolute; left:{x}px; width:{w}px; '
                f'top:{y - 76}px; text-align:center; font-weight:700; font-size:46px;',
                f'  color:{color}; opacity:0; }}']
        html.append(f'<div id="{cid}-boxlabel">{_esc(label)}</div>')
        js.append(f'tl.fromTo("#{cid}-boxlabel", {{opacity:0, y:12}}, {{opacity:1, y:0, '
                  f'duration:0.28, ease:"power2.out"}}, {t0 + 0.4:.2f});')
    return css, html, js


def _strike_text(cid, c, t0, theme):
    """Текст, который зачёркивается на глазах: «так больше не надо».
    Опционально сверху ставится логотип: «200 $ в месяц» без логотипа Claude Code
    не читается, зрителю нужен якорь, о чьём тарифе речь."""
    text = _esc(c.get("text", "вручную"))
    logo = c.get("logo")
    logo_size = int(c.get("logo_size", 150))
    logo_color = theme.get(c.get("logo_color", "deep"), theme["deep"])
    size = int(c.get("size", 96))
    top = int(c.get("top", 760))
    after = c.get("after")
    color = theme.get(c.get("color", "ink"), theme["ink"])
    line = theme.get(c.get("line_color", "deep"), theme["deep"])

    css = [f'#{cid}-st {{ position:absolute; left:0; right:0; top:{top}px; text-align:center;',
           f'  font-weight:800; font-size:{size}px; letter-spacing:-0.02em; color:{color}; opacity:0; }}',
           f'#{cid}-st .w {{ position:relative; display:inline-block; }}',
           f'#{cid}-line {{ position:absolute; left:-8px; right:-8px; top:50%; height:{max(size // 11, 6)}px;',
           f'  margin-top:-{max(size // 22, 3)}px; background:{line}; border-radius:6px;',
           '  transform:scaleX(0); transform-origin:left center; }']
    html = [f'<div id="{cid}-st"><span class="w">{text}<span id="{cid}-line"></span></span></div>']
    if logo:
        css.insert(0, f'#{cid}-stlogo {{ position:absolute; left:50%; margin-left:-{logo_size // 2}px;'
                      f' top:{top - logo_size - 60}px; width:{logo_size}px; height:{logo_size}px;'
                      f' background-color:{logo_color}; opacity:0;'
                      f' -webkit-mask:url("{_esc(logo)}") no-repeat center / contain;'
                      f' mask:url("{_esc(logo)}") no-repeat center / contain; }}')
        html.insert(0, f'<div id="{cid}-stlogo"></div>')
    js = [f'tl.fromTo("#{cid}-st", {{opacity:0, scale:0.92}}, {{opacity:1, scale:1, '
          f'duration:0.3, ease:"back.out(1.8)"}}, {t0 + (0.25 if logo else 0):.2f});',
          f'tl.fromTo("#{cid}-line", {{scaleX:0}}, {{scaleX:1, duration:0.32, '
          f'ease:"power2.inOut"}}, {t0 + (0.85 if logo else 0.45):.2f});']
    if logo:
        js.insert(0, f'tl.fromTo("#{cid}-stlogo", {{opacity:0, scale:0.8}}, {{opacity:1, scale:1, '
                     f'duration:0.35, ease:"back.out(2)"}}, {t0 + 0.05:.2f});')
    if after:
        css += [f'#{cid}-after {{ position:absolute; left:0; right:0; top:{top + size + 40}px;',
                f'  text-align:center; font-weight:800; font-size:{size}px; letter-spacing:-0.02em;',
                f'  color:{theme["accent"]}; opacity:0; }}']
        html.append(f'<div id="{cid}-after">{_esc(after)}</div>')
        js.append(f'tl.fromTo("#{cid}-after", {{opacity:0, y:34}}, {{opacity:1, y:0, '
                  f'duration:0.4, ease:"power3.out"}}, {t0 + 0.85:.2f});')
    return css, html, js


def _highlight(cid, c, t0, theme):
    """Текст, по которому проезжает маркер."""
    text = _esc(c.get("text", "важное"))
    size = int(c.get("size", 88))
    top = int(c.get("top", 800))
    color = theme.get(c.get("color", "ink"), theme["ink"])
    band = c.get("band", "rgba(195,100,93,0.30)")
    css = [f'#{cid}-hl {{ position:absolute; left:0; right:0; top:{top}px; text-align:center;',
           f'  font-weight:800; font-size:{size}px; letter-spacing:-0.02em; color:{color}; opacity:0; }}',
           f'#{cid}-hl .w {{ position:relative; display:inline-block; padding:0 14px; }}',
           f'#{cid}-band {{ position:absolute; left:0; right:0; top:14%; bottom:6%;',
           f'  background:{band}; border-radius:10px; z-index:-1; transform:scaleX(0);',
           '  transform-origin:left center; }']
    html = [f'<div id="{cid}-hl"><span class="w"><span id="{cid}-band"></span>{text}</span></div>']
    js = [f'tl.fromTo("#{cid}-hl", {{opacity:0, y:20}}, {{opacity:1, y:0, duration:0.3, '
          f'ease:"power3.out"}}, {t0:.2f});',
          f'tl.fromTo("#{cid}-band", {{scaleX:0}}, {{scaleX:1, duration:0.4, '
          f'ease:"power2.inOut"}}, {t0 + 0.35:.2f});']
    return css, html, js


def _cursor_path(cid, c, t0, theme):
    """Курсор идёт по кадру и кликает. Движение только через transform x/y."""
    pts = c.get("points") or [[820, 560], [300, 980], [560, 1360]]
    clicks = set(int(i) for i in (c.get("click_at") or list(range(1, len(pts)))))
    size = int(c.get("size", 92))
    dur = float(c.get("duration", 3.0))
    color = theme.get(c.get("color", "ink"), theme["ink"])
    legs = max(len(pts) - 1, 1)
    hold = 0.32                                   # пауза на клик
    leg_t = max((dur - 0.4 - hold * len(clicks)) / legs, 0.35)

    css = [f'#{cid}-cur {{ position:absolute; left:0; top:0; width:{size}px; '
           f'height:{int(size * 1.25)}px; opacity:0; }}',
           f'#{cid}-cur svg {{ display:block; width:100%; height:100%; overflow:visible; }}',
           f'.{cid}-ring {{ position:absolute; left:{-size // 2}px; top:{-size // 2}px;',
           f'  width:{size * 2}px; height:{size * 2}px; border-radius:999px;',
           f'  border:6px solid {theme["accent"]}; opacity:0; }}']
    # своё кольцо на каждый клик: два fromTo на одном узле ломают базовое состояние при seek
    rings = "".join(f'<div class="{cid}-ring" id="{cid}-ring{i}"></div>' for i in sorted(clicks))
    html = [f'<div id="{cid}-cur">{rings}'
            f'<svg viewBox="0 0 80 100" fill="{color}" xmlns="http://www.w3.org/2000/svg">'
            f'<path d="M14 8 L14 74 L30 58 L42 84 L54 78 L42 52 L64 50 Z" stroke="{theme["ink"]}" '
            f'stroke-width="3" stroke-linejoin="round"/></svg></div>']

    x0, y0 = pts[0]
    js = [f'gsap.set("#{cid}-cur", {{x:{x0}, y:{y0}, transformOrigin:"14px 8px"}});',
          f'tl.to("#{cid}-cur", {{opacity:1, duration:0.2}}, {t0:.2f});']
    t = t0 + 0.25
    for i in range(1, len(pts)):
        x, y = pts[i]
        js.append(f'tl.to("#{cid}-cur", {{x:{x}, y:{y}, duration:{leg_t:.2f}, '
                  f'ease:"power2.inOut"}}, {t:.2f});')
        t += leg_t
        if i in clicks:
            js.append(f'tl.to("#{cid}-cur", {{scale:0.84, duration:0.09, yoyo:true, repeat:1, '
                      f'ease:"power2.out"}}, {t:.2f});')
            js.append(f'tl.fromTo("#{cid}-ring{i}", {{opacity:0.75, scale:0.25}}, {{opacity:0, '
                      f'scale:1, duration:0.42, ease:"power2.out"}}, {t:.2f});')
            t += hold
    js.append(f'tl.to("#{cid}-cur", {{opacity:0, duration:0.2}}, {t0 + dur - 0.2:.2f});')
    return css, html, js


def _type_line(cid, c, t0, theme):
    """Строка набирается посимвольно: команда, промпт, запрос.

    Ширину плашки задаёт СКРЫТЫЙ дубль полного текста, а видимый текст лежит
    поверх него абсолютом. Иначе плашка растёт по мере печати и каретка вылезает
    за её правый край (поймано уже на готовом ролике)."""
    text = str(c.get("text", "npx ecc-universal setup"))
    size = int(c.get("size", 58))
    top = int(c.get("top", 820))
    dur = float(c.get("duration", 3.0))
    run = float(c.get("run", max(dur * 0.55, 0.6)))
    prompt = _esc(c.get("prompt", "> "))
    color = theme.get(c.get("color", "ink"), theme["ink"])
    plate = c.get("plate", True)

    plate_css = (f'background:{theme["glass"]}; box-shadow:{theme["shadow"]}; '
                 f'border-radius:26px; padding:28px 36px;' if plate else "")
    caret_w = max(size // 9, 5)
    css = [f'#{cid}-tl {{ position:absolute; left:0; right:0; margin:0 auto; top:{top}px;',
           f'  width:max-content; max-width:940px; {plate_css}',
           f'  font-family:"JetBrains Mono","SF Mono",Consolas,monospace; font-weight:600;',
           f'  font-size:{size}px; color:{color}; opacity:0; white-space:pre; }}',
           f'#{cid}-tlrow {{ position:relative; display:inline-block; }}',
           f'#{cid}-tlghost {{ visibility:hidden; }}',
           f'#{cid}-tlshow {{ position:absolute; left:0; top:0; white-space:pre; }}',
           f'#{cid}-tlp {{ color:{theme["accent"]}; }}',
           f'#{cid}-caret {{ display:inline-block; width:{caret_w}px;',
           f'  height:{int(size * 0.92)}px; background:{theme["accent"]}; margin-left:6px;',
           '  vertical-align:-0.12em; opacity:0; }']
    ghost = _esc(text)
    html = [f'<div id="{cid}-tl"><span id="{cid}-tlp">{prompt}</span>'
            f'<span id="{cid}-tlrow">'
            f'<span id="{cid}-tlghost">{ghost}'
            f'<span style="display:inline-block; width:{caret_w + 8}px"></span></span>'
            f'<span id="{cid}-tlshow"><span id="{cid}-tlt"></span>'
            f'<span id="{cid}-caret"></span></span></span></div>']
    blinks = max(1, int((dur - run) / 0.6))
    js = [
        f'const {cid}_txt = {json_dumps(text)};',
        f'const {cid}_out = document.getElementById("{cid}-tlt");',
        f'const {cid}_i = {{n:0}};',
        f'tl.fromTo("#{cid}-tl", {{opacity:0, y:22}}, {{opacity:1, y:0, duration:0.3, '
        f'ease:"power3.out"}}, {t0:.2f});',
        f'tl.to("#{cid}-caret", {{opacity:1, duration:0.1}}, {t0 + 0.25:.2f});',
        f'tl.to({cid}_i, {{n:{cid}_txt.length, duration:{run:.2f}, ease:"none", onUpdate:() => '
        f'{{ {cid}_out.textContent = {cid}_txt.slice(0, Math.round({cid}_i.n)); }}}}, {t0 + 0.3:.2f});',
        f'tl.to("#{cid}-caret", {{opacity:0.15, duration:0.3, ease:"steps(1)", yoyo:true, '
        f'repeat:{blinks * 2}}}, {t0 + 0.3 + run:.2f});',
    ]
    return css, html, js


def _compare(cid, c, t0, theme):
    """Две колонки «было и стало»: левая гаснет, правая выезжает."""
    left, right = _esc(c.get("left", "было")), _esc(c.get("right", "стало"))
    lsub, rsub = c.get("left_sub"), c.get("right_sub")
    size = int(c.get("size", 82))
    top = int(c.get("top", 760))
    css = [f'#{cid}-cmpL, #{cid}-cmpR {{ position:absolute; top:{top}px; width:480px;',
           '  text-align:center; font-weight:800; letter-spacing:-0.02em; opacity:0; }',
           f'#{cid}-cmpL {{ left:30px; font-size:{size}px; color:{theme["muted"]}; }}',
           f'#{cid}-cmpR {{ left:570px; font-size:{size}px; color:{theme["ink"]}; }}',
           f'#{cid}-cmpR .a {{ color:{theme["accent"]}; }}',
           f'#{cid}-cmpLs, #{cid}-cmpRs {{ position:absolute; top:{top + size + 34}px;',
           '  width:480px; text-align:center; font-weight:600; font-size:40px; opacity:0; }',
           f'#{cid}-cmpLs {{ left:30px; color:{theme["muted"]}; }}',
           f'#{cid}-cmpRs {{ left:570px; color:{theme["muted"]}; }}',
           f'#{cid}-cmpArrow {{ position:absolute; left:498px; top:{top + size // 3}px;',
           f'  width:84px; height:44px; opacity:0; }}']
    html = [f'<div id="{cid}-cmpL">{left}</div>',
            f'<div id="{cid}-cmpR"><span class="a">{right}</span></div>',
            f'<div id="{cid}-cmpArrow"><svg viewBox="0 0 120 60" fill="none" '
            f'xmlns="http://www.w3.org/2000/svg" stroke="{theme["accent"]}" stroke-width="10" '
            f'stroke-linecap="round" stroke-linejoin="round">'
            f'<path d="M6 30 H96"/><path d="M78 13 L100 30 L78 47"/></svg></div>']
    js = [f'tl.fromTo("#{cid}-cmpL", {{opacity:0, x:-30}}, {{opacity:1, x:0, duration:0.35, '
          f'ease:"power3.out"}}, {t0:.2f});',
          f'tl.fromTo("#{cid}-cmpArrow", {{opacity:0, scale:0.6}}, {{opacity:1, scale:1, '
          f'duration:0.3, ease:"back.out(2)"}}, {t0 + 0.4:.2f});',
          f'tl.fromTo("#{cid}-cmpR", {{opacity:0, x:40}}, {{opacity:1, x:0, duration:0.4, '
          f'ease:"power3.out"}}, {t0 + 0.6:.2f});']
    if lsub:
        html.append(f'<div id="{cid}-cmpLs">{_esc(lsub)}</div>')
        js.append(f'tl.to("#{cid}-cmpLs", {{opacity:1, duration:0.3}}, {t0 + 0.25:.2f});')
    if rsub:
        html.append(f'<div id="{cid}-cmpRs">{_esc(rsub)}</div>')
        js.append(f'tl.to("#{cid}-cmpRs", {{opacity:1, duration:0.3}}, {t0 + 0.8:.2f});')
    return css, html, js


def _badge(cid, c, t0, theme):
    """Пилюля-ценник, которая выскакивает: «0 ₽», «бесплатно», «-90%»."""
    text = _esc(c.get("text", "бесплатно"))
    size = int(c.get("size", 92))
    top = int(c.get("top", 820))
    tilt = float(c.get("tilt", -4))
    fill = theme.get(c.get("color", "deep"), theme["deep"])
    css = [f'#{cid}-badge {{ position:absolute; left:0; right:0; margin:0 auto; top:{top}px;',
           f'  width:max-content; background:{fill}; color:rgb(250,249,247);',
           f'  font-weight:800; font-size:{size}px; letter-spacing:-0.02em;',
           f'  padding:{size // 4}px {size // 1.6:.0f}px; border-radius:999px;',
           f'  box-shadow:{theme["shadow"]}; opacity:0; }}']
    html = [f'<div id="{cid}-badge">{text}</div>']
    js = [f'tl.fromTo("#{cid}-badge", {{opacity:0, scale:0.35, rotate:{tilt * 3}}}, '
          f'{{opacity:1, scale:1, rotate:{tilt}, duration:0.5, ease:"back.out(2.6)"}}, {t0:.2f});']
    return css, html, js


def _timeline(cid, c, t0, theme):
    """Горизонтальный таймлайн: линия, точки-шаги и бегущий маркер."""
    steps = [str(x) for x in (c.get("steps") or ["план", "тесты", "код", "ревью"])]
    top = int(c.get("top", 860))
    width = int(c.get("width", 900))
    dur = float(c.get("duration", 3.5))
    n = len(steps)
    x0 = (1080 - width) // 2
    gap = width // max(n - 1, 1)
    run = max(dur * 0.65, 0.8)

    css = [f'#{cid}-tlline {{ position:absolute; left:{x0}px; top:{top}px; width:{width}px;',
           f'  height:6px; background:{theme["muted"]}; opacity:0.28; border-radius:3px; }}',
           f'#{cid}-tlfill {{ position:absolute; left:{x0}px; top:{top}px; width:{width}px;',
           f'  height:6px; background:{theme["accent"]}; border-radius:3px;',
           '  transform:scaleX(0); transform-origin:left center; }',
           f'.{cid}-dot {{ position:absolute; top:{top - 11}px; width:28px; height:28px;',
           f'  border-radius:999px; background:{theme["accent"]}; opacity:0; }}',
           f'.{cid}-lbl {{ position:absolute; top:{top + 40}px; width:240px; text-align:center;',
           f'  font-weight:700; font-size:40px; color:{theme["ink"]}; opacity:0; }}']
    html, js = [f'<div id="{cid}-tlline"></div><div id="{cid}-tlfill"></div>'], []
    js.append(f'tl.fromTo("#{cid}-tlfill", {{scaleX:0}}, {{scaleX:1, duration:{run:.2f}, '
              f'ease:"none"}}, {t0 + 0.2:.2f});')
    for i, st in enumerate(steps):
        cx = x0 + gap * i
        html.append(f'<div class="{cid}-dot" id="{cid}-d{i}" style="left:{cx - 14}px"></div>')
        # крайние подписи прижимаем в кадр, иначе первая вылезает за левый край
        lx = min(max(cx - 120, 12), 1080 - 240 - 12)
        html.append(f'<div class="{cid}-lbl" id="{cid}-l{i}" style="left:{lx}px">{_esc(st)}</div>')
        at = t0 + 0.2 + run * (i / max(n - 1, 1))
        js.append(f'tl.fromTo("#{cid}-d{i}", {{opacity:0, scale:0.2}}, {{opacity:1, scale:1, '
                  f'duration:0.25, ease:"back.out(2.4)"}}, {at:.2f});')
        js.append(f'tl.fromTo("#{cid}-l{i}", {{opacity:0, y:12}}, {{opacity:1, y:0, '
                  f'duration:0.25, ease:"power2.out"}}, {at + 0.05:.2f});')
    return css, html, js


def _card_stack(cid, c, t0, theme):
    """Стопка карточек разлетается веером: «их тут много»."""
    items = [str(x) for x in (c.get("items") or [])]
    count = int(c.get("count", len(items) or 5))
    top = int(c.get("top", 720))
    cw, ch = int(c.get("w", 300)), int(c.get("h", 210))
    cols = int(c.get("cols", 3))
    gap = int(c.get("gap", 36))
    rows = (count + cols - 1) // cols
    grid_w = cols * cw + (cols - 1) * gap
    left0 = (1080 - grid_w) // 2

    css = [f'.{cid}-card {{ position:absolute; width:{cw}px; height:{ch}px; border-radius:26px;',
           f'  background:{theme["glass"]}; box-shadow:{theme["shadow"]};',
           f'  border:1px solid rgba(23,23,20,0.08); display:flex; align-items:center;',
           f'  justify-content:center; text-align:center; font-weight:700; font-size:38px;',
           f'  color:{theme["ink"]}; padding:0 18px; opacity:0; }}']
    html, js = [], []
    start_x = (1080 - cw) // 2
    start_y = top + (rows - 1) * (ch + gap) // 2
    for i in range(count):
        r, col = divmod(i, cols)
        x = left0 + col * (cw + gap)
        y = top + r * (ch + gap)
        label = _esc(items[i]) if i < len(items) else ""
        html.append(f'<div class="{cid}-card" id="{cid}-k{i}" '
                    f'style="left:{start_x}px; top:{start_y}px">{label}</div>')
        js.append(f'tl.fromTo("#{cid}-k{i}", {{opacity:0, x:0, y:0, scale:0.9, rotate:{(i % 3 - 1) * 4}}}, '
                  f'{{opacity:1, x:{x - start_x}, y:{y - start_y}, scale:1, rotate:0, duration:0.5, '
                  f'ease:"power3.out"}}, {t0 + 0.12 * i:.2f});')
    return css, html, js


def _number_roll(cid, c, t0, theme):
    """Табло: разряды прокручиваются и останавливаются на нужной цифре."""
    value = str(c.get("value", "258"))
    size = int(c.get("size", 170))
    top = int(c.get("top", 760))
    dur = float(c.get("duration", 2.5))
    color = theme.get(c.get("color", "ink"), theme["ink"])
    label = c.get("label")
    cell_h = int(size * 1.16)
    cell_w = int(size * 0.62)

    css = [f'#{cid}-roll {{ position:absolute; left:0; right:0; margin:0 auto; top:{top}px;',
           f'  width:max-content; display:flex; gap:{max(size // 22, 4)}px; opacity:0; }}',
           f'.{cid}-col {{ width:{cell_w}px; height:{cell_h}px; overflow:hidden; }}',
           f'.{cid}-strip {{ display:flex; flex-direction:column; }}',
           f'.{cid}-strip span {{ height:{cell_h}px; line-height:{cell_h}px; text-align:center;',
           f'  font-weight:800; font-size:{size}px; letter-spacing:-0.03em; color:{color};',
           '  font-variant-numeric:tabular-nums; }',
           f'.{cid}-sep {{ width:{cell_w // 2}px; }}']
    html, js = [f'<div id="{cid}-roll">'], [
        f'tl.fromTo("#{cid}-roll", {{opacity:0, y:24}}, {{opacity:1, y:0, duration:0.3, '
        f'ease:"power3.out"}}, {t0:.2f});']
    col = 0
    for ch in value:
        if not ch.isdigit():
            html.append(f'<div class="{cid}-sep"></div>')
            continue
        digits = "".join(f'<span>{d}</span>' for d in list("0123456789") * 2 + [ch])
        html.append(f'<div class="{cid}-col"><div class="{cid}-strip" id="{cid}-s{col}">'
                    f'{digits}</div></div>')
        js.append(f'tl.fromTo("#{cid}-s{col}", {{y:0}}, {{y:{-20 * cell_h}, '
                  f'duration:{max(dur * 0.62, 0.7) + col * 0.12:.2f}, ease:"power3.out"}}, '
                  f'{t0 + 0.12:.2f});')
        col += 1
    html.append("</div>")
    if label:
        css += [f'#{cid}-rolllabel {{ position:absolute; left:0; right:0; top:{top + cell_h + 24}px;',
                f'  text-align:center; font-weight:600; font-size:46px; color:{theme["muted"]};',
                '  opacity:0; }']
        html.append(f'<div id="{cid}-rolllabel">{_esc(label)}</div>')
        js.append(f'tl.to("#{cid}-rolllabel", {{opacity:1, duration:0.3}}, {t0 + 0.5:.2f});')
    return css, html, js


def _bar_chart(cid, c, t0, theme):
    """Столбики: сравнить цены, скорость, охваты."""
    bars = c.get("bars") or [["было", 100], ["стало", 25]]
    top = int(c.get("top", 640))
    height = int(c.get("height", 420))
    bw = int(c.get("bar_width", 190))
    gap = int(c.get("gap", 70))
    suffix = _esc(c.get("suffix", ""))
    n = len(bars)
    total_w = n * bw + (n - 1) * gap
    x0 = (1080 - total_w) // 2
    top_val = max(float(v) for _, v in bars) or 1

    css = [f'.{cid}-bar {{ position:absolute; width:{bw}px; border-radius:20px 20px 8px 8px;',
           '  transform:scaleY(0); transform-origin:bottom center; }',
           f'.{cid}-bl {{ position:absolute; width:{bw}px; text-align:center; font-weight:700;',
           f'  font-size:40px; color:{theme["ink"]}; opacity:0; }}',
           f'.{cid}-bv {{ position:absolute; width:{bw}px; text-align:center; font-weight:800;',
           f'  font-size:52px; color:{theme["accent"]}; opacity:0; }}']
    html, js = [], []
    base_y = top + height
    for i, (name, val) in enumerate(bars):
        h = max(int(height * float(val) / top_val), 24)
        x = x0 + i * (bw + gap)
        fill = theme["accent"] if i == n - 1 else theme["muted"]
        html.append(f'<div class="{cid}-bar" id="{cid}-b{i}" style="left:{x}px; '
                    f'top:{base_y - h}px; height:{h}px; background:{fill}"></div>')
        html.append(f'<div class="{cid}-bv" id="{cid}-v{i}" style="left:{x}px; '
                    f'top:{base_y - h - 74}px">{_esc(val)}{suffix}</div>')
        html.append(f'<div class="{cid}-bl" id="{cid}-t{i}" style="left:{x}px; '
                    f'top:{base_y + 22}px">{_esc(name)}</div>')
        at = t0 + 0.1 + i * 0.22
        js.append(f'tl.fromTo("#{cid}-b{i}", {{scaleY:0}}, {{scaleY:1, duration:0.5, '
                  f'ease:"power3.out"}}, {at:.2f});')
        js.append(f'tl.to("#{cid}-v{i}", {{opacity:1, duration:0.25}}, {at + 0.35:.2f});')
        js.append(f'tl.to("#{cid}-t{i}", {{opacity:1, duration:0.25}}, {at + 0.15:.2f});')
    return css, html, js


def _tooltip(cid, c, t0, theme):
    """Всплывающая подсказка с хвостиком: цепляется к точке на скриншоте."""
    text = _esc(c.get("text", "вот здесь"))
    x, y = int(c.get("x", 540)), int(c.get("y", 700))
    width = int(c.get("w", 520))
    size = int(c.get("size", 44))
    side = c.get("side", "down")       # down: облачко НАД точкой, хвост вниз
    fill = theme.get(c.get("color", "deep"), theme["deep"])
    pad = 26
    box_h = int(size * 1.5) + pad * 2
    box_y = y - box_h - 26 if side == "down" else y + 26
    tail_y = box_y + box_h - 2 if side == "down" else box_y - 20

    css = [f'#{cid}-tip {{ position:absolute; left:{x - width // 2}px; top:{box_y}px;',
           f'  width:{width}px; background:{fill}; color:rgb(250,249,247);',
           f'  border-radius:22px; padding:{pad}px 28px; text-align:center;',
           f'  font-weight:700; font-size:{size}px; box-shadow:{theme["shadow"]}; opacity:0; }}',
           f'#{cid}-tail {{ position:absolute; left:{x - 16}px; top:{tail_y}px;',
           f'  width:0; height:0; border-left:16px solid transparent;',
           f'  border-right:16px solid transparent;',
           f'  border-{"top" if side == "down" else "bottom"}:22px solid {fill}; opacity:0; }}',
           f'#{cid}-dot {{ position:absolute; left:{x - 11}px; top:{y - 11}px; width:22px;',
           f'  height:22px; border-radius:999px; background:{fill}; opacity:0; }}']
    html = [f'<div id="{cid}-tip">{text}</div><div id="{cid}-tail"></div>'
            f'<div id="{cid}-dot"></div>']
    js = [f'tl.fromTo("#{cid}-dot", {{opacity:0, scale:0.2}}, {{opacity:1, scale:1, '
          f'duration:0.25, ease:"back.out(2.4)"}}, {t0:.2f});',
          f'tl.fromTo("#{cid}-tip", {{opacity:0, y:{14 if side == "down" else -14}, scale:0.92}}, '
          f'{{opacity:1, y:0, scale:1, duration:0.35, ease:"back.out(1.8)"}}, {t0 + 0.2:.2f});',
          f'tl.to("#{cid}-tail", {{opacity:1, duration:0.2}}, {t0 + 0.3:.2f});']
    return css, html, js


def _file_tree(cid, c, t0, theme):
    """Дерево файлов: строки появляются сверху вниз, нужная подсвечена."""
    lines = [str(x) for x in (c.get("lines") or ["project/", "  src/", "  .claude/", "  README.md"])]
    top = int(c.get("top", 640))
    size = int(c.get("size", 46))
    hi = c.get("highlight")
    hi = set(hi if isinstance(hi, list) else ([hi] if hi is not None else []))
    lh = int(size * 1.55)

    css = [f'#{cid}-tree {{ position:absolute; left:0; right:0; margin:0 auto; top:{top}px;',
           f'  width:max-content; min-width:640px; background:{theme["glass"]};',
           f'  box-shadow:{theme["shadow"]}; border-radius:28px; padding:34px 44px;',
           f'  font-family:"JetBrains Mono","SF Mono",Consolas,monospace; font-size:{size}px;',
           f'  font-weight:600; color:{theme["ink"]}; opacity:0; }}',
           f'.{cid}-row {{ height:{lh}px; line-height:{lh}px; white-space:pre; opacity:0; }}',
           f'.{cid}-hi {{ color:{theme["accent"]}; }}']
    html = [f'<div id="{cid}-tree">']
    js = [f'tl.fromTo("#{cid}-tree", {{opacity:0, y:24}}, {{opacity:1, y:0, duration:0.3, '
          f'ease:"power3.out"}}, {t0:.2f});']
    for i, ln in enumerate(lines):
        cls = f'{cid}-row' + (f' {cid}-hi' if i in hi else "")
        html.append(f'<div class="{cls}" id="{cid}-r{i}">{_esc(ln)}</div>')
        js.append(f'tl.to("#{cid}-r{i}", {{opacity:1, duration:0.2}}, {t0 + 0.25 + i * 0.16:.2f});')
    html.append("</div>")
    return css, html, js


def _chat_bubbles(cid, c, t0, theme):
    """Пузыри переписки: сообщения появляются по очереди."""
    msgs = c.get("messages") or [["Здравствуйте, свободно на выходные?", "in"],
                                 ["Да, держу для вас", "out"]]
    top = int(c.get("top", 620))
    size = int(c.get("size", 42))
    gap = int(c.get("gap", 26))
    maxw = int(c.get("w", 640))

    css = [f'.{cid}-msg {{ position:absolute; max-width:{maxw}px; border-radius:30px;',
           f'  padding:26px 32px; font-weight:600; font-size:{size}px; line-height:1.3;',
           f'  box-shadow:{theme["shadow"]}; opacity:0; }}',
           f'.{cid}-in {{ left:70px; background:{theme["glass"]}; color:{theme["ink"]};',
           '  border-bottom-left-radius:10px; }',
           f'.{cid}-out {{ right:70px; background:{theme["deep"]}; color:rgb(250,249,247);',
           '  border-bottom-right-radius:10px; }']
    html, js = [], []
    y = top
    for i, m in enumerate(msgs):
        text, side = (m[0], m[1]) if isinstance(m, (list, tuple)) else (m.get("text"), m.get("side", "in"))
        rows = max(1, len(str(text)) // 26 + 1)
        h = int(size * 1.3 * rows) + 52
        html.append(f'<div class="{cid}-msg {cid}-{side}" id="{cid}-m{i}" '
                    f'style="top:{y}px">{_esc(text)}</div>')
        js.append(f'tl.fromTo("#{cid}-m{i}", {{opacity:0, y:22, scale:0.94}}, {{opacity:1, y:0, '
                  f'scale:1, duration:0.35, ease:"back.out(1.7)"}}, {t0 + 0.15 + i * 0.55:.2f});')
        y += h + gap
    return css, html, js


def _node_map(cid, c, t0, theme):
    """Схема связей: центральный узел и расходящиеся ветки."""
    center = _esc(c.get("center", "Claude"))
    nodes = [str(x) for x in (c.get("nodes") or ["агенты", "скиллы", "команды", "хуки", "память"])]
    cx, cy = int(c.get("cx", 540)), int(c.get("cy", 980))
    r = int(c.get("r", 330))
    size = int(c.get("size", 38))
    n = len(nodes)
    import math
    pos = []
    for i in range(n):
        a = -math.pi / 2 + 2 * math.pi * i / n
        pos.append((cx + r * math.cos(a), cy + r * math.sin(a)))

    paths = "".join(
        f'<path id="{cid}-p{i}" d="M{cx} {cy} L{int(x)} {int(y)}" />' for i, (x, y) in enumerate(pos))
    css = [f'#{cid}-map {{ position:absolute; left:0; top:0; width:1080px; height:1920px; }}',
           f'#{cid}-map svg {{ position:absolute; left:0; top:0; width:1080px; height:1920px; }}',
           f'#{cid}-c {{ position:absolute; left:{cx - 130}px; top:{cy - 62}px; width:260px;',
           f'  height:124px; border-radius:999px; background:{theme["deep"]};',
           f'  color:rgb(250,249,247); font-weight:800; font-size:{size + 8}px;',
           '  display:flex; align-items:center; justify-content:center; opacity:0; }',
           f'.{cid}-n {{ position:absolute; width:250px; height:92px; border-radius:999px;',
           f'  background:{theme["glass"]}; box-shadow:{theme["shadow"]};',
           f'  border:1px solid rgba(23,23,20,0.08); color:{theme["ink"]}; font-weight:700;',
           f'  font-size:{size}px; display:flex; align-items:center; justify-content:center;',
           '  opacity:0; }']
    html = [f'<div id="{cid}-map"><svg viewBox="0 0 1080 1920" fill="none" '
            f'xmlns="http://www.w3.org/2000/svg" stroke="{theme["accent"]}" stroke-width="5" '
            f'stroke-linecap="round" stroke-opacity="0.55">{paths}</svg>',
            f'<div id="{cid}-c">{center}</div>']
    js = [f'tl.fromTo("#{cid}-c", {{opacity:0, scale:0.6}}, {{opacity:1, scale:1, duration:0.4, '
          f'ease:"back.out(2)"}}, {t0:.2f});']
    for i, (x, y) in enumerate(pos):
        html.append(f'<div class="{cid}-n" id="{cid}-n{i}" style="left:{int(x) - 125}px; '
                    f'top:{int(y) - 46}px">{_esc(nodes[i])}</div>')
        at = t0 + 0.35 + i * 0.18
        length = int(((x - cx) ** 2 + (y - cy) ** 2) ** 0.5)
        js.append(f'gsap.set("#{cid}-p{i}", {{strokeDasharray:{length}, strokeDashoffset:{length}}});')
        js.append(f'tl.to("#{cid}-p{i}", {{strokeDashoffset:0, duration:0.35, '
                  f'ease:"power2.out"}}, {at:.2f});')
        js.append(f'tl.fromTo("#{cid}-n{i}", {{opacity:0, scale:0.8}}, {{opacity:1, scale:1, '
                  f'duration:0.3, ease:"back.out(2)"}}, {at + 0.25:.2f});')
    html.append("</div>")
    return css, html, js


def _particles(cid, c, t0, theme):
    """Частицы разлетаются из точки: момент результата."""
    import math
    n = int(c.get("count", 16))
    cx, cy = int(c.get("cx", 540)), int(c.get("cy", 880))
    spread = int(c.get("spread", 320))
    dot = int(c.get("dot", 18))
    color = theme.get(c.get("color", "accent"), theme["accent"])
    css = [f'.{cid}-p {{ position:absolute; width:{dot}px; height:{dot}px; border-radius:999px;',
           f'  background:{color}; opacity:0; }}']
    html, js = [], []
    for i in range(n):
        a = 2 * math.pi * i / n
        rr = spread * (0.6 + 0.4 * ((i * 7) % 5) / 4)      # без random: детерминированный разброс
        dx, dy = rr * math.cos(a), rr * math.sin(a)
        html.append(f'<div class="{cid}-p" id="{cid}-p{i}" style="left:{cx}px; top:{cy}px"></div>')
        js.append(f'tl.fromTo("#{cid}-p{i}", {{opacity:0.9, x:0, y:0, scale:1}}, '
                  f'{{opacity:0, x:{dx:.0f}, y:{dy:.0f}, scale:0.3, duration:0.75, '
                  f'ease:"power2.out"}}, {t0 + 0.02 * i:.2f});')
    return css, html, js


def _bg_parallax(cid, c, t0, theme):
    """Медленно плывущее световое пятно на фоне: кадр перестаёт быть мёртвым."""
    dur = float(c.get("duration", 4.0))
    tint = c.get("tint", "rgba(195,100,93,0.10)")
    size = int(c.get("size", 1500))
    dx, dy = int(c.get("dx", 120)), int(c.get("dy", -90))
    css = [f'#{cid}-bgp {{ position:absolute; left:{(1080 - size) // 2}px; top:{c.get("top", 300)}px;',
           f'  width:{size}px; height:{size}px; border-radius:999px; opacity:0;',
           f'  background:radial-gradient(circle, {tint}, rgba(255,255,255,0) 68%); z-index:0; }}']
    html = [f'<div id="{cid}-bgp"></div>']
    js = [f'tl.to("#{cid}-bgp", {{opacity:1, duration:0.6}}, {t0:.2f});',
          f'tl.fromTo("#{cid}-bgp", {{x:0, y:0, scale:1}}, {{x:{dx}, y:{dy}, scale:1.08, '
          f'duration:{dur:.2f}, ease:"none"}}, {t0:.2f});']
    return css, html, js


def _codeword(cid, c, t0, theme):
    """Кодовое слово в плашке и стрелка, которая прыгает на него. Для концовки."""
    word = _esc(c.get("word", "CLAUDE"))
    title = c.get("title", "пиши кодовое слово")
    size = int(c.get("size", 104))
    top = int(c.get("top", 820))
    dur = float(c.get("duration", 4.0))
    fill = theme.get(c.get("color", "deep"), theme["deep"])
    arrow_size = int(c.get("arrow", 150))
    bounces = max(1, int(dur / 0.9))

    pad_v, pad_h = size // 3, int(size * 0.72)
    badge_h = size + pad_v * 2
    css = [f'#{cid}-cwt {{ position:absolute; left:0; right:0; top:{top - 110}px; text-align:center;',
           f'  font-weight:700; font-size:52px; color:{theme["ink"]}; opacity:0; }}',
           f'#{cid}-cw {{ position:absolute; left:0; right:0; margin:0 auto; top:{top}px;',
           f'  width:max-content; background:{fill}; color:rgb(250,249,247); font-weight:800;',
           f'  font-size:{size}px; letter-spacing:0.04em; padding:{pad_v}px {pad_h}px;',
           f'  border-radius:999px; box-shadow:{theme["shadow"]}; opacity:0;',
           '  white-space:nowrap; }',
           f'#{cid}-cwa {{ position:absolute; left:0; right:0; margin:0 auto;',
           f'  top:{top + badge_h + 26}px; width:{arrow_size}px; opacity:0; }}',
           f'#{cid}-cwa svg {{ display:block; width:100%; height:auto; overflow:visible; }}']
    # стрелка смотрит ВВЕРХ, на плашку, и прыгает к ней
    html = [f'<div id="{cid}-cwt">{_esc(title)}</div>' if title else "",
            f'<div id="{cid}-cw">{word}</div>',
            f'<div id="{cid}-cwa"><svg viewBox="0 0 60 120" fill="none" '
            f'xmlns="http://www.w3.org/2000/svg" stroke="{fill}" stroke-width="11" '
            f'stroke-linecap="round" stroke-linejoin="round">'
            f'<path d="M30 114 V16"/><path d="M12 36 L30 12 L48 36"/></svg></div>']
    js = [f'tl.fromTo("#{cid}-cw", {{opacity:0, scale:0.6}}, {{opacity:1, scale:1, duration:0.45, '
          f'ease:"back.out(2.4)"}}, {t0:.2f});',
          f'tl.to("#{cid}-cwa", {{opacity:1, duration:0.2}}, {t0 + 0.35:.2f});',
          f'tl.fromTo("#{cid}-cwa", {{y:26}}, {{y:-10, duration:0.45, ease:"sine.inOut", '
          f'yoyo:true, repeat:{bounces * 2 + 1}}}, {t0 + 0.4:.2f});']
    if title:
        js.append(f'tl.fromTo("#{cid}-cwt", {{opacity:0, y:14}}, {{opacity:1, y:0, duration:0.3, '
                  f'ease:"power2.out"}}, {t0 + 0.15:.2f});')
    return css, [h for h in html if h], js


def _claude_terminal(cid, c, t0, theme):
    """Узнаваемое окно Claude Code: тёмный терминал с шапкой, моделью, путём,
    печатающимся промптом и статусной строкой. Сделано по донору: зритель должен
    узнать интерфейс за полсекунды, поэтому детали (версия, модель, auto mode) важны."""
    prompt = str(c.get("prompt", "почини авторизацию и покрой тестами"))
    version = _esc(c.get("version", "Claude Code v2.1.239"))
    model = _esc(c.get("model", "Opus 5 (1M context) with high effort · Claude Max"))
    path = _esc(c.get("path", "~/Projects/app"))
    steps = [str(x) for x in (c.get("steps") or [])]
    status = _esc(c.get("status", "auto mode on (shift+tab to cycle)"))
    ctx = _esc(c.get("context", "Opus 5 (1M context) · 100% left"))
    top = int(c.get("top", 430))
    width = int(c.get("width", 940))
    size = int(c.get("size", 30))
    dur = float(c.get("duration", 4.0))
    run = float(c.get("run", max(dur * 0.4, 0.8)))

    # акцент внутри тёмного окна СВОЙ: бежевая терракота на почти чёрном даёт 4.39:1
    # и не проходит AA, поэтому здесь светлее
    ink, acc = "rgb(232,230,226)", c.get("accent", "rgb(226,140,128)")
    bar, back = "rgb(38,38,41)", "rgb(26,26,28)"
    mono = '"JetBrains Mono","SF Mono",Consolas,monospace'
    css = [f'#{cid}-term {{ position:absolute; left:0; right:0; margin:0 auto; top:{top}px;',
           f'  width:{width}px; background:{back}; border-radius:22px; overflow:hidden;',
           f'  box-shadow:rgba(0,0,0,0.30) 0px 22px 48px 0px; font-family:{mono};',
           f'  font-size:{size}px; color:{ink}; opacity:0; }}',
           f'#{cid}-term .bar {{ display:flex; align-items:center; gap:10px; background:{bar};',
           f'  padding:16px 22px; font-size:{int(size * 0.78)}px; color:rgb(150,150,154); }}',
           f'#{cid}-term .bar i {{ width:14px; height:14px; border-radius:999px; }}',
           f'#{cid}-term .body {{ padding:26px 28px 22px; line-height:1.5; white-space:pre-wrap; }}',
           f'#{cid}-term .ver {{ color:{ink}; font-weight:700; }}',
           f'#{cid}-term .dim {{ color:rgb(138,138,142); }}',
           f'#{cid}-term .acc {{ color:{acc}; }}',
           f'#{cid}-term .row {{ display:flex; gap:14px; margin-top:6px; opacity:0; }}',
           f'#{cid}-term .foot {{ border-top:1px solid rgba(255,255,255,0.08); padding:14px 28px;',
           f'  font-size:{int(size * 0.72)}px; color:rgb(146,146,151); display:flex;',
           '  justify-content:space-between; }',
           f'#{cid}-tcaret {{ display:inline-block; width:{max(size // 2, 10)}px;',
           f'  height:{int(size * 1.05)}px; background:{acc}; vertical-align:-0.18em; opacity:0; }}',
           f'#{cid}-ghost {{ visibility:hidden; }}',
           f'#{cid}-show {{ position:absolute; left:0; top:0; white-space:nowrap; }}',
           f'#{cid}-prow {{ position:relative; display:inline-block; }}']

    # маркер шага настраивается: галочка для успеха, крестик для отчёта об ошибке
    step_mark = _esc(c.get("step_mark", "✓"))
    rows = "".join(
        f'<div class="row" id="{cid}-st{i}"><span class="acc">{step_mark}</span>'
        f'<span class="dim">{_esc(s)}</span></div>' for i, s in enumerate(steps))
    html = [f'<div id="{cid}-term">'
            f'<div class="bar"><i style="background:#ff5f57"></i><i style="background:#febc2e"></i>'
            f'<i style="background:#28c840"></i><span>claude-code — node ‹ claude</span></div>'
            f'<div class="body">'
            f'<span class="ver">{version}</span>\n'
            f'<span class="dim">{model}\n{path}</span>\n\n'
            f'<span class="acc">›</span> <span id="{cid}-prow">'
            f'<span id="{cid}-ghost">{_esc(prompt)}'
            f'<span style="display:inline-block; width:{max(size // 2, 10) + 6}px"></span></span>'
            f'<span id="{cid}-show"><span id="{cid}-ptxt"></span>'
            f'<span id="{cid}-tcaret"></span></span></span>'
            f'{rows}</div>'
            f'<div class="foot"><span>{ctx}</span><span class="acc">⏵⏵ {status}</span></div></div>']

    js = [f'const {cid}_p = {json_dumps(prompt)};',
          f'const {cid}_o = document.getElementById("{cid}-ptxt");',
          f'const {cid}_n = {{i:0}};',
          f'tl.fromTo("#{cid}-term", {{opacity:0, y:34, scale:0.97}}, {{opacity:1, y:0, scale:1, '
          f'duration:0.45, ease:"power3.out"}}, {t0:.2f});',
          f'tl.to("#{cid}-tcaret", {{opacity:1, duration:0.1}}, {t0 + 0.35:.2f});',
          f'tl.to({cid}_n, {{i:{cid}_p.length, duration:{run:.2f}, ease:"none", onUpdate:() => '
          f'{{ {cid}_o.textContent = {cid}_p.slice(0, Math.round({cid}_n.i)); }}}}, {t0 + 0.4:.2f});']
    for i, _ in enumerate(steps):
        js.append(f'tl.to("#{cid}-st{i}", {{opacity:1, duration:0.2}}, '
                  f'{t0 + 0.5 + run + i * 0.35:.2f});')
    return css, html, js


def _claude_desktop(cid, c, t0, theme):
    """Окно десктопного приложения Claude: боковая колонка с сессиями, диалог,
    строка ввода с моделью. Тот же принцип, что и с терминалом: узнаваемость дают
    детали интерфейса, а не форма окна."""
    prompt = str(c.get("prompt", "разбери проект и составь план"))
    sessions = [str(x) for x in (c.get("sessions") or
                                 ["Проект А", "Проект Б", "Проект В"])]
    active = int(c.get("active", 0))
    rows = [str(x) for x in (c.get("rows") or
                             ["Читаю файлы проекта", "Пишу план", "Готово"])]
    model = _esc(c.get("model", "Opus 5"))
    top = int(c.get("top", 430))
    width = int(c.get("width", 960))
    height = int(c.get("height", 620))
    size = int(c.get("size", 28))
    dur = float(c.get("duration", 5.0))
    run = float(c.get("run", max(dur * 0.3, 0.7)))

    ink = theme["ink"]
    side_bg = "rgb(238, 236, 232)"
    css = [f'#{cid}-app {{ position:absolute; left:0; right:0; margin:0 auto; top:{top}px;',
           f'  width:{width}px; height:{height}px; background:rgb(252,251,249);',
           f'  border-radius:24px; overflow:hidden; box-shadow:{theme["shadow"]};',
           '  border:1px solid rgba(23,23,20,0.10); display:flex; opacity:0; }',
           f'#{cid}-app .side {{ width:{int(width * 0.3)}px; background:{side_bg}; padding:20px 18px;',
           '  border-right:1px solid rgba(23,23,20,0.07); }',
           f'#{cid}-app .logo {{ display:flex; align-items:center; gap:10px; font-weight:800;',
           f'  font-size:{int(size * 1.05)}px; color:{ink}; margin-bottom:22px; }}',
           f'#{cid}-app .logo i {{ width:{size}px; height:{size}px; border-radius:8px;',
           f'  background:{theme["deep"]}; }}',
           f'#{cid}-app .s {{ padding:13px 14px; border-radius:12px; font-size:{int(size*0.92)}px;',
           f'  color:rgb(110,108,104); margin-bottom:8px; white-space:nowrap;',
           '  overflow:hidden; text-overflow:ellipsis; }',
           f'#{cid}-app .s.on {{ background:rgba(255,255,255,0.95); color:{ink}; font-weight:700;',
           '  box-shadow:rgba(38,34,23,0.08) 0px 2px 8px 0px; }',
           f'#{cid}-app .main {{ flex:1; display:flex; flex-direction:column; padding:22px 26px; }}',
           f'#{cid}-app .msg {{ align-self:flex-end; max-width:82%; background:{theme["deep"]};',
           f'  color:rgb(250,249,247); border-radius:20px 20px 6px 20px; padding:16px 20px;',
           f'  font-size:{size}px; font-weight:600; opacity:0; }}',
           f'#{cid}-app .step {{ display:flex; align-items:center; gap:12px; margin-top:16px;',
           f'  font-size:{int(size * 0.95)}px; color:rgb(96,94,90); opacity:0; }}',
           f'#{cid}-app .step b {{ color:{theme["accent"]}; font-size:{int(size * 1.05)}px; }}',
           f'#{cid}-app .composer {{ margin-top:auto; border:1px solid rgba(23,23,20,0.13);',
           f'  border-radius:18px; padding:16px 18px; display:flex; align-items:center;',
           f'  gap:12px; font-size:{int(size*0.95)}px; color:rgb(140,138,134); background:#fff; }}',
           f'#{cid}-app .composer .mdl {{ margin-left:auto; font-weight:700; color:{ink};',
           '  background:rgba(23,23,20,0.06); border-radius:999px; padding:7px 14px;',
           f'  font-size:{int(size*0.82)}px; }}',
           f'#{cid}-dghost {{ visibility:hidden; }}',
           f'#{cid}-dshow {{ position:absolute; left:0; top:0; white-space:nowrap; }}',
           f'#{cid}-drow {{ position:relative; display:inline-block; }}',
           f'#{cid}-dcaret {{ display:inline-block; width:3px; height:{int(size*1.05)}px;',
           f'  background:{theme["accent"]}; vertical-align:-0.16em; opacity:0; }}']

    side = "".join(f'<div class="s{" on" if i == active else ""}">{_esc(x)}</div>'
                   for i, x in enumerate(sessions))
    steps = "".join(f'<div class="step" id="{cid}-ds{i}"><b>✓</b>{_esc(r)}</div>'
                    for i, r in enumerate(rows))
    html = [f'<div id="{cid}-app">'
            f'<div class="side"><div class="logo"><i></i>Claude</div>{side}</div>'
            f'<div class="main"><div class="msg" id="{cid}-dmsg">{_esc(prompt)}</div>{steps}'
            f'<div class="composer"><span id="{cid}-drow">'
            f'<span id="{cid}-dghost">{_esc(prompt)}</span>'
            f'<span id="{cid}-dshow"><span id="{cid}-dtxt"></span>'
            f'<span id="{cid}-dcaret"></span></span></span>'
            f'<span class="mdl">{model}</span></div></div></div>']

    js = [f'const {cid}_dp = {json_dumps(prompt)};',
          f'const {cid}_do = document.getElementById("{cid}-dtxt");',
          f'const {cid}_dn = {{i:0}};',
          f'tl.fromTo("#{cid}-app", {{opacity:0, y:34, scale:0.97}}, {{opacity:1, y:0, scale:1, '
          f'duration:0.45, ease:"power3.out"}}, {t0:.2f});',
          f'tl.to("#{cid}-dcaret", {{opacity:1, duration:0.1}}, {t0 + 0.3:.2f});',
          f'tl.to({cid}_dn, {{i:{cid}_dp.length, duration:{run:.2f}, ease:"none", onUpdate:() => '
          f'{{ {cid}_do.textContent = {cid}_dp.slice(0, Math.round({cid}_dn.i)); }}}}, {t0 + 0.35:.2f});',
          # отправили: текст улетел из строки ввода в сообщение
          f'tl.to("#{cid}-dshow", {{opacity:0, duration:0.15}}, {t0 + 0.4 + run:.2f});',
          f'tl.to("#{cid}-dcaret", {{opacity:0, duration:0.1}}, {t0 + 0.4 + run:.2f});',
          f'tl.fromTo("#{cid}-dmsg", {{opacity:0, y:18}}, {{opacity:1, y:0, duration:0.3, '
          f'ease:"power3.out"}}, {t0 + 0.45 + run:.2f});']
    for i, _ in enumerate(rows):
        js.append(f'tl.to("#{cid}-ds{i}", {{opacity:1, duration:0.25}}, '
                  f'{t0 + 0.8 + run + i * 0.45:.2f});')
    return css, html, js


def _task_list(cid, c, t0, theme):
    """Список задач с прогрессом: сделанные, текущая с процентом, остальные в очереди."""
    tasks = c.get("tasks") or [["Схема данных", "done"], ["Оплата", 74], ["Личный кабинет", "wait"]]
    top = int(c.get("top", 500))
    width = int(c.get("width", 900))
    size = int(c.get("size", 42))
    title = c.get("title")
    total = c.get("total")
    rest = c.get("rest")
    row_h = int(size * 1.9)
    x0 = (1080 - width) // 2

    css = [f'#{cid}-tasks {{ position:absolute; left:{x0}px; top:{top}px; width:{width}px;',
           '  opacity:0; }',
           f'.{cid}-t {{ position:relative; height:{row_h}px; margin-bottom:16px;',
           f'  border-radius:20px; background:{theme["glass"]}; box-shadow:{theme["shadow"]};',
           '  border:1px solid rgba(23,23,20,0.08); display:flex; align-items:center;',
           f'  padding:0 26px; gap:18px; font-weight:700; font-size:{size}px;',
           f'  color:{theme["ink"]}; opacity:0; }}',
           f'.{cid}-box {{ width:{int(size * 0.86)}px; height:{int(size * 0.86)}px;',
           '  border-radius:9px; border:3px solid rgba(23,23,20,0.22); flex:none;',
           '  display:flex; align-items:center; justify-content:center;',
           f'  font-size:{int(size * 0.6)}px; color:rgb(250,249,247); }}',
           f'.{cid}-done .{cid}-box {{ background:{theme["accent"]}; border-color:{theme["accent"]}; }}',
           f'.{cid}-wait {{ color:{theme["muted"]}; }}',
           f'.{cid}-pct {{ margin-left:auto; color:{theme["accent"]}; font-weight:800; }}',
           f'.{cid}-fill {{ position:absolute; left:0; bottom:0; height:6px; border-radius:0 6px 6px 0;',
           f'  background:{theme["accent"]}; transform:scaleX(0); transform-origin:left center;',
           f'  width:{width}px; }}',
           f'#{cid}-head {{ position:absolute; left:{x0}px; top:{top - 104}px; width:{width}px;',
           f'  display:flex; justify-content:space-between; align-items:baseline;',
           f'  font-weight:700; font-size:{size}px; color:{theme["ink"]}; opacity:0; }}',
           f'#{cid}-head b {{ font-size:{int(size * 1.5)}px; color:{theme["accent"]}; }}',
           f'#{cid}-rest {{ position:absolute; left:{x0}px; top:{top + len(tasks) * (row_h + 16) + 10}px;',
           f'  width:{width}px; text-align:right; font-weight:600; font-size:{int(size * 0.85)}px;',
           f'  color:{theme["muted"]}; opacity:0; }}']
    html, js = [], [f'tl.to("#{cid}-tasks", {{opacity:1, duration:0.2}}, {t0:.2f});']
    if title or total:
        html.append(f'<div id="{cid}-head"><span>{_esc(title or "")}</span>'
                    f'<span><b>{_esc(total or "")}</b></span></div>')
        js.append(f'tl.fromTo("#{cid}-head", {{opacity:0, y:14}}, {{opacity:1, y:0, duration:0.3, '
                  f'ease:"power2.out"}}, {t0 + 0.1:.2f});')
    html.append(f'<div id="{cid}-tasks">')
    for i, t in enumerate(tasks):
        name, state = (t[0], t[1]) if isinstance(t, (list, tuple)) else (t, "wait")
        pct = state if isinstance(state, (int, float)) else None
        cls = f'{cid}-t ' + (f'{cid}-done' if state == "done" else
                             (f'{cid}-wait' if pct is None else ""))
        mark = "✓" if state == "done" else ""
        right = f'<span class="{cid}-pct">{pct}%</span>' if pct is not None else (
            f'<span class="{cid}-pct" style="color:{theme["muted"]};'
            f'font-size:{int(size*0.72)}px">в очереди</span>' if state == "wait" else "")
        fill = (f'<span class="{cid}-fill" id="{cid}-f{i}"></span>' if pct is not None else "")
        html.append(f'<div class="{cls}" id="{cid}-t{i}"><span class="{cid}-box">{mark}</span>'
                    f'<span>{_esc(name)}</span>{right}{fill}</div>')
        at = t0 + 0.25 + i * 0.3
        js.append(f'tl.fromTo("#{cid}-t{i}", {{opacity:0, x:-26}}, {{opacity:1, x:0, '
                  f'duration:0.35, ease:"power3.out"}}, {at:.2f});')
        if pct is not None:
            js.append(f'tl.fromTo("#{cid}-f{i}", {{scaleX:0}}, {{scaleX:{pct / 100:.2f}, '
                      f'duration:0.6, ease:"power2.out"}}, {at + 0.25:.2f});')
    html.append("</div>")
    if rest:
        html.append(f'<div id="{cid}-rest">{_esc(rest)}</div>')
        js.append(f'tl.to("#{cid}-rest", {{opacity:1, duration:0.25}}, '
                  f'{t0 + 0.35 + len(tasks) * 0.3:.2f});')
    return css, html, js


SPECIAL = {
    "counter": _counter,
    "claude_terminal": _claude_terminal,
    "claude_desktop": _claude_desktop,
    "task_list": _task_list,
    "number_roll": _number_roll,
    "bar_chart": _bar_chart,
    "tooltip": _tooltip,
    "file_tree": _file_tree,
    "chat_bubbles": _chat_bubbles,
    "node_map": _node_map,
    "particles": _particles,
    "bg_parallax": _bg_parallax,
    "codeword": _codeword,
    "type_line": _type_line,
    "compare": _compare,
    "badge": _badge,
    "timeline": _timeline,
    "card_stack": _card_stack,
    "frame_box": _frame_box,
    "strike_text": _strike_text,
    "highlight": _highlight,
    "cursor_path": _cursor_path,
}


def build_mark(cid, c, t0, theme):
    shape = c.get("shape", "check")
    if shape in SPECIAL:
        css, html, js = SPECIAL[shape](cid, c, t0, theme)
        return dict(css="\n      ".join(css), html="".join(html), js="\n      ".join(js))
    if shape not in SHAPES:
        raise SystemExit(f"Неизвестная фигура: {shape}. "
                         f"Доступны: {', '.join(sorted(list(SHAPES) + list(SPECIAL)))}")
    view, inner, kind = SHAPES[shape]
    size = int(c.get("size", 320))
    top = int(c.get("top", 900))
    left = c.get("left")
    width_attr = f"width:{size}px;"
    color = theme.get(c.get("color", "accent"), theme["accent"])
    # Толщина задаётся в ПИКСЕЛЯХ кадра и пересчитывается в единицы viewBox.
    # Иначе одна и та же цифра даёт тонкую линию на широкой фигуре и жирную на узкой:
    # arrow_down на 60-единичном viewBox выходил втрое толще arrow_right.
    vb = [float(x) for x in view.split()]
    vb_w, vb_h = vb[2], vb[3]
    stroke_px = float(c.get("stroke", 26))
    stroke = round(stroke_px * vb_w / size, 2)
    draw_h = size * vb_h / vb_w      # реальная высота фигуры в кадре
    dur = float(c.get("duration", 2.0))
    speed = float(c.get("speed", 0.75))     # доля длительности карточки на отрисовку
    pos = (f"left:{int(left)}px;" if left is not None else "left:0; right:0; margin:0 auto;")

    fill = "none" if shape in STROKE_ONLY else color
    svg_open = (f'<svg viewBox="{view}" fill="none" xmlns="http://www.w3.org/2000/svg" '
                f'stroke="{color}" stroke-width="{stroke}" stroke-linecap="round" '
                f'stroke-linejoin="round">')

    if kind == "progress":
        inner = (f'<rect x="4" y="8" width="292" height="24" rx="12" fill="none" '
                 f'stroke="{color}" stroke-opacity="0.22" stroke-width="3"/>'
                 f'<rect id="{cid}-fill" x="10" y="14" width="280" height="12" rx="6" '
                 f'fill="{color}" stroke="none" style="transform-origin:10px 20px"/>')
    elif kind == "dots":
        inner = inner.replace("<circle", f'<circle fill="{color}" stroke="none" class="{cid}-dot"')

    css = f"""
      #{cid}-mark {{ position:absolute; {pos} top:{top}px; {width_attr} opacity:0; }}
      #{cid}-mark svg {{ display:block; width:100%; height:auto; overflow:visible; }}
    """
    html = f'<div id="{cid}-mark">{svg_open}{inner}</svg></div>'

    js = [f'tl.to("#{cid}-mark", {{opacity:1, duration:0.2, ease:"power2.out"}}, {t0:.2f});']

    if kind == "draw":
        draw = max(dur * speed, 0.4)
        js.append(
            f'gsap.utils.toArray("#{cid}-mark path").forEach((p, i) => {{'
            f' const L = p.getTotalLength();'
            f' gsap.set(p, {{strokeDasharray: L, strokeDashoffset: L}});'
            f' tl.to(p, {{strokeDashoffset: 0, duration:{draw:.2f}, ease:"power2.inOut"}},'
            f' {t0 + 0.1:.2f} + i * 0.18); }});')
    elif kind == "pop":
        js.append(f'tl.fromTo("#{cid}-mark", {{scale:0.4}}, {{scale:1, duration:0.45, '
                  f'ease:"back.out(2.2)"}}, {t0 + 0.05:.2f});')
    elif kind == "dots":
        cycle = 0.42
        reps = max(0, int(dur / (cycle * 3)) - 1)
        js.append(
            f'gsap.utils.toArray(".{cid}-dot").forEach((d, i) => {{'
            f' gsap.set(d, {{transformOrigin:"50% 50%", opacity:0.28}});'
            f' tl.to(d, {{opacity:1, scale:1.25, duration:{cycle / 2:.2f}, yoyo:true, '
            f'repeat:{reps * 2 + 1}, ease:"sine.inOut"}}, {t0 + 0.15:.2f} + i * 0.14); }});')
    elif kind == "progress":
        js.append(f'tl.fromTo("#{cid}-fill", {{scaleX:0}}, {{scaleX:1, duration:{max(dur * 0.8, 0.5):.2f}, '
                  f'ease:"power2.inOut"}}, {t0 + 0.15:.2f});')

    label = c.get("label")
    if label:
        lsize = int(c.get("label_size", 56))
        css += f"""
      #{cid}-marklabel {{ position:absolute; left:0; right:0; top:{int(top + draw_h + 34)}px;
        text-align:center; font-weight:700; font-size:{lsize}px; color:{theme['ink']};
        opacity:0; }}
    """
        html += f'<div id="{cid}-marklabel">{label}</div>'
        js.append(f'tl.fromTo("#{cid}-marklabel", {{opacity:0, y:16}}, {{opacity:1, y:0, '
                  f'duration:0.3, ease:"power2.out"}}, {t0 + 0.5:.2f});')

    return dict(css=css, html=html, js="\n      ".join(js))
