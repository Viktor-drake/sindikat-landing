# -*- coding: utf-8 -*-
"""
Саунд-дизайн без библиотек звуков: короткие эффекты синтезируются локально и
расставляются по СОБЫТИЯМ анимации, а не на каждую смену карточки.

    python sound.py projects/my-reel/manifest.yaml --video in.mp4 --out out.mp4 --speed 1.2
    python sound.py ... --dry-run        # показать раскладку звуков, ничего не рендерить

Правило, выведенное на практике: один и тот же whoosh на каждой карточке
раздражает уже к середине ролика. Поэтому:
  * whoosh только на полнокадровых вставках (broll), это редко;
  * остальные события получают СВОИ звуки: галочки тикают, логотип «попает»,
    зачёркивание бьёт глухо, печать в окне Claude щёлкает еле слышно;
  * заголовки идут вообще без звука, тишина это тоже приём;
  * глобальный троттлинг: не чаще одного эффекта в MIN_GAP секунд (кроме печати).

Тайминги событий взяты из build.py и должны меняться вместе с ним.
"""
import argparse
import math
import pathlib
import struct
import subprocess
import sys
import wave

import yaml

SR = 48000
FF = pathlib.Path(r"D:/Программы/Python/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe")
SFX_DIR = pathlib.Path(__file__).parent / "sfx"
MIN_GAP = 0.55          # секунд между любыми двумя эффектами (печать не в счёт)
WHOOSH_MIN_GAP = 6.0    # whoosh реже всех, иначе он и есть источник раздражения


# ── синтез ────────────────────────────────────────────────────────────────────

def _write_wav(path, samples, peak=0.9):
    """Нормализуем по пику: громкость задаётся микшером, а не синтезом.
    Первая версия давала пик -16 дБ и под речью её физически не было слышно."""
    m = max((abs(x) for x in samples), default=0.0)
    if m > 0:
        samples = [x * (peak / m) for x in samples]
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", max(-32767, min(32767, int(s * 32767)))) for s in samples))


def _noise(n, seed=7):
    """Детерминированный псевдошум (без random, чтобы звук не плавал между сборками)."""
    x = seed
    for _ in range(n):
        x = (1103515245 * x + 12345) % (2 ** 31)
        yield (x / (2 ** 30)) - 1.0


def make_whoosh(dur=0.42):
    """Мягкий воздух, без высоких: должен подпирать монтаж, а не резать ухо."""
    n = int(SR * dur)
    out, lp, hp_prev, hp_out = [], 0.0, 0.0, 0.0
    for i, raw in enumerate(_noise(n)):
        t = i / n
        lp += 0.055 * (raw - lp)
        hp_out = 0.86 * (hp_out + lp - hp_prev)
        hp_prev = lp
        out.append(hp_out * (math.sin(math.pi * t) ** 2))
    return out


def make_pop(dur=0.16):
    """Появление логотипа: круглый короткий тон вверх."""
    n = int(SR * dur)
    return [math.sin(2 * math.pi * 430 * (1 + 0.5 * i / n) * i / SR) * math.exp(-10.0 * i / n)
            for i in range(n)]


def make_tick(dur=0.05):
    """Галочка чек-листа: очень короткий сухой щелчок."""
    n = int(SR * dur)
    return [math.sin(2 * math.pi * 1650 * i / SR) * math.exp(-40.0 * i / n) for i in range(n)]


def make_key(dur=0.035):
    """Печать в окне Claude: тише и глуше тика, иначе получается пулемёт."""
    n = int(SR * dur)
    return [(0.6 * math.sin(2 * math.pi * 900 * i / SR) + 0.4 * next(_noise(1, seed=i + 3)))
            * math.exp(-48.0 * i / n) for i in range(n)]


def make_thock(dur=0.22):
    """Зачёркивание в хуке: низкий глухой удар."""
    n = int(SR * dur)
    return [math.sin(2 * math.pi * 148 * (1 - 0.25 * i / n) * i / SR) * math.exp(-14.0 * i / n)
            for i in range(n)]


def make_ding(dur=0.5):
    """«Готово» в окне Claude: два тона, мягко."""
    n = int(SR * dur)
    out = []
    for i in range(n):
        t = i / SR
        a = math.sin(2 * math.pi * 784 * t) * math.exp(-6.0 * i / n)
        b = math.sin(2 * math.pi * 1176 * t) * math.exp(-9.0 * i / n) * 0.5
        out.append((a + b) * 0.7)
    return out


SFX = {"whoosh": make_whoosh, "pop": make_pop, "tick": make_tick,
       "key": make_key, "thock": make_thock, "ding": make_ding}

# Громкость каждого эффекта отдельно: они по-разному лезут в ухо.
GAIN = {"whoosh": 0.13, "pop": 0.20, "tick": 0.15, "key": 0.11, "thock": 0.24, "ding": 0.18}


def ensure_sfx(force=False) -> dict:
    paths = {}
    for name, fn in SFX.items():
        p = SFX_DIR / f"{name}.wav"
        if force or not p.exists():
            _write_wav(p, fn())
        paths[name] = p
    return paths


# ── события ───────────────────────────────────────────────────────────────────

def events_from_manifest(manifest_path):
    """[(время, эффект, что это было)] в таймлайне ИСХОДНОГО (неускоренного) ролика."""
    m = yaml.safe_load(pathlib.Path(manifest_path).read_text(encoding="utf-8"))
    ev = []
    for c in m.get("cards", []):
        t0 = float(c["start"])
        dur = float(c["duration"])
        t = c["type"]
        if t == "hook":
            ev.append((t0 + 0.75, "thock", "зачёркивание"))
        elif t == "logo":
            ev.append((t0 + 0.12, "pop", f'логотип {pathlib.Path(str(c.get("src", ""))).stem}'))
        elif t == "checklist":
            for i, step in enumerate(c.get("steps", [])):
                ev.append((t0 + 1.35 + i * 0.33, "tick", f"галочка {step}"))
        elif t == "claude_window":
            words = c.get("prompt_words", [])
            for i, w in enumerate(words):
                ev.append((t0 + 0.77 + i * 0.25, "key", f"печать {w}"))
            ev.append((t0 + dur - 0.9, "ding", "готово"))
        elif t == "broll":
            ev.append((t0, "whoosh", "полнокадровая вставка"))
        elif t == "mark" and c.get("shape") in ("type_line", "claude_terminal", "claude_desktop"):
            # печать: клики по символам, но не чаще 11 в секунду, иначе получается пулемёт
            text = str(c.get("text") or c.get("prompt") or "")
            run = float(c.get("run", max(dur * (0.55 if c.get("shape") == "type_line" else (0.3 if c.get("shape") == "claude_desktop" else 0.4)), 0.7)))
            lead = {"type_line": 0.3, "claude_terminal": 0.4, "claude_desktop": 0.35}[c.get("shape")]
            n = max(1, min(len(text), int(run * 11)))
            for k in range(n):
                ev.append((t0 + lead + run * k / n, "key", "печать"))
            if c.get("shape") == "claude_terminal" and c.get("steps"):
                for i, st in enumerate(c["steps"]):
                    ev.append((t0 + 0.5 + run + i * 0.35, "tick", f"шаг {st}"))
        elif t == "mark" and c.get("shape") == "codeword":
            ev.append((t0 + 0.05, "pop", "кодовое слово"))
        elif t == "mark" and c.get("shape") in ("check", "spark", "badge", "particles",
                                                "number_roll", "counter", "compare", "highlight",
                                                "bar_chart", "card_stack", "chat_bubbles",
                                                "node_map", "timeline", "frame_box", "strike_text"):
            ev.append((t0 + 0.1, "pop", f'акцент {c.get("shape")}'))
        elif t == "shot":
            ev.append((t0 + 0.15, "pop", f'скриншот {pathlib.Path(str(c.get("src", ""))).stem}'))
        # headline намеренно молчит
    return sorted(ev, key=lambda x: x[0])


def throttle(events):
    """Убирает частокол: эффекты не ближе MIN_GAP, whoosh не ближе WHOOSH_MIN_GAP."""
    kept, last_any, last_whoosh = [], -99.0, -99.0
    for t, name, what in events:
        # печать и галочки идут сериями, их частота это ритм, а не частокол;
        # ограничиваем только столкновение с «крупными» звуками
        if name in ("key", "tick"):
            if t - last_any >= 0.2:
                kept.append((t, name, what))
            continue
        if t - last_any < MIN_GAP:
            continue
        if name == "whoosh" and t - last_whoosh < WHOOSH_MIN_GAP:
            continue
        kept.append((t, name, what))
        last_any = t
        if name == "whoosh":
            last_whoosh = t
    return kept


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("manifest")
    ap.add_argument("--video", help="готовый ролик (уже ускоренный, если ускоряешь)")
    ap.add_argument("--out")
    ap.add_argument("--speed", type=float, default=1.0, help="во сколько раз ролик уже ускорен")
    ap.add_argument("--gain", type=float, default=1.0, help="общий множитель громкости эффектов")
    ap.add_argument("--music", help="wav/mp3 подложки (опционально)")
    ap.add_argument("--music-gain", type=float, default=0.06)
    ap.add_argument("--regen", action="store_true", help="пересинтезировать wav-ы")
    ap.add_argument("--dry-run", action="store_true", help="показать раскладку и выйти")
    a = ap.parse_args()

    paths = ensure_sfx(force=a.regen)
    events = throttle(events_from_manifest(a.manifest))
    events = [(round(t / a.speed, 3), n, w) for t, n, w in events]

    print(f"Событий: {len(events)}")
    for t, n, w in events:
        print(f"  {t:6.2f}s  {n:7} {w}")
    counts = {}
    for _, n, _ in events:
        counts[n] = counts.get(n, 0) + 1
    print("  итого:", ", ".join(f"{k} x{v}" for k, v in sorted(counts.items())))
    if a.dry_run:
        return
    if not (a.video and a.out):
        sys.exit("Нужны --video и --out (или --dry-run)")
    if not FF.exists():
        sys.exit(f"ffmpeg не найден: {FF}")

    used = sorted({n for _, n, _ in events})
    idx = {n: i + 1 for i, n in enumerate(used)}      # 0 это видео
    inputs = ["-i", a.video]
    for n in used:
        inputs += ["-i", str(paths[n])]
    if a.music:
        inputs += ["-i", a.music]

    # у витрин и немых композиций своей дорожки нет: тогда база это тишина
    # (иначе amix ссылается на несуществующий [0:a] и ffmpeg падает).
    # Тишина добавляется ПОСЛЕДНИМ входом, чтобы видео осталось нулевым.
    probe = subprocess.run([str(FF), "-i", a.video], capture_output=True, text=True,
                           encoding="utf-8", errors="ignore")
    has_audio = "Audio:" in (probe.stderr or "")
    if has_audio:
        base = "[0:a]"
    else:
        inputs += ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=mono"]
        base = f"[{len(used) + (2 if a.music else 1)}:a]"
    shift = 0
    parts, labels = [], [base]
    for k, (t, n, _) in enumerate(events):
        ms = int(t * 1000)
        g = round(GAIN[n] * a.gain, 4)
        parts.append(f"[{idx[n] + shift}:a]adelay={ms}|{ms},volume={g}[s{k}]")
        labels.append(f"[s{k}]")
    if a.music:
        parts.append(f"[{len(used) + 1 + shift}:a]volume={a.music_gain}[m]")
        labels.append("[m]")
    fc = ";".join(parts) + f";{''.join(labels)}amix=inputs={len(labels)}:duration=first:normalize=0[a]"

    subprocess.run([str(FF), "-y", "-v", "error", *inputs, "-filter_complex", fc,
                    "-map", "0:v", "-map", "[a]", "-shortest", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                    a.out], check=True)
    print(f"Готово: {a.out}")


if __name__ == "__main__":
    main()
