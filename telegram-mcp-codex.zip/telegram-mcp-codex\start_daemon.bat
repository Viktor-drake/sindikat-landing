@echo off
REM Telegram MCP для Codex - запуск демона (Streamable HTTP, порт 8765).
REM Codex подключается по адресу http://127.0.0.1:8765/mcp
REM Claude Code, если нужен, подключается к ЭТОМУ ЖЕ демону
REM (в .mcp.json: "type": "http", url .../mcp). Второй демон не запускать.
setlocal
cd /d "%~dp0"

if not exist .venv\Scripts\python.exe (
    echo [!] Нет .venv. Сначала выполни:
    echo     python -m venv .venv
    echo     .venv\Scripts\python.exe -m pip install -r requirements.txt
    pause
    exit /b 1
)

if not exist logs mkdir logs

REM Не запускаем вторую копию, если порт уже занят
netstat -ano | findstr /R /C:"LISTENING" | findstr ":8765" >nul 2>&1
if %errorlevel%==0 (
    echo Демон уже работает на 8765, вторая копия не нужна.
    exit /b 0
)

REM pythonw, а не python: не мигает окно консоли при запуске
start "" /b .venv\Scripts\pythonw.exe main.py --transport streamable-http --host 127.0.0.1 --port 8765 >> logs\daemon.log 2>&1
echo Демон запущен: http://127.0.0.1:8765/mcp (лог: logs\daemon.log)
endlocal
