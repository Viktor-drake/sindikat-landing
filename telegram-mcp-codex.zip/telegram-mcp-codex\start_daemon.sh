#!/bin/bash
# Telegram MCP для Codex - запуск демона (Streamable HTTP, порт 8765).
# Codex подключается по адресу http://127.0.0.1:8765/mcp
# Claude Code, если нужен, подключается к ЭТОМУ ЖЕ демону
# (в .mcp.json: "type": "http", url .../mcp). Второй демон не запускать.
cd "$(dirname "$0")"

if [ ! -f .venv/bin/python ]; then
  echo "[!] Нет .venv. Сначала: python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"
  exit 1
fi

mkdir -p logs

# Не запускаем вторую копию, если порт уже занят
if lsof -i :8765 -sTCP:LISTEN >/dev/null 2>&1; then
  echo "Демон уже работает на 8765, вторая копия не нужна."
  exit 0
fi

nohup .venv/bin/python main.py --transport streamable-http --host 127.0.0.1 --port 8765 >> logs/daemon.log 2>&1 &
echo "Демон запущен: http://127.0.0.1:8765/mcp (лог: logs/daemon.log)"
