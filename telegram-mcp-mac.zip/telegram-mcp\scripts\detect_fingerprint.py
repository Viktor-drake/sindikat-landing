"""
Определяет «слепок» (отпечаток) твоего компьютера и записывает его в .env.

Зачем: по умолчанию библиотека Telethon представляется Telegram так:
ключи официального приложения + строки вида "Darwin arm64" + свою
собственную версию вместо версии приложения. Для антифрода Telegram это
выглядит как поддельный клиент, и он отзывает молодые сессии (кейс клуба,
июль 2026: сессии умирали за 2-4 минуты). Со слепком реального компьютера
расхождения нет - сессии живут.

Запуск:
    macOS/Linux:  .venv/bin/python scripts/detect_fingerprint.py
    Windows:      .venv\\Scripts\\python.exe scripts\\detect_fingerprint.py
"""
import os
import platform
import plistlib
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ENV_PATH = ROOT / ".env"


def _run(cmd) -> str:
    try:
        return subprocess.run(
            cmd, capture_output=True, text=True, timeout=15
        ).stdout.strip()
    except Exception:
        return ""


def mac_device_model() -> str:
    """
    Человекочитаемое имя модели ('MacBook Air', 'MacBook Pro', 'iMac'...).

    Основной источник - system_profiler: он отдаёт готовое имя семейства
    независимо от схемы числовых идентификаторов. Запасной путь (парсинг
    hw.model) не годится сам по себе: на Intel/M1 идентификатор вида
    'MacBookAir10,1' содержит словесный префикс, а на части линеек M2+
    Apple перешла на голые 'Mac14,2' без него - тогда после отсечения
    цифр остаётся бесполезное 'Mac' (найдено на реальном MacBook Air M2,
    07.09.2026).
    """
    try:
        import json

        raw = _run(["system_profiler", "SPHardwareDataType", "-json"])
        if raw:
            data = json.loads(raw)
            name = data.get("SPHardwareDataType", [{}])[0].get("machine_name", "").strip()
            if name:
                return name
    except Exception:
        pass

    # Запасной путь, только если system_profiler недоступен.
    raw = _run(["sysctl", "-n", "hw.model"])
    if not raw:
        return "Mac"
    name = re.sub(r"[\d,]+$", "", raw)  # MacBookAir10,1 -> MacBookAir
    pretty = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", name).strip()
    return pretty or "Mac"


def mac_system_version() -> str:
    ver = _run(["sw_vers", "-productVersion"])
    return f"macOS {ver}" if ver else "macOS"


def mac_telegram_version() -> str:
    """Версия установленного Telegram Desktop из Info.plist."""
    for app in (
        "/Applications/Telegram.app",
        str(Path.home() / "Applications/Telegram.app"),
        "/Applications/Telegram Desktop.app",
    ):
        plist = Path(app) / "Contents/Info.plist"
        if plist.exists():
            try:
                with open(plist, "rb") as f:
                    data = plistlib.load(f)
                ver = data.get("CFBundleShortVersionString") or data.get("CFBundleVersion")
                if ver:
                    return str(ver)
            except Exception:
                pass
    return ""


def win_device_model() -> str:
    out = _run(
        ["powershell", "-NoProfile", "-Command",
         "(Get-CimInstance Win32_ComputerSystem).Model"]
    )
    return out or "PC"


def win_system_version() -> str:
    rel = _run(
        ["powershell", "-NoProfile", "-Command",
         "(Get-CimInstance Win32_OperatingSystem).Caption"]
    )
    if rel:
        # 'Microsoft Windows 11 Pro' -> 'Windows 11'
        m = re.search(r"Windows\s+(\d+)", rel)
        if m:
            return f"Windows {m.group(1)}"
        return rel.replace("Microsoft ", "").strip()
    return f"Windows {platform.release()}"


def win_telegram_version() -> str:
    candidates = [
        Path(os.environ.get("APPDATA", "")) / "Telegram Desktop" / "Telegram.exe",
        Path(os.environ.get("PROGRAMFILES", "")) / "Telegram Desktop" / "Telegram.exe",
    ]
    for exe in candidates:
        if exe.exists():
            out = _run(
                ["powershell", "-NoProfile", "-Command",
                 f"(Get-Item '{exe}').VersionInfo.ProductVersion"]
            )
            if out:
                return out.split(".0.0")[0] if out.count(".") > 2 else out
    return ""


def detect() -> dict:
    system = platform.system()
    if system == "Darwin":
        return {
            "TELEGRAM_DEVICE_MODEL": mac_device_model(),
            "TELEGRAM_SYSTEM_VERSION": mac_system_version(),
            "TELEGRAM_APP_VERSION": mac_telegram_version(),
        }
    if system == "Windows":
        return {
            "TELEGRAM_DEVICE_MODEL": win_device_model(),
            "TELEGRAM_SYSTEM_VERSION": win_system_version(),
            "TELEGRAM_APP_VERSION": win_telegram_version(),
        }
    return {
        "TELEGRAM_DEVICE_MODEL": platform.node() or "PC",
        "TELEGRAM_SYSTEM_VERSION": f"{system} {platform.release()}",
        "TELEGRAM_APP_VERSION": "",
    }


def read_env() -> dict:
    values = {}
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, _, v = line.partition("=")
                values[k.strip()] = v.strip()
    return values


def write_env(updates: dict) -> None:
    lines = ENV_PATH.read_text(encoding="utf-8").splitlines() if ENV_PATH.exists() else []
    for key, value in updates.items():
        lines = [l for l in lines if not l.startswith(key + "=")]
        lines.append(f"{key}={value}")
    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    print("--- Определение слепка компьютера ---\n")
    fp = detect()

    for key, value in fp.items():
        print(f"  {key}={value or '(не определилось)'}")

    if not fp["TELEGRAM_APP_VERSION"]:
        print(
            "\n[!] Не нашёл установленный Telegram Desktop, поэтому не знаю его версию.\n"
            "    Открой Telegram на компьютере: Настройки -> О программе (About),\n"
            "    и впиши номер версии (например 5.16.4) в .env вручную:\n"
            "    TELEGRAM_APP_VERSION=5.16.4"
        )

    env = read_env()
    if env.get("TELEGRAM_SESSION_STRING"):
        print(
            "\n=========================== СТОП ===========================\n"
            "В .env уже есть рабочая сессия (TELEGRAM_SESSION_STRING).\n"
            "МЕНЯТЬ СЛЕПОК НА ЖИВОЙ СЕССИИ НЕЛЬЗЯ: она была создана со старым\n"
            "слепком, и расхождение 'вход одним, работа другим' - это как раз\n"
            "то, что Telegram считает подделкой. Сессия умрёт.\n\n"
            "Если всё работает - ничего не делай, закрой этот скрипт.\n"
            "Если будешь логиниться заново - сначала очисти строку\n"
            "TELEGRAM_SESSION_STRING= в .env, потом запусти этот скрипт снова.\n"
            "============================================================"
        )
        return 1

    write_env({k: v for k, v in fp.items() if v})
    print(f"\nГотово: слепок записан в {ENV_PATH}")
    print("Следующий шаг - вход в Telegram (ОДИН раз):")
    exe = ".venv\\Scripts\\python.exe" if platform.system() == "Windows" else ".venv/bin/python"
    print(f"    {exe} scripts/session_string_generator.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
