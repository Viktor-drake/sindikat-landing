"""
Telegram session string generator (macOS build).

Fully async (no telethon.sync, no nest_asyncio - both break on
Python 3.11+ / macOS). Writes the session string straight into the
project's .env so the daemon reads exactly what was generated here.
2FA password is read with getpass and never echoes to the terminal.

Usage:
    .venv/bin/python scripts/session_string_generator.py
"""
import asyncio
import getpass
import os
import sys
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError, FloodWaitError
from telethon.sessions import StringSession

ROOT = Path(__file__).resolve().parent.parent
ENV_PATH = ROOT / ".env"
load_dotenv(ENV_PATH)


def update_env(key: str, value: str) -> None:
    """Insert or replace KEY=value in .env, keeping other lines intact."""
    lines = []
    if ENV_PATH.exists():
        lines = ENV_PATH.read_text(encoding="utf-8").splitlines()
    lines = [l for l in lines if not l.startswith(key + "=")]
    lines.append(f"{key}={value}")
    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_proxy():
    url = os.environ.get("TELEGRAM_PROXY", "").strip()
    if not url:
        return None
    u = urlparse(url)
    if u.scheme and u.hostname and u.port:
        print(f"Using proxy {u.scheme}://{u.hostname}:{u.port}")
        return (u.scheme, u.hostname, u.port)
    print(f"WARNING: cannot parse TELEGRAM_PROXY='{url}', connecting without proxy")
    return None


def build_fingerprint() -> dict:
    """
    Same client fingerprint as the daemon (TELEGRAM_DEVICE_MODEL /
    TELEGRAM_SYSTEM_VERSION / TELEGRAM_APP_VERSION from .env). CRITICAL:
    login and daemon must present ONE identity — a session that logs in
    with one fingerprint and then runs with another is itself a red flag.
    """
    kwargs = {}
    for env_key, kw in (
        ("TELEGRAM_DEVICE_MODEL", "device_model"),
        ("TELEGRAM_SYSTEM_VERSION", "system_version"),
        ("TELEGRAM_APP_VERSION", "app_version"),
    ):
        val = os.environ.get(env_key, "").strip()
        if val:
            kwargs[kw] = val
    if kwargs:
        print(f"Client fingerprint override: {kwargs}")
    return kwargs


async def main() -> None:
    print("----- Telegram Session String Generator (Mac) -----\n")
    api_id = os.environ.get("TELEGRAM_API_ID") or input("API ID (my.telegram.org): ").strip()
    api_hash = os.environ.get("TELEGRAM_API_HASH") or input("API Hash: ").strip()

    client = TelegramClient(
        StringSession(), int(api_id), api_hash, proxy=build_proxy(), **build_fingerprint()
    )
    await client.connect()

    if not await client.is_user_authorized():
        phone = input("Phone (+7...): ").strip()
        try:
            await client.send_code_request(phone)
        except FloodWaitError as e:
            print(f"\nTelegram flood limit: wait {e.seconds} seconds, then retry ONCE.")
            sys.exit(1)
        code = input("Code from Telegram: ").strip()
        try:
            await client.sign_in(phone, code)
        except SessionPasswordNeededError:
            password = getpass.getpass("2FA password (typing is hidden): ")
            await client.sign_in(password=password)

    if not await client.is_user_authorized():
        print("\nAuthorization FAILED. Do not retry in a loop - wait 3-4 hours if repeated.")
        sys.exit(1)

    session_string = StringSession.save(client.session)
    update_env("TELEGRAM_API_ID", str(api_id))
    update_env("TELEGRAM_API_HASH", api_hash)
    update_env("TELEGRAM_SESSION_STRING", session_string)
    # Login timestamp powers the daemon's anti-fraud quiet period
    # (QUIET_WARMUP_HOURS): young sessions must not start with bulk reads.
    import time as _time

    update_env("TELEGRAM_LOGIN_TS", str(int(_time.time())))

    me = await client.get_me()
    print(f"\nOK: authorized as {me.first_name} (@{me.username})")
    print(f"Session string written to {ENV_PATH} (TELEGRAM_SESSION_STRING).")
    print("Do NOT press 'Terminate all sessions' in Telegram after this - it kills the string.")
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
