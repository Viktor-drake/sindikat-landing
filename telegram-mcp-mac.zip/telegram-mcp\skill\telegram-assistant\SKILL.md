---
name: telegram-assistant
description: Работа с Telegram через MCP-сервер telegram-mcp-v2. Используй ВСЕГДА, когда просят что-либо сделать в Telegram - отправить сообщение или файл, ответить, переслать, найти чат или переписку, посмотреть историю, поставить реакцию, создать группу или опрос, работать с каналами, топиками, папками, контактами, черновиками. Триггеры - телеграм, telegram, тг, напиши в тг, отправь сообщение, скинь файл, найди чат, найди переписку, история чата, реакция, лайк, канал, группа, топик, форум, папка, черновик, опрос, стикер, гифка, переслать, закрепить, пригласить, забанить.
---

# Telegram через MCP

Все инструменты вызываются с префиксом `mcp__telegram-mcp-v2__`.
Например: `mcp__telegram-mcp-v2__send_message`.

ВАЖНО ПРО ПОИСК ИНСТРУМЕНТОВ. Инструменты MCP подгружаются по мере
необходимости, поэтому в текущем контексте их может ещё не быть. Если
нужного инструмента не видно, это НЕ значит, что его нет на сервере:
сначала загрузи его по имени из списка ниже (в Claude Code - через
ToolSearch, запрос вида `select:mcp__telegram-mcp-v2__send_message`),
и только потом делай вывод. Всего сервер отдаёт 94 инструмента, включая
все операции отправки и редактирования.

## Как определить чат

Инструменты принимают `chat_id` в трёх видах:
- число (например 296286990) - самый надёжный способ
- username со собакой (@durov)
- название чата для поиска через `search_contacts` / `list_chats`

Если чат неизвестен, сначала найди его: `list_chats`, `search_contacts`
или `resolve_username`, возьми ID из ответа и работай с ним.

## Частые сценарии

Отправить сообщение человеку по username:
1. `resolve_username` (получить ID) -> 2. `send_message`

Ответить в топик форума:
`reply_to_message` с `message_id` = ID топика (список топиков даёт
`list_topics`). Для файла в топик - `send_file` с `reply_to_msg_id`.

Прочитать последние сообщения чата:
`get_history` или `list_messages` с нужным `limit`.

Найти переписку по слову:
`search_messages` внутри чата или `search_global` по всем чатам.

Отправить файл:
`send_file` с абсолютным путём. Путь должен быть внутри разрешённых
папок (allowed roots), иначе будет ошибка доступа.

## Форматирование текста

`parse_mode`: `html` для тегов `<b>`, `<i>`, `<code>`; `md` для Markdown;
не указывать для обычного текста. Сообщения длиннее 4096 символов сервер
режет и отправляет частями сам.

Если текст пойдёт человеку на копирование, не используй markdown-звёздочки
и решётки: в Telegram они видны буквально. Акценты делай КАПСОМ, структуру
пустыми строками.

## Полный список инструментов

### Сообщения

- `send_message` - Send a message to a specific chat.
- `reply_to_message` - Reply to a specific message in a chat.
- `edit_message` - Edit a message you sent.
- `delete_message` - Delete a message by ID.
- `forward_message` - Forward a message from one chat to another.
- `send_file` - Send a file to a chat.
- `send_voice` - Send a voice message to a chat. File must be an OGG/OPUS voice note.
- `send_sticker` - Send a sticker to a chat. File must be a valid .webp sticker file.
- `send_gif` - Send a GIF to a chat by Telegram GIF document ID (not a file path).
- `create_poll` - Create a poll in a chat using Telegram's native poll feature.
- `send_reaction` - Send a reaction to a message.
- `remove_reaction` - Remove your reaction from a message.
- `get_message_reactions` - Get the list of reactions on a message.
- `pin_message` - Pin a message in a chat.
- `unpin_message` - Unpin a message in a chat.
- `mark_as_read` - Mark all messages as read in a chat.
- `get_pinned_messages` - Get all pinned messages in a chat.

### Чтение и поиск

- `get_chats` - Get a paginated list of chats.
- `list_chats` - List available chats with metadata.
- `get_chat` - Get detailed information about a specific chat.
- `get_messages` - Get paginated messages from a specific chat.
- `list_messages` - Retrieve messages with optional filters.
- `get_history` - Get full chat history (up to limit).
- `get_message_context` - Retrieve context around a specific message.
- `search_messages` - Search for messages in a chat by text.
- `search_global` - Search for messages across all public chats and channels by text content.
- `search_public_chats` - Search for public chats, channels, or bots by username or title.
- `resolve_username` - Resolve a username to a user or chat ID.
- `get_media_info` - Get info about media in a message.
- `download_media` - Download media from a message in a chat.
- `transcribe_voice` - Transcribe a voice or video-note message via Telegram's built-in

### Контакты

- `list_contacts` - List all contacts in your Telegram account.
- `search_contacts` - Search for contacts by name, username, or phone number using Telethon's SearchRequest.
- `get_contact_ids` - Get all contact IDs in your Telegram account.
- `add_contact` - Add a new contact to your Telegram account.
- `delete_contact` - Delete a contact by user ID.
- `import_contacts` - Import a list of contacts. Each contact should be a dict with phone, first_name, last_name.
- `export_contacts` - Export all contacts as a JSON string.
- `block_user` - Block a user by user ID.
- `unblock_user` - Unblock a user by user ID.
- `get_blocked_users` - Get a list of blocked users.
- `get_direct_chat_by_contact` - Find a direct chat with a specific contact by name, username, or phone.
- `get_contact_chats` - List all chats involving a specific contact.
- `get_last_interaction` - Get the most recent message with a contact.
- `get_user_status` - Get the online status of a user.
- `get_user_photos` - Get profile photos of a user.

### Группы и каналы

- `create_group` - Create a new group or supergroup and add users.
- `create_channel` - Create a new channel or supergroup.
- `invite_to_group` - Invite users to a group or channel.
- `leave_chat` - Leave a group or channel by chat ID.
- `get_participants` - List all participants in a group or channel.
- `edit_chat_title` - Edit the title of a chat, group, or channel.
- `edit_chat_photo` - Edit the photo of a chat, group, or channel. Requires a file path to an image.
- `delete_chat_photo` - Delete the photo of a chat, group, or channel.
- `archive_chat` - Archive a chat.
- `unarchive_chat` - Unarchive a chat.
- `mute_chat` - Mute notifications for a chat.
- `unmute_chat` - Unmute notifications for a chat.
- `subscribe_public_channel` - Subscribe (join) to a public channel or supergroup by username or ID.

### Админство

- `promote_admin` - Promote a user to admin in a group/channel.
- `demote_admin` - Demote a user from admin in a group/channel.
- `ban_user` - Ban a user from a group or channel.
- `unban_user` - Unban a user from a group or channel.
- `get_admins` - Get all admins in a group or channel.
- `get_banned_users` - Get all banned users in a group or channel.
- `get_recent_actions` - Get recent admin actions (admin log) in a group or channel.

### Приглашения

- `get_invite_link` - Get the invite link for a group or channel.
- `export_chat_invite` - Export a chat invite link.
- `import_chat_invite` - Import a chat invite by hash.
- `join_chat_by_link` - Join a chat by invite link.

### Топики форума

- `list_topics` - Retrieve forum topics from a supergroup with the forum feature enabled.

### Папки

- `list_folders` - Get all dialog folders (filters) with their IDs, names, and emoji.
- `get_folder` - Get detailed information about a specific folder including all included chats.
- `create_folder` - Create a new dialog folder.
- `delete_folder` - Delete a folder. Chats in the folder are preserved, only the folder is removed.
- `add_chat_to_folder` - Add a chat to an existing folder.
- `remove_chat_from_folder` - Remove a chat from a folder.
- `reorder_folders` - Change the order of folders in the folder list.

### Черновики

- `save_draft` - Save a draft message to a chat or channel. The draft will appear in the Telegram
- `get_drafts` - Get all draft messages across all chats.
- `clear_draft` - Clear/delete a draft from a specific chat.

### Профиль и приватность

- `get_me` - Get your own user information.
- `update_profile` - Update your profile information (name, bio).
- `set_profile_photo` - Set a new profile photo.
- `delete_profile_photo` - Delete your current profile photo.
- `get_privacy_settings` - Get your privacy settings for last seen status.
- `set_privacy_settings` - Set privacy settings (e.g., last seen, phone, etc.).

### Боты и медиа

- `get_bot_info` - Get information about a bot by username.
- `set_bot_commands` - Set bot commands for a bot you own.
- `list_inline_buttons` - Inspect inline buttons on a recent message to discover their indices/text/URLs.
- `press_inline_button` - Press an inline button (callback) in a chat message.
- `upload_file` - Upload a local file to Telegram and return upload metadata.
- `get_sticker_sets` - Get all sticker sets.
- `get_gif_search` - Search for GIFs by query. Returns a list of Telegram document IDs (not file paths).

## Ошибки и что они значат

- `session string is not authorized` - сессия отозвана, нужен новый вход
  через `scripts/session_string_generator.py`
- `GEN-ERR-*` / `CONTACT-ERR-*` - ошибка конкретного вызова, детали
  в `mcp_errors.log` рядом с main.py
- инструментов Telegram не видно вообще - демон не запущен или сессия
  клиента подключилась до старта демона, перезапусти сессию агента
