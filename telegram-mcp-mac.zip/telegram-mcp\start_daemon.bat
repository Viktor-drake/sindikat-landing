@echo off
REM Telegram MCP - запуск демона на Windows (SSE, порт 8765).
REM Все сессии Claude Code подключаются к одному этому процессу.
setlocal
cd /d "%~dp0"

if not exist .venv\Scripts\python.exe (
    echo [!] Нет .venv. Сначала выполни:
    echo     python -m venv .venv
    echo     .venv\Scripts\python.exe -m pip install -r requirements.txt
    pause
    exit /b 1
)

if not exist logs mkdir logs

REM Не запускаем вторую копию, если порт уже занят
netstat -ano | findstr /R /C:"LISTENING" | findstr ":8765" >nul 2>&1
if %errorlevel%==0 (
    echo Демон уже работает на 8765, вторая копия не нужна.
    exit /b 0
)

REM pythonw, а не python: не мигает окно консоли при запуске
start "" /b .venv\Scripts\pythonw.exe main.py --transport sse --host 127.0.0.1 --port 8765 >> logs\daemon.log 2>&1
echo Демон запущен (лог: logs\daemon.log). Проверка: netstat -ano ^| findstr :8765
endlocal
