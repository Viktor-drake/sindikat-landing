#!/bin/bash
# Telegram MCP - запуск демона на macOS (SSE, порт 8765).
# Все сессии Claude Code подключаются к одному этому процессу.
cd "$(dirname "$0")"

if [ ! -f .venv/bin/python ]; then
  echo "[!] Нет .venv. Сначала: python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"
  exit 1
fi

mkdir -p logs

# Не запускаем вторую копию, если порт уже занят
if lsof -i :8765 -sTCP:LISTEN >/dev/null 2>&1; then
  echo "Демон уже работает на 8765, вторая копия не нужна."
  exit 0
fi

nohup .venv/bin/python main.py --transport sse --host 127.0.0.1 --port 8765 >> logs/daemon.log 2>&1 &
echo "Демон запущен (лог: logs/daemon.log). Проверка: lsof -i :8765"
